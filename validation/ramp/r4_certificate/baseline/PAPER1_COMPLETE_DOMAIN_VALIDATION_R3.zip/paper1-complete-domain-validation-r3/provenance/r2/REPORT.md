# Paper 1: implemented continuation and remaining decision

## Corrected result

The continuation has produced a model-specific contour formulation and rigorous local integration enclosures. It has not established an unconditional exact-lattice floor. The completed Extension 1 results, selected numerical response, fixed-matrix 10.8% certificate and manuscript remain unchanged.

The substantive mathematical improvement is that, at the reference squared frequency E=36/25, the fixed radius s=acos(3/4) separates the longitudinal radial pole from both transverse poles in every maximum-coordinate chart. The exact endpoint inequalities are lambda_2<=11/8<E and lambda_3>=3/2>E. The margins are 13/200 and 3/50. The previous complete radial census converts these endpoint inequalities into a complete pole classification, including tied transverse modes.

For complex radial coordinate z with 0<Re(z)<=R=acos(1/4), the imaginary part of the nine-bond matrix has the sign of Im(z) and is definite. This excludes nonreal poles. Consequently the full retarded Green integral can be evaluated along a lower complex contour, with its real exterior contribution retained. The imaginary part of the lower contour from s to R gives the lower-two qT spectral integral. This handles the complete residue at a transverse degeneracy without selecting individual eigenvectors. It also includes principal-value and endpoint contributions without explicit singular subtraction.

These statements were derived separately in the mathematical and referee reviews, checked against the actual source convention, and challenged by exact algebra, interval endpoint bounds, and independently computed symmetry-direction integrals. The numerical comparisons are diagnostics; the written inequalities justify the global separator and pole exclusion.

## Implemented local integration

The code encloses entire positive-area angular cells with outward ball arithmetic. It retains all 17 signed source moments, the t^2 chart Jacobian, positive-octant normalization 1/pi^3, and the fixed physical source axis. Source factors are extended analytically on the complex contour; they are not numerically conjugated there.

| Fixed x-chart cell | u interval | v interval | Finest qT maximum interval radius | Finest Green maximum real/imaginary radius |
|---|---|---|---:|---:|
| Ordinary | [3/8,7/16] | [5/8,11/16] | 1.20e-4 | 2.61e-4 |
| Coordinate plane | [7/16,1/2] | [0,1/32] | 1.66e-5 | 4.07e-5 |
| Axis | [0,1/32] | [0,1/32] | 6.69e-7 | 5.79e-6 |
| Body diagonal | [31/32,1] | [31/32,1] | 3.39e-5 | 4.73e-5 |

These are rounded descriptions of the exact binary endpoint records, not global errors or uncertainty on the paper's conversion coefficient. The qT refinement uses 8 by 8 angular subdivisions and 512 segments per contour edge; the Green refinement uses 8 by 8 and 256, including the regular exterior. The same physical cells were retained across refinements. All 68 refined qT moment intervals are strictly contained in their preceding intervals. Green enclosures overlap across successful levels and their maximum widths contract.

The four cells cover 1/128 of the x-chart parameter square, or 1/384 of the combined three-chart parameter area. This is not a solid-angle fraction or a bound on the omitted integral. In particular, enclosure of these cells cannot be substituted for the complete Green/qT matrix errors.

## Higher-order method and the feasibility decision

A three-point tensor Gauss method with a proved Cauchy/Taylor remainder was implemented and independently checked. It proves complex analyticity on the neighborhoods actually used in the error bound by interval inversion, rather than extrapolating the real-angle pole exclusion to complex angles. Exact quadrature nodes and weights are enclosed with Arb. Manufactured polynomial, rational and nonseparable integral tests check both the enclosure theorem and nontrivial error control.

Initially, accepting any finite complex inverse produced a very broad ordinary-cell enclosure. The algorithm was corrected to test the proven error contribution before quadrature and subdivide the coordinate responsible for the largest bound. Bounded stages then identified a further bottleneck near the global separator. A separate whole-cell proof permits better local separators: 5/8 in the ordinary cell, 11/16 at the coordinate plane and 1/2 near the body diagonal. Each is certified by rank-one interlacing and a fixed-vector Rayleigh bound on the complete real angular cell. This changes the integration path while preserving the same qT integral. Complex neighborhoods still require their own verification.

All four higher-order cells completed. The ordinary cell was assembled from four nonoverlapping saved rows and the body-diagonal cell from two; source hashes, settings, exact coverage and every moment were checked before outward summation. All successful stages finished within 20 seconds in the recorded environment. Twelve manufactured checks, 26 result checks, five deliberate merge-rejection checks and two missing-coverage rejection checks passed.

Compared on the same full physical cells, the higher-order maximum radius is smaller by factors of approximately 3.6 (axis), 4.2 (ordinary) and 4.5 (body diagonal). The coordinate-plane radius is about 25% larger than its finest Riemann counterpart, so both methods' records are retained. Ordinary/body runs took more total stage time; this is not evidence of a universal speed improvement.

**Decision: do not launch a full-domain campaign from this pilot alone.** The missing prerequisite is a complete error-allocation and cost plan tied to the actual matrix norm budgets. As a conservative planning reference, a 12-by-12 error matrix with every entry bounded in modulus by 1/4056 satisfies the qT budget because 1.69 times 12 times 1/4056 equals 0.005. A uniform allocation across the three unit-area charts would allow radius density at most 1/12168 (about 8.2e-5), even before reserving anything for displacement from the selected cached centers. The tested higher-order density radii range from about 1.9e-4 to 1.1e-2. This comparison does not prove failure of a nonuniform allocation or impossibility of global certification. It establishes that this sufficient uniform allocation has not been demonstrated, and the four-cell evidence cannot certify the remaining domain.

The appropriate next research stage is to construct a complete adaptive chart cover, allocate errors using the actual repeated moment pattern, and measure the cost of tighter bounds on representative tiles. Options include sharper interval/analytic bounds, increased validated quadrature order, and nonuniform budgeting. Complete all three charts and the Green exterior, then compare exact integral enclosures with the actual cached centers before invoking the conditional floor bridge. This stronger theorem can remain future work for Paper 1's current explicitly numerical and fixed-input claims.

## Checks and corrections made as work proceeded

- Recovery: reread the saved result/plan and rehashed the completed Extension 1 archive. Its identity matched. The original N160 campaign was not rerun.
- Environment: the default interpreter lacked SymPy. The existing validated interpreter imported every required dependency; no new installation was needed.
- Before integration: checked the retarded sign, pi factor, radial Jacobian, phase/cross terms and physical source orientation. Incorrect complex source conjugation, reversed contour orientation and omitted vertical edges were each rejected by targeted controls.
- During interval development: broad boxes that could not certify inversion were recorded as unresolved; subdivision resolved the basic four-cell cases. Failed partial sums were never reported as enclosures.
- During higher-order development: rejected finite-but-unhelpfully-wide bounds, checked complete-domain analytic neighborhoods and introduced certified local contour placement. The proof permits every positive contour height; an unnecessary proposed upper-height restriction was rejected during review.
- Before handoff: validated input rejection, atomic numerical outputs, exact endpoint serialization and generating-code identities. A confirmed audit gap was corrected: the standalone auditor now rejects missing selected cells instead of accepting a reduced or empty result set. Historical records remain paired with their executed source snapshots. Final export replay and its precise scope are recorded separately.

The checks were placed after each new mathematical identity, primitive, pilot/refinement, substantive correction and export. Independent review meant a separate AI-assisted derivation/checking task on the same host; it was not an external human or second-platform review. This was a targeted review with stopping criteria, not an exhaustive audit.

## Consequence for Paper 1

No new error requiring a manuscript correction was confirmed. These results improve the route to a stronger validation theorem; they do not change the selected approximately 12.6% conversion result or establish a more efficient physical device. The present fixed-input floor qualification remains necessary. The new proofs, algorithms and execution history belong in the validation addition; they do not currently justify extra main-paper length or repeated safeguards.

The attached papers helped specify complete root accounting, whole-cluster treatment, source-consistent symmetry and readout-specific error propagation. The new separator and contour statements were derived from Paper 1's own bond matrix, not transferred from another paper's numerical results. The inherited donor map is included as provenance.

## Remaining uncertainty, assumptions and unperformed verification

| Item | What remains | Effect on this result |
|---|---|---|
| Global exact-lattice guarantee | Complete outward integrals on all three charts, including the regular exterior; full matrix reconstruction; distance to the selected cached centers; operator-error budgets. | No unconditional lattice floor is claimed. Existing sufficient budgets are ||1.69 Delta g||_2<=0.020 and ||1.69 Delta Q||_2<=0.005 with exact Q PSD; only after establishing them would the checked bridge give a floor above 0.1037. |
| Reference-model scope | Proofs use unit mass/spacing, unit axial/diagonal springs, E=36/25, original X/R sources and six source sections. | Results have not been extended to the stiffness sweep, arbitrary frequencies or the full packet spectrum. |
| Finite-window readout | No phase-resolved causal identity or complete trajectory/readout error enclosure was derived. | The existing packet/direct comparison remains numerical corroboration with its original preparation, normalization and reporting window. |
| Independent replication | No second platform, independent human derivation or experiment was performed. | Successful same-host checks are not described as those forms of replication. |
| Publication | Author-attested metadata, licences, public archive/citation locations and release decisions remain as recorded in the baseline release files. | This is a private reproducible handoff; no GitHub push or publication was performed. |
| Earlier connection errors | Client transport records and exact error messages are unavailable. | Their root cause remains unknown; completed evidence and bounded replay do not depend on diagnosing it. |

Deterministic interval bounds are distinguished from floating-point diagnostics throughout. No numerical agreement is converted into a calibrated 95% probability.
