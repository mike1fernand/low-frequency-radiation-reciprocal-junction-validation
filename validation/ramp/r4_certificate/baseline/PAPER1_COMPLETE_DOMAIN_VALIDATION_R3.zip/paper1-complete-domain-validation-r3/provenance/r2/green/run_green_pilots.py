#!/usr/bin/env python3
"""Replay one cell through four levels; every subprocess has a time limit."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from green_cell_pilot import CELLS,HERE,atomic_json

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--cell',choices=CELLS,required=True)
    p.add_argument('--output-dir',type=Path,required=True)
    p.add_argument('--timeout-seconds',type=float,default=30)
    args=p.parse_args()
    if args.timeout_seconds<=0:p.error('timeout must be positive')
    args.output_dir.mkdir(parents=True,exist_ok=True)
    records=[]
    for a,n in [(1,32),(2,64),(4,128),(8,256)]:
        path=args.output_dir/f'{args.cell}_a{a}_n{n}.json'
        command=[sys.executable,str(HERE/'green_cell_pilot.py'),'--cell',args.cell,
                 '--angular',str(a),'--radial',str(n),'--output',str(path)]
        run=subprocess.run(command,text=True,capture_output=True,timeout=args.timeout_seconds)
        if run.returncode not in (0,2):
            raise RuntimeError(f'Producer failed unexpectedly: {run.stderr}')
        data=json.loads(path.read_text())
        expected=0 if data['status']=='certified_partial_cell_enclosure' else 2
        if run.returncode!=expected:raise RuntimeError('Exit code/status mismatch')
        records.append({'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                        'exit_code':run.returncode,'status':data['status'],
                        'elapsed_seconds':data['elapsed_seconds']})
    if records[-1]['status']!='certified_partial_cell_enclosure':
        raise RuntimeError('Finest cell still unresolved')
    summary={'cell':args.cell,'runs':records,'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    atomic_json(args.output_dir/f'{args.cell}_execution.json',summary)
    print(json.dumps(summary))

if __name__=='__main__':main()
