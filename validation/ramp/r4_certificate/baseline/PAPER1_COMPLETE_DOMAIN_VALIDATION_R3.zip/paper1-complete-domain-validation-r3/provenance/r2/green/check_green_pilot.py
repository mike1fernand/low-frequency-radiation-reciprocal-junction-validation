#!/usr/bin/env python3
"""Independent floating-point diagnostics and exact stored-enclosure audits.

Numerical Gaussian quadrature and height agreement are diagnostics only.
They do not supply the rigorous error radii in green_cell_pilot outputs.
"""
from fractions import Fraction
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
sys.dont_write_bytecode=True
import numpy as np
from flint import arb,acb,ctx
from green_cell_pilot import CELLS,HERE,PRIMITIVE,interval,atomic_json
from source_moments import moment_values,ball_serialization
ctx.prec=120

def exact_endpoint(obj):
    return arb((int(obj['mantissa']),int(obj['exponent2'])))

def ball_part(obj):
    lo,hi=exact_endpoint(obj['lower']),exact_endpoint(obj['upper'])
    return arb((lo+hi)/2,((hi-lo)/2).upper())

def box_ball(obj): return acb(ball_part(obj['real']),ball_part(obj['imag']))

def gauss_interval(n,lo,hi):
    x,w=np.polynomial.legendre.leggauss(n)
    return lo+(x+1)*(hi-lo)/2,w*(hi-lo)/2

def diagnostic_integral(cell,height,nradial=96,nangular=8):
    ul,uh,vl,vh=[float(Fraction(s)) for s in CELLS[cell]]
    us,uw=gauss_interval(nangular,ul,uh)
    vs,vw=gauss_interval(nangular,vl,vh)
    ss,sw=gauss_interval(nradial,0,1)
    # Independent nine-bond symbol, rather than the primitive's explicit entries.
    bonds=np.array([(1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,-1,0),
                    (1,0,1),(1,0,-1),(0,1,1),(0,1,-1)],float)
    dyads=bonds[:,:,None]*bonds[:,None,:]/np.sum(bonds*bonds,axis=1)[:,None,None]
    R=np.arccos(.25)
    legs=[(0,-1j*height),(-1j*height,R),(R-1j*height,1j*height),(R,np.pi-R)]
    answer=np.zeros(17,complex)
    leg_answers=[]
    for start,delta in legs:
        tt,uu,vv=np.meshgrid(start+delta*ss,us,vs,indexing='ij')
        t=tt.reshape(-1)
        k=np.stack([tt,tt*uu,tt*vv],axis=-1).reshape(-1,3)
        phase=k@bonds.T
        D=np.einsum('nb,bij->nij',2*(1-np.cos(phase)),dyads)
        resolvent=np.linalg.inv(D-1.44*np.eye(3))
        ky,kz=k[:,1],k[:,2]
        A=2*np.cos(ky/2)*np.cos(kz/2)
        B=np.sqrt(2)*np.sin(ky/2)*np.cos(kz/2)
        C=np.sqrt(2)*np.cos(ky/2)*np.sin(kz/2)
        Fplus=np.zeros((len(t),3,2),complex)
        Fminus=np.zeros_like(Fplus)
        Fplus[:,0,0]=Fminus[:,0,0]=A
        Fplus[:,1,1]=-1j*B;Fplus[:,2,1]=-1j*C
        Fminus[:,1,1]=1j*B;Fminus[:,2,1]=1j*C
        projected=np.einsum('naA,nab,nbB->nAB',Fminus,resolvent,Fplus)
        w=(sw[:,None,None]*uw[None,:,None]*vw[None,None,:]).reshape(-1)*delta*t*t/np.pi**3
        vals=[np.sum(w*projected[:,0,0]*np.cos(d*k[:,0])) for d in range(6)]
        vals += [np.sum(w*projected[:,1,1]*np.cos(d*k[:,0])) for d in range(6)]
        vals += [np.sum(w*1j*projected[:,0,1]*np.sin(d*k[:,0])) for d in range(1,6)]
        arr=np.array(vals)
        leg_answers.append(arr);answer+=arr
    return answer,leg_answers

def exact_x_axis_test():
    R=(arb(1)/4).acos();h=arb(1)/4;n=1024
    tL=(arb(19)/25).acos()
    legs=[(acb(0),acb(0,-h)),(acb(0,-h),acb(R)),
          (acb(R,-h),acb(0,h)),(acb(R),acb(arb.pi()-R))]
    totals=[acb(0) for _ in range(17)]
    for start,delta in legs:
        for j in range(n):
            vals=moment_values(start+delta*interval(arb(j)/n,arb(j+1)/n),arb(0),arb(0),0)
            for d in range(17):totals[d]+=delta/n*vals[d]
    exact=[4*tL*tL*(d*tL).cos()/(arb.pi()**2*6*tL.sin()) for d in range(6)]
    assert all(totals[d].imag.contains(exact[d]) for d in range(6))
    assert all(z.is_zero() for z in totals[6:])
    return {'status':'passed','radial_segments_per_leg':n,
            'analytic_spectral_formula':'4*tL^2*cos(d*tL)/(pi^2*6*sin(tL)); tL=acos(19/25)',
            'all_six_a_spectral_moments_contain_exact':True,'all_c_and_b_exactly_zero':True,
            'exact_a_spectral':list(map(ball_serialization,exact)),
            'enclosed_a_spectral':[ball_serialization(z.imag) for z in totals[:6]]}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--input-dir',type=Path,default=HERE)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    started=time.monotonic()
    output={'status':'passed','scope':'Diagnostics and same-cell outward-enclosure consistency; not global certification.',
            'cells':{},'negative_controls':{}}
    phash=hashlib.sha256(PRIMITIVE.read_bytes()).hexdigest()
    producer_hash=hashlib.sha256((HERE/'green_cell_pilot.py').read_bytes()).hexdigest()
    for cell in CELLS:
        records=[]
        for a,n in [(1,32),(2,64),(4,128),(8,256)]:
            record=json.loads((args.input_dir/f'{cell}_a{a}_n{n}.json').read_text())
            assert record['primitive_sha256']==phash and record['script_sha256']==producer_hash
            if record['status']=='certified_partial_cell_enclosure':records.append(record)
        fine=records[-1]
        bounds=list(map(box_ball,fine['moments']))
        coarse=[list(map(box_ball,r['moments'])) for r in records[:-1]]
        assert all(x.overlaps(y) for vals in coarse for x,y in zip(vals,bounds))
        rads=[max(r['max_real_radius_diagnostic'],r['max_imag_radius_diagnostic']) for r in records]
        assert all(b<a for a,b in zip(rads,rads[1:])), 'enclosure radii failed to contract'
        d1,l1=diagnostic_integral(cell,.25)
        d2,l2=diagnostic_integral(cell,.125)
        heightdiff=float(np.max(np.abs(d1-d2)))
        assert heightdiff<1e-11,'independent contour-height diagnostic differs'
        inside=all(b.contains(acb(float(z.real),float(z.imag))) for d in (d1,d2) for b,z in zip(bounds,d))
        assert inside,'independent quadrature outside outward enclosure'
        exterior=list(map(box_ball,fine['leg_moments']['regular_exterior']))
        assert all(b.imag.is_zero() for b in exterior),'exterior should be real'
        assert d1[0].imag>0 and d1[6].imag>0,'diagonal spectral sign wrong'
        output['cells'][cell]={
            'maximum_radius_sequence':rads,'certified_levels':len(records),
            'two_height_max_abs_difference_diagnostic':heightdiff,
            'independent_quadrature_inside_all_17_enclosures':inside,
            'exterior_exactly_real':True,
            'imaginary_a0_c0_diagnostic':[float(d1[0].imag),float(d1[6].imag)],
            'quadrature_17_moments_diagnostic':[[float(z.real),float(z.imag)] for z in d1],
            'fine_max_radius_divided_by_cell_area_diagnostic':rads[-1]/float((Fraction(CELLS[cell][1])-Fraction(CELLS[cell][0]))*(Fraction(CELLS[cell][3])-Fraction(CELLS[cell][2]))) }
    output['exact_x_axis']=exact_x_axis_test()
    output['script_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    output['producer_sha256']=producer_hash
    output['primitive_sha256']=phash
    output['elapsed_seconds']=time.monotonic()-started
    atomic_json(args.output,output)
    print(json.dumps({cell:{k:v for k,v in r.items() if k!='quadrature_17_moments_diagnostic'} for cell,r in output['cells'].items()},indent=2))

if __name__=='__main__':main()
