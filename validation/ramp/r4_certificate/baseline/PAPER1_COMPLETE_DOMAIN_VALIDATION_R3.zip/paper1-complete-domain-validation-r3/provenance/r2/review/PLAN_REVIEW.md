# Independent continuation-plan review

The present Paper 1 claim does not require an unconditional lattice floor: its selected numerical conversion and strict stored-matrix floor already have their stated scope. This continuation is a bounded attempt to remove the remaining integration limitation. Preserve the paper and accepted matrices unless a complete, independently checked enclosure establishes a stronger result. Do not repeat the completed N160 campaign.

## Material improvement: a fixed radial separator

The proposed per-cell root/projector tracking can be replaced by a globally valid contour split for the reference bare bulk. Let a be any real pyramid direction with max_i |a_i|=1, t0=acos(3/4), and R=acos(1/4). At t0, all cos(t0 a_i) lie in [3/4,1]. In the proved decomposition D/2=diag(d_i)+ss^T,

    d_i = 2+c_i^2-c_i(1+c_j+c_k)
        <= 2+c_i^2-(5/2)c_i <= 11/16.

The final bound follows from convexity and its endpoint values 11/16 and 1/2. Rank-one interlacing gives lambda_2(D)<=11/8. For an index with |a_i|=1, D_ii>=6(1-3/4)=3/2, so lambda_3(D)>=3/2. At E=36/25,

    lambda_2(t0)<=E-13/200,  lambda_3(t0)>=E+3/50.

By the established real radial monotonicity, exactly the highest-branch pole lies in (0,t0), and exactly the lower-two poles, with multiplicity, lie in (t0,R). This includes plane, axis and body-diagonal degeneracies. The constants were also checked with exact Fraction arithmetic in this review; the algebra and interlacing argument, not sampling, justify the global conclusion. The coordinating agent should independently challenge this lemma before using it.

For z=x+iy with 0<x<=R and y nonzero,

    Im D(z a) = 2 sum_b sin(x a.b) sinh(y a.b) n_b n_b^T.

All nonzero coefficients have the sign of y because |x a.b|<=2R<pi. The active axial and diagonal bond directions span R^3 for every such a. Hence Im D is strictly definite and D-E has no nonreal zeros in this strip. At x=0, D(iy a) is negative semidefinite, so D-E is invertible as well. This makes a fixed contour route feasible without continuing individual eigenvectors or applying an unproved complex eigenvalue gap.

The accepted producer uses (D-E-i0)^(-1) with positive spectral imaginary part. Therefore use a LOWER radial detour. The complete interior Green integral is the path 0 -> -ih -> R-ih -> R; the nonsingular exterior is R -> pi. For the lower-two spectral integral use t0 -> t0-ih -> R-ih -> R. Its imaginary part is exactly the qT residue sum times pi. Equivalently, integrate a positively oriented closed rectangle around (t0,R) and divide by 2i. The latter equivalence follows from Schwarz symmetry of the real-axis 17 moment formulas. The lower detour already includes both endpoint contributions and the principal value; it does not require separate subtraction and logarithm code. Do not omit either vertical endpoint segment.

## Required acceptance gates

1. **Freeze the problem.** Bind E=36/25, actual source moments, m=1, all bulk springs=1, chart definitions, target dyadic matrices, precision, code hashes and contour height. No frequency sweep or new physics is covered.
2. **Verify conventions before integration.** Compare the analytic source-moment formulas with the existing producer on nonsingular real inputs, including all 17 moments and all three charts. Verify the positive-octant factor 8/(2pi)^3=1/pi^3 and t^2 Jacobian. The physical x source axis is not permuted with a chart. Complex continuation uses the holomorphic real-axis formulas, not a conjugated complex source.
3. **Test the claimed contour identity.** Use an exactly integrable simple-pole example with unequal endpoint distances, a nonconstant numerator/Jacobian, and the declared orientation. Test the retarded imaginary sign and real logarithmic term. A midpoint diagnostic or finite-eta agreement alone does not establish this identity.
4. **Certify whole pilot cells.** Use nonzero-area ordinary, coordinate-plane-touching, axis-touching and body-diagonal-touching angular boxes. Every contour segment and real exterior interval must be covered by outward interval enclosures, including all angular values. A verified finite inverse at sampled nodes is insufficient. Count covered boxes and record exact parameter bounds; refuse nonfinite inverse enclosures. Geometry degeneracies must be contained, not replaced by measure-zero point checks.
5. **Measure useful contraction.** Repeat each cell with a refined cover and, if necessary, a higher precision. Each run must independently enclose the actual cell integral. Proven child integrals may be summed and intersected with a proven parent enclosure; an empty intersection is a stop-and-diagnose condition. Record raw and intersected widths, runtime and box count. Only outward widths measure certification progress; ordinary mesh differences remain diagnostics.
6. **Choose the global method from the pilot evidence.** A complete cover is warranted only if the projected proven moment-error budget and cost are practical. Otherwise record exactly which method or bound failed and stop without weakening the required claim. Do not launch uniform refinement merely because previous work is already invested. A valid but very wide enclosure is a valid pilot, not a usable certificate.
7. **If proceeding globally, close the actual target.** Cover all three pyramid charts and the real exterior; bind every checkpoint to the same problem and nonoverlapping coverage ledger. Assemble every Toeplitz occurrence and signed X/R term into the 12x12 matrices. Include enclosure-center displacement from the actual stored matrices. Only proven ||1.69 Delta g||_2<=0.020 and ||1.69 Delta Q||_2<=0.005, with exact Q PSD, activate the existing >0.1037 bridge. A failed budget does not invalidate the stored-matrix >0.108 certificate.
8. **Delivery check.** Fresh-extract and run the bounded new checks with external outputs, verify source/manuscript identities and archive contents, and preserve exact interval endpoints. Do not call the optional stronger theorem completed when only pilots or prerequisites have been established.

## Referee priorities and stopping conditions

The essential present-paper obligations are truthful scope, reproducibility of its claimed numerical result, and clarity about the stored-matrix floor. The new contour route is a potentially substantial mathematical improvement to validation, but is optional until a stronger paper claim is made. A successful four-cell pilot is useful evidence of feasibility; it does not establish a full-zone certificate. A full reference-frequency certificate would still not establish an exact finite-time readout identity or a whole-packet-frequency guarantee.

No extra manuscript safeguards are justified while the claim stays unchanged. Keep the existing concise qualification near the floor; place proof development, run logs and conditional outcomes in the validation materials. The supplied papers support complete root accounting, joint treatment of tied modes and source-consistent transformations. They do not supply Paper 1's missing integral bounds or validate the new contour route by analogy.

This review inspected the saved plan/results, radial proof, prior certification assessment, scalar resolvent producer and new source-moment implementation. It performed exact rational arithmetic on the new separator constants. It did not execute contour quadrature, verify interval-library internals, inspect a final global cover, or run a second platform. The key contour and separator lemmas require a separate mathematical review before they carry a certificate.

## Second and open passes on the written plan

The subsequently supplied `../PLAN.md` incorporates the corrected retarded convention, the global separator, fixed-domain full-cell contraction tests, source/chart normalization, conditional global budget and preservation of completed work. No material issue was identified in its stage gates. Stage 4 correctly permits replacement of a slow enclosure algorithm; naive interval range integration is a proof/debugging baseline, not a requirement for the final global method.

One higher-order option is validated tensor Gauss quadrature with a Cauchy/Taylor remainder. It requires a proved analytic bound on the complex neighborhoods used by its actual remainder formula. The real-angular-direction no-pole argument does not prove invertibility for complex u,v. A verified finite inverse over each required complex neighborhood can prove invertibility and bound each moment there; failure of this bound calls for subdivision or a sharper inverse bound, not acceptance from real samples.

The preferred proposed remainder uses one complex coordinate at a time and avoids requiring an entire product of complex discs. For normalized integration I_j and positive Gauss quadrature Q_j, the telescoping identity in three variables is

    I1 I2 I3 - Q1 Q2 Q3
      = (I1-Q1) I2 I3 + Q1 (I2-Q2) I3 + Q1 Q2 (I3-Q3).

If |f|<=M_j when coordinate j lies in its complex disc |z_j|<=rho_j>1 and ALL other coordinates range over their real [-1,1] intervals, then each real averaging operator has norm at most one. Cauchy coefficient bounds and Gauss exactness through degree 2n_j-1 give the sufficient total normalized error

    sum_j 2 M_j rho_j^(-2 n_j) / (1-rho_j^(-1)).

This was independently checked algebraically in the second review. Crucially, M_j must enclose all real values of other coordinates, not merely their quadrature nodes. Holomorphy and boundedness are uniform over those other real coordinates, which also justify the averaged analytic functions. Multiply by the physical box measure, with contour differential handled consistently. This route does not require simultaneous complex continuation of every coordinate.

For comparison, a sufficient but unnecessarily stronger alternative assumes that the integrand is holomorphic on the closed product discs |z_i|<=rho_i>1, with |f|<=M. For exact n_i-node Gauss rules, its conservative error bound is

    2 M [1 - product_i(1-rho_i^(-2 n_i))]
        / product_i(1-rho_i^(-1)).

This follows by Cauchy coefficient bounds and summing all Taylor monomials not integrated exactly; both normalized integration and positive Gauss quadrature have norm at most one. Multiply by the actual box measure and contour differential, as appropriate to the chosen integrand definition. Outward node, weight, arithmetic and analytic-bound errors must be enclosed separately. This formula is a derived candidate, not an executed quadrature certificate or a claim about runtime. A sharper validated remainder is acceptable if its hypotheses are actually checked.

The open referee question is whether the additional result changes the paper's physical conclusion enough to justify manuscript space. Even successful global bounds would certify the reference stationary lattice floor, not the direct finite-window observable or every packet frequency. Present the mathematical gain in those terms. A rigorous lower floor above 0.1037 can be valuable even though it is below the stored-matrix 0.108 floor; it should not be described as an improved numerical conversion efficiency. Until a full certificate exists, the plan's decision to keep this development in validation materials is appropriate.
