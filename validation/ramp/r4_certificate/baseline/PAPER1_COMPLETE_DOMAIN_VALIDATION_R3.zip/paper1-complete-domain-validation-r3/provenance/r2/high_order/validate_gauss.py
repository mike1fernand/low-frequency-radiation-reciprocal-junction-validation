#!/usr/bin/env python3
"""Manufactured-function checks of the certified tensor quadrature."""
import argparse,json,hashlib
from pathlib import Path
from flint import arb,acb,ctx
from certified_gauss import gauss3_box
ctx.prec=128
checks=[]
root=(arb(3)/5).sqrt();nodes=[-root,arb(0),root];weights=[arb(5)/18,arb(4)/9,arb(5)/18]
checks.append({'name':'positive_weights','passed':all(w>0 for w in weights)})
for k in range(6):
    q=sum(w*x**k for w,x in zip(weights,nodes));expected=arb(0) if k%2 else arb(1)/(k+1)
    checks.append({'name':'normalized_GL_exact_degree_'+str(k),'passed':q.contains(expected)})
b=[(arb(-1),arb(1))]*3
# Closed-form integral, rational poles outside every selected disk.
def rational(x,y,z):return [1/((5-x)*(6-y)*(7-z))]
val,meta=gauss3_box(rational,b,(2,3))
expected=(arb(6)/4).log()*(arb(7)/5).log()*(arb(8)/6).log()
checks.append({'name':'separable_rational_integral','passed':val[0].real.contains(expected) and val[0].imag.contains(0),'details':meta})
# Degree 6 exceeds GL3 exactness: this checks a genuinely nonzero remainder.
def sixth(x,y,z):return [x**6+y**6+z**6]
val,meta=gauss3_box(sixth,b,(2,4))
checks.append({'name':'degree6_remainder','passed':val[0].real.contains(arb(24)/7) and val[0].imag.contains(0),'details':meta})
# Polynomial maximum degree 5 per variable, exact tensor GL degree.
def fifth(x,y,z):return [1+x**4*y**2*z**4+x**5+y**3+z]
val,meta=gauss3_box(fifth,b,(2,4))
checks.append({'name':'tensor_degree5','passed':val[0].real.contains(8+arb(8)/75) and val[0].imag.contains(0),'details':meta})
# Pole lies in the complex disk but outside the real integration interval.
def pole(x,y,z):return [1/(x-acb(0,arb(1)/10))]
try:
    gauss3_box(pole,b,(2,4));blocked=False
except ArithmeticError:blocked=True
checks.append({'name':'reject_unenclosed_pole','passed':blocked})
# Nontrivial narrow-box integral, with a useful accuracy threshold.
h=arb(1)/100
val,meta=gauss3_box(rational,[(-h,h)]*3,(8,16,32))
expected=arb(1)
for c in [5,6,7]:expected*=((c+h)/(c-h)).log()
checks.append({'name':'narrow_rational_tight_enclosure','passed':val[0].real.contains(expected) and val[0].imag.contains(0) and val[0].real.rad()<arb('1e-12'),'details':meta})
out={'precision_bits':ctx.prec,'checks':checks,'passed':all(x['passed'] for x in checks),
     'source_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in [Path(__file__),Path(__file__).with_name('certified_gauss.py')]}}
p=argparse.ArgumentParser();p.add_argument('--output',default=str(Path(__file__).with_name('MANUFACTURED_CHECKS.json')));a=p.parse_args()
p=Path(a.output);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
if not out['passed']:raise SystemExit(2)
