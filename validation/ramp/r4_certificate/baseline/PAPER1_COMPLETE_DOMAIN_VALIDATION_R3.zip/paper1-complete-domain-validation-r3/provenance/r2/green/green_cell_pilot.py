#!/usr/bin/env python3
"""Outward full-Green integrals on four *partial* angular cells.

This is a rectangular interval Riemann integration. Each function evaluation
contains the entire three-dimensional input box. It does not estimate an
error from point samples or convergence differences. None of these cells is
a full chart or Brillouin-zone cover.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PRIMITIVE = HERE.parent / 'pilot' / 'source_moments.py'
sys.path.insert(0, str(PRIMITIVE.parent))
from flint import arb, acb, ctx
from source_moments import moment_values, ball_serialization

CELLS = {
    'ordinary': ('3/8','7/16','5/8','11/16'),
    'plane': ('7/16','1/2','0','1/32'),
    'axis': ('0','1/32','0','1/32'),
    'body': ('31/32','1','31/32','1'),
}

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def atomic_json(path,result):
    path.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='w',dir=path.parent,prefix=path.name+'.',suffix='.tmp',delete=False) as f:
        temporary=f.name
        json.dump(result,f,indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())
    os.replace(temporary,path)

def interval(lo, hi):
    return arb((lo+hi)/2, ((hi-lo)/2).upper())

def integrate_cell(name, angular, radial, height):
    lo_u, hi_u, lo_v, hi_v = map(arb, CELLS[name])
    du, dv = (hi_u-lo_u)/angular, (hi_v-lo_v)/angular
    R=(arb(1)/4).acos()
    h=arb(height)
    legs=[('inner_down',acb(0),acb(0,-h)),
          ('inner_across',acb(0,-h),acb(R)),
          ('inner_up',acb(R,-h),acb(0,h)),
          ('regular_exterior',acb(R),acb(arb.pi()-R))]
    # Parameterization keeps uncertain transcendental endpoints outward.
    leg_totals={}
    for label, start, delta in legs:
        total=[acb(0) for _ in range(17)]
        weight=delta*du*dv/radial
        for iu in range(angular):
            u=interval(lo_u+iu*du,lo_u+(iu+1)*du)
            for iv in range(angular):
                v=interval(lo_v+iv*dv,lo_v+(iv+1)*dv)
                for it in range(radial):
                    s=interval(arb(it)/radial,arb(it+1)/radial)
                    vals=moment_values(start+delta*s,u,v,chart=0)
                    for j in range(17): total[j]+=weight*vals[j]
        leg_totals[label]=total
    total=[sum((v[j] for v in leg_totals.values()),acb(0)) for j in range(17)]
    return total,leg_totals

def scalar_checks():
    # t^2/(t-a) on [0,b], a=1/2,b=2. The PV includes a^2 log 3.
    a,b=arb(1)/2,arb(2)
    exact=acb(b*b/2+a*b+a*a*((b-a)/a).log(),arb.pi()*a*a)
    out=[]
    for sign in (-1,1):
        for n in (128,512):
            h=arb(1)/4
            legs=[(acb(0),acb(0,sign*h)),
                  (acb(0,sign*h),acb(b)),
                  (acb(b,sign*h),acb(0,-sign*h))]
            val=acb(0)
            for start,delta in legs:
                for j in range(n):
                    t=start+delta*interval(arb(j)/n,arb(j+1)/n)
                    val+=delta/n*t*t/(t-a)
            target=exact if sign==-1 else exact.conjugate()
            assert val.contains(target),'scalar exact integral is not enclosed'
            omitted=acb(b*b/2+a*b,target.imag)
            wrongsign=target.conjugate()
            if n==512:
                assert not val.overlaps(omitted),'omitted endpoint logarithm escaped negative test'
                assert not val.overlaps(wrongsign),'retarded-sign reversal escaped negative test'
            out.append({'path_half_plane':'lower' if sign==-1 else 'upper',
                        'segments_per_leg':n,'enclosure':ball_serialization(val),
                        'contains_exact':True,'endpoint_log_omission_overlaps':val.overlaps(omitted),
                        'wrong_retarded_sign_overlaps':val.overlaps(wrongsign)})
    return {'status':'passed','exact_lower_contour':ball_serialization(exact),
            'formula':'b^2/2+a*b+a^2*log((b-a)/a)+i*pi*a^2; a=1/2,b=2',
            'runs':out}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--cell',choices=CELLS)
    p.add_argument('--angular',type=int,default=1)
    p.add_argument('--radial',type=int,default=32)
    p.add_argument('--height',default='1/4')
    p.add_argument('--precision',type=int,default=120)
    p.add_argument('--scalar-only',action='store_true')
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    if args.angular<=0 or args.radial<=0 or args.precision<80:
        p.error('angular/radial subdivisions must be positive and precision at least 80 bits')
    ctx.prec=args.precision
    if not arb(args.height)>0:
        p.error('contour height must be strictly positive')
    if args.scalar_only and args.cell is not None:
        p.error('--scalar-only and --cell are mutually exclusive')
    if not args.scalar_only and args.cell is None:
        p.error('--cell is required unless --scalar-only is specified')
    started=time.monotonic()
    identity={'script_sha256':sha(Path(__file__)), 'primitive_sha256':sha(PRIMITIVE),
              'precision_bits':ctx.prec,'energy':'36/25','chart':0,
              'normalization':'1/pi^3','radial_jacobian':'t^2'}
    if args.scalar_only:
        result=scalar_checks()
    else:
        assert args.cell is not None
        try:
            total,legs=integrate_cell(args.cell,args.angular,args.radial,args.height)
            result={'status':'certified_partial_cell_enclosure',
                    'cell':args.cell,'angular_endpoints':CELLS[args.cell],
                    'angular_parts_per_axis':args.angular,'radial_parts_per_leg':args.radial,
                    'contour_height':args.height,
                    'box_evaluations':4*args.angular**2*args.radial,
                    'moments':list(map(ball_serialization,total)),
                    'leg_moments':{k:list(map(ball_serialization,v)) for k,v in legs.items()},
                    'max_real_radius_diagnostic':max(float(x.real.rad()) for x in total),
                    'max_imag_radius_diagnostic':max(float(x.imag.rad()) for x in total),
                    'scope':'Only this positive-area cell in x chart; no global error bound.'}
        except (ZeroDivisionError,ArithmeticError) as e:
            result={'status':'unresolved_interval_inversion','cell':args.cell,
                    'angular_parts_per_axis':args.angular,'radial_parts_per_leg':args.radial,
                    'error':str(e)}
    result.update(identity)
    result['elapsed_seconds']=time.monotonic()-started
    atomic_json(args.output,result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('moments','leg_moments','runs','exact_lower_contour')},sort_keys=True))
    if result['status']=='unresolved_interval_inversion':
        sys.exit(2)

if __name__=='__main__':main()
