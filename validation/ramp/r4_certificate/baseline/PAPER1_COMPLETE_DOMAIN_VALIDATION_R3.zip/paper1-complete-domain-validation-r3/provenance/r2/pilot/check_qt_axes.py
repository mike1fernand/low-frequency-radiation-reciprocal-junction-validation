#!/usr/bin/env python3
"""Exact analytical axis targets versus rigorous contour enclosures.

These are zero-angular-area identity tests, separate from the full-cell pilots.
They verify source orientation, residue normalization, and the retarded sign.
"""
from pathlib import Path
import hashlib,json,time
from flint import arb,acb,ctx
from source_moments import moment_values,ball_serialization
from qt_cell_pilot import interval
ctx.prec=128
s=(arb(3)/4).acos();R=(arb(1)/4).acos();h=arb(1)/8
points=[acb(s),acb(s,-h),acb(R,-h),acb(R)]
n=1024
start=time.monotonic();rows=[]
tT=(arb(7)/25).acos()
axis_a=4*(tT/2).cos()**2*tT*tT/(arb.pi()**2*2*tT.sin())
for chart in range(3):
 total=[acb(0) for _ in range(17)]
 for a,b in zip(points[:-1],points[1:]):
  for i in range(n):
   r=interval(arb(i)/n,arb(i+1)/n)
   vals=moment_values(a+(b-a)*r,arb(0),arb(0),chart)
   for m,val in enumerate(vals):total[m]+=val*(b-a)/n
 enclosed=[x.imag for x in total]
 expected=[axis_a if chart!=0 and i<6 else arb(0) for i in range(17)]
 assert all(x.contains(y) for x,y in zip(enclosed,expected))
 wrong_sign_rejected=(chart==0) or all(not x.overlaps(-axis_a) for x in enclosed[:6])
 wrong_pi_rejected=(chart==0) or all(not x.overlaps(axis_a/arb.pi()) for x in enclosed[:6])
 assert wrong_sign_rejected and wrong_pi_rejected
 rows.append({'chart':chart,'all_17_analytic_targets_contained':True,
 'wrong_retarded_sign_rejected':None if chart==0 else wrong_sign_rejected,
 'missing_factor_pi_rejected':None if chart==0 else wrong_pi_rejected,
 'exact_analytic_targets':[ball_serialization(x) for x in expected],
 'contour_enclosures':[ball_serialization(x) for x in enclosed]})
out={'status':'passed','scope':'zero-angular-area exact axis tests, not cell integration',
 'precision_bits':ctx.prec,'segments_per_edge':n,'seconds':time.monotonic()-start,
 'checks':rows,'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()
 for p in (Path(__file__),Path(__file__).with_name('source_moments.py'),Path(__file__).with_name('qt_cell_pilot.py'))}}
p=Path(__file__).with_name('results')/'QT_AXIS_CHECKS.json';p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'passed','seconds':out['seconds'],'checks':[{'chart':r['chart'],'all_17_analytic_targets_contained':True} for r in rows]},indent=2))
