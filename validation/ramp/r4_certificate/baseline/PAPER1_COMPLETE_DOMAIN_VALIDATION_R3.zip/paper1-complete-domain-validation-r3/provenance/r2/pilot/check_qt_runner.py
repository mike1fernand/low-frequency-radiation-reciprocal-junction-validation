#!/usr/bin/env python3
"""Final runner input rejection, atomic-output, and unchanged-numerics checks."""
from pathlib import Path
import hashlib,json,subprocess,sys
base=Path(__file__).resolve().parent
script=base/'qt_cell_pilot.py';results=base/'results'
cases=[('zero_angular',['--angular-n','0']),('negative_contour',['--contour-n','-1']),
 ('zero_height',['--height','0']),('negative_height',['--height=-1/8']),
 ('low_precision',['--bits','32']),('bad_chart',['--chart','3'])]
rows=[]
for name,options in cases:
 out=results/f'qt_invalid_{name}.json'
 r=subprocess.run([sys.executable,str(script),'--cell','ordinary','--output',str(out),*options],capture_output=True,text=True)
 assert r.returncode==2,(name,r.returncode,r.stderr)
 j=json.loads(out.read_text());assert j['status']=='failed_execution'
 assert not out.with_name(out.name+'.tmp').exists()
 rows.append({'case':name,'rejected':True,'exit_code':r.returncode,'error':j['error']})
original=json.loads((results/'qt_ordinary_a2_c128.json').read_text())
replay=json.loads((results/'qt_final_runner_positive_replay.json').read_text())
assert original['moments']==replay['moments']
assert original['source_sha256']['qt_cell_pilot.py']==hashlib.sha256((results/'qt_cell_pilot.py.snapshot').read_bytes()).hexdigest()
assert replay['source_sha256']['qt_cell_pilot.py']==hashlib.sha256(script.read_bytes()).hexdigest()
out={'status':'passed','invalid_cases':rows,'positive_replay_all_17_serialized_moments_bit_identical':True,
 'historical_numerical_runner_snapshot_matches_record':True,'final_runner_matches_replay_record':True,
 'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__),script)}}
(results/'QT_RUNNER_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
