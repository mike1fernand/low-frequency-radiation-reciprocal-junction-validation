# Paper 1: resolution of the remaining validation issues

## Implemented result

The review found no new load-bearing error in RC4's physical model or selected numerical result. The implementation strengthens the validation evidence while preserving the approximately 12.6% incident-qT conversion, the selected surface packet prediction, and the paper's length. It also closes several concrete mathematical prerequisites for a future exact-lattice certificate.

### Complete packet refinement

The complete N160 tetrahedron campaign freshly evaluated all 14 occupied finite-DFT frequencies and both unweighted comparison endpoints, through 63 validated checkpoints. Actual shared integration took 1,705.99 seconds. The previously missing eight occupied nodes are now included at the same resolution.

| Calculation | Full-energy-normalized packet contribution |
|---|---:|
| Retained tetrahedron N96 | 0.1275675619 |
| Retained tetrahedron N128 | 0.1275946687 |
| Fresh complete tetrahedron N160 | 0.1276094196 |
| Selected surface N160 | 0.1276730185 |

The N128-to-N160 weighted absolute nodewise change is **0.01218% of the N160 tetrahedron sum**; the signed change is 0.01156%. The complete third grid therefore meets the predeclared 0.05% successive-refinement target. The new tetrahedron-to-surface weighted absolute difference is **0.04981% of the selected surface sum**. Neither difference is a rigorous integration-error bound.

Ordered summation of the 63 checkpoints reproduced all 128 stored kernel arrays bit-for-bit. Six freshly evaluated frequencies overlapped the retained N160 campaign, with maximum matrix relative difference 7.003e-18. A separate 19-coordinate solve agreed with the eliminated solve to 1.221e-15, and maximum flux-closure residual was 1.489e-11. A separately written checker reconstructed the 120-point DFT directly from q/v and used 60-digit decimal arithmetic for the 14 weighted sums and absolute differences; it confirmed the results above.

The review caught a validation gap: separately checking checkpoint and kernel hashes did not prove that one produced the other. The new checker now reconstructs every final kernel from the checkpoints. A deliberately changed checkpoint, even with its adjacent hash updated, was rejected. The original evidence was preserved.

The selected surface N160 prediction remains 0.12767301846182993. Its difference from the retained direct window average is approximately 0.0365%, with the same prepared displacement and velocity, full-energy denominator and blind 52.8–55.4 window. No arrival correction, fitted window or method selection based on proximity to the trajectory was introduced. The new tetrahedron result is an additional numerical comparison, not an error bar for the selected answer.

### Exact reference-shell mathematics

The bare bulk admits the exact decomposition

\[
D/2=\operatorname{diag}(d_i)+ss^T,\qquad
d_i=2+c_i^2-c_i(1+c_j+c_k),
\]

where \(c_i=\cos k_i\) and \(s_i=\sin k_i\). From the actual bond sum and this decomposition, the new proof establishes at \(E=\omega^2=36/25\):

- Every branch's energy shell lies inside \(|k_i|<R=\arccos(1/4)\). Outside that cube, \(D-EI\succeq(3/50)I\).
- Every ordered branch crosses the reference energy exactly once along every radial direction, counting coincident lower roots with multiplicity. The radial slope at a shell is at least \(24/(25\sqrt5)\simeq0.429325\), including the appropriate one-sided slopes at a multiple root.
- The highest branch is separated from the lower-two cluster by at least \(18/125=0.144\) on the union of those shells.

These are analytic bounds for Paper 1's unit-spacing, unit-mass, equal-unit-stiffness bare bulk. They do not cover the changed-stiffness sweep or all packet frequencies. Lower-pair degeneracies remain allowed; the proof does not assign smooth individual eigenvectors through them.

Two separately written checkers tested the derivation, including exact polynomial identities, explicit bond assembly, cube-boundary equality cases, axes, near-axis directions, root residuals and radial derivative factors. The global conclusions follow from the analytic inequalities and eigenvalue arguments. The finite numerical samples are checks for mistakes, not the basis for claiming complete domain coverage. The full derivation, checked constants and execution records are in the validation extension.

The improved certification plan can now use radial roots on three maximum-coordinate pyramids per octant, with their actual source factors and Jacobian. It no longer needs an unproved assumption that a mesh found every sheet. It still needs an outward enclosure of the resulting integrals.

### Reproduction with different numerical dependencies

The bounded checks were executed with NumPy/SciPy 2.3.5/1.17.0 and 2.2.6/1.15.3. Both used Python 3.12 on the same host. The 16 freshly computed N12 matrix arrays at two frequencies, compared packet and finite-response quantities, and selected reference coefficient agreed exactly in these runs. Both environments also reproduced the same 160-bit finite-matrix certificate: 64 coupling-box vertices, 5,987 positive LDL pivots, and a floor strictly above 27/250.

The original exact-version gate correctly rejects the alternate environment's two changed pins. That expected rejection is recorded; it is not reported as a pass of the original locked-environment profile. The proof used the same Flint version, so this is not an independent implementation of interval arithmetic or a second-platform replication.

## Use of the supplied papers and manuscript decision

The supplied papers helped identify the necessary checks for complete root counting, tied modes, source and boundary conventions, and the actual time-domain readout. The new shell and gap results were derived from Paper 1's own equations. Donor numerical results were not used as evidence for them. The source review also checked later superseding notes, avoiding an obsolete donor diagnosis that would have suggested an unjustified extra self-energy term.

No additional physical ingredient is supported. The operational-duration paper's readout-stability method instead clarifies what a stronger finite-time statement would require: a genuine trajectory-error enclosure propagated through the actual quadratic qT readout, together with window integration and normalization errors.

The added evidence belongs in the validation package. RC4 already states the two consequential limitations near the affected claims: the floor uses specified computed matrices, and stationary spectral power is distinct from finite-window stored energy. Repeating that qualification around every result, or importing the donors' audit histories, would make the physical argument harder to follow. The main paper and supplement therefore remain byte-for-byte unchanged.

This placement is also consistent with the inspected published examples: essential applicability limits stay beside the method in [Ong's phonon-scattering paper](https://arxiv.org/pdf/1811.02732), convergence evidence stays with results while detailed algorithms move to appendices in [Kawamura and colleagues' tetrahedron paper](https://arxiv.org/pdf/2203.15648), and approximation limits motivate the relevant kernel choices in [Weiße and colleagues' KPM review](https://arxiv.org/pdf/cond-mat/0504627). This is an editorial inference from those examples, not a universal journal rule. The exact passages read are recorded in the extension.

## Remaining uncertainty and its effect

| Issue | Present consequence | Disposition |
|---|---|---|
| Exact lattice Green and qT integration errors | The strict 10.8% box floor remains a certificate for the selected stored matrices. It is not an unconditional infinite-lattice floor. | Future theorem unless that stronger guarantee becomes a paper claim. The new shell/root/gap proof closes prerequisites, not the integration errors. |
| Exact relation to the finite-time direct readout | The packet comparison remains numerical corroboration. Its 0.0365% discrepancy is not a proved total error. | Retain the current claim. A stronger relation requires phase-resolved response or a rigorously enclosed trajectory and the same readout. |
| True discretization error | Grid and method differences are observed sensitivities; cancellation-free differences help diagnose them but do not bound the true continuum integral. | Keep the existing rounded physical result and separate time-step, box and cadence checks. No calibrated 95% probability is inferred. |
| Other environments and people | The new dependency check covers two stacks on one host, using shared algorithms. | Second-platform and independent-person reproduction remain unperformed. |
| Public release preparation | This is a private validation handoff. | Resolve publication metadata, licences and archive/citation locations before public release; no publication or GitHub push was performed. |

An exact-lattice guarantee would next require a complete outward angular/radial integration, correctly weighted clustered residues, principal-value subtraction and endpoint terms, the regular exterior contribution, and assembly into bounds for the full source-projected matrices. Only then can the existing conditional bridge be invoked with \(\|1.69\Delta g\|_2\le0.020\) and \(\|1.69\Delta Q\|_2\le0.005\), together with positive-semidefinite exact Q. Under those hypotheses it would supply a floor above 0.1037 throughout the same box. The required integration-error inequalities have not been established here.

No new full direct trajectory, full changed-stiffness campaign, whole-band rigorous certificate or independent external review was performed. Their retained records were not relabelled as new runs. The independent analytic review here means a separate derivation/checking task, not an independent human reviewer.

## Delivery and scope of verification

The extension includes the reviewed plan, new code and exact inputs, small checkpoints and outputs, source hashes, donor-source map, analytic proof, independent checks and reproduction commands. Adding evidence changes the repository input identity, so its required execution records are regenerated against the final package instead of reusing RC4 records as if they validated the extension. Large regenerable geometry arrays and installed environments are omitted. The companion delivery-check record identifies the actual final archive and fresh-extraction checks; it is separate to avoid a self-referential archive hash.

The review began with load-bearing claims, then checked numerical provenance and reproduction, and finished with an open referee pass on physical significance and manuscript clarity. It is a targeted review, not an exhaustive one. Further numerical refinement is not warranted solely to add decimals if it does not change the rounded conclusion.
