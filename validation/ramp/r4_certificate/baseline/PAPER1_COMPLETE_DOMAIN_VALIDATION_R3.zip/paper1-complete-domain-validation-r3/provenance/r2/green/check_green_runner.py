#!/usr/bin/env python3
"""Check CLI rejection before creating a result; does not run physics."""
import argparse
import hashlib
from pathlib import Path
import subprocess
import sys
import tempfile
from green_cell_pilot import HERE,atomic_json

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    checks=[]
    with tempfile.TemporaryDirectory() as temp:
        path=Path(temp)/'must_not_exist.json'
        for options in [ ['--cell','ordinary','--height','0'],
                         ['--cell','ordinary','--height','-1/4'],
                         ['--scalar-only','--cell','ordinary'],
                         ['--angular','0','--cell','ordinary'],
                         ['--precision','40','--cell','ordinary'],
                         [] ]:
            run=subprocess.run([sys.executable,str(HERE/'green_cell_pilot.py'),*options,
                                '--output',str(path)],capture_output=True,text=True,timeout=10)
            assert run.returncode==2 and not path.exists()
            checks.append({'arguments':options,'exit_code':run.returncode,
                           'no_output_written':True,'stderr':run.stderr})
    result={'status':'passed','checks':checks,
            'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'producer_sha256':hashlib.sha256((HERE/'green_cell_pilot.py').read_bytes()).hexdigest()}
    atomic_json(args.output,result)
    print('All six CLI rejection checks passed; no invalid result was written.')

if __name__=='__main__':main()
