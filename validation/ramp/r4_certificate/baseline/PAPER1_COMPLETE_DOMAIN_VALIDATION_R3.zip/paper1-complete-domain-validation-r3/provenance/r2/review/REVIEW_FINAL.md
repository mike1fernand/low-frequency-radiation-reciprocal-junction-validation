# Independent final code and proof review

**Result:** no material mathematical error was identified in the reviewed contour construction, source-moment implementation, interval box integration, or Cauchy-bounded three-point Gauss implementation. This is a scoped AI-assisted review on the same host. It does not establish a full-domain lattice certificate or an independent-person/platform replication.

## Load-bearing proof checks

The review rederived the global separator and checked the exact endpoint margins. At s=acos(3/4), rank-one interlacing gives lambda_2<=11/8 while the maximum-coordinate diagonal gives lambda_3>=3/2. With E=36/25 the margins are 13/200 and 3/50. Combined with the preceding radial shell theorem, this places exactly the lower two poles in (s,R), including multiplicity, for every chart direction. No differentiability of individual lower eigenvectors is assumed.

The nonreal-pole exclusion is valid: every active bond contribution to the Hermitian imaginary part has the sign of Im t on 0<Re t<=R, because all real bond phases have magnitude below pi. The active bond vectors span three dimensions. The Re t=0 boundary is separately nonsingular because D there is negative semidefinite. Compactness of the fixed contour and closed angular chart supplies a uniform finite inverse bound and justifies the deformed zero-regulator/angular limit. The qualitative bound is not substituted for a usable numerical enclosure.

The retarded convention is (D-E-i0)^(-1). The lower detour consequently gives PV plus positive i*pi times the residues. The lower-pair spectral integral is the imaginary part of the detour from s to R. Both vertical edges are included. The multiple-root Schur-complement residue uses the inverse restricted radial derivative; the contour therefore retains the full lower cluster without equal-rank or averaged-eigenvalue approximations.

The source formulas preserve the physical x source axis in all three coordinate charts, their signed separated X/R moments, t^2 Jacobian, and 8/(2pi)^3=1/pi^3 normalization. Their continuation is holomorphic; it does not conjugate complex t. There is no additional 1/(2 omega) factor because the spectral variable is E=omega^2. Unit mass and the exact E=36/25 are explicit model settings.

## Implementation and quadrature checks

Inspected files include `math/CONTOUR_DERIVATION.md`, `pilot/source_moments.py`, `pilot/qt_cell_pilot.py`, `green/green_cell_pilot.py`, `high_order/certified_gauss.py`, and the adaptive mode of `high_order/qt_gauss_pilot.py`.

The interval Riemann routines evaluate the complete three-dimensional parameter box, multiply by the corresponding parameter measure and complex contour differential, and sum outwardly. They do not infer quadrature error from sampled nodes. A failed interval inverse is treated as a failed enclosure.

The higher-order routine uses the valid telescoping tensor error identity. For each coordinate, it bounds the function on a complex square containing the Cauchy disc while retaining the entire real intervals in the other two coordinates. Cauchy coefficient bounds and exact Gauss degree five yield the stated degree-six tail. Positive normalized Gauss weights and normalized integration have norm at most one. Summing the three one-coordinate remainder bounds is therefore sufficient; simultaneous complex continuation of all three coordinates is unnecessary.

The Gauss nodes, weights, function values, volume and error bounds use outward Arb arithmetic. A complex absolute-error bound e is added as the rectangle [-e,e]+i[-e,e], which contains the corresponding error disc. Selecting a radius multiplier using a diagnostic floating-point ranking does not invalidate a candidate's separately outward error bound. Adaptive subdivision sums valid child integrals over the original domain.

The current adaptive runner rejects tested negative/zero partitions. During this inspection its input validation and partial-row metadata were being corrected; the current `integrated_bounds_rational` explicitly identifies the actual row domain. Earlier row records must remain paired with their generating source snapshots or be regenerated before final packaging. Similarly, the inspected `MANUFACTURED_CHECKS.json` initially predated the expanded checker and source hashes; final delivery must include the rerun against final code. These are evidence-pairing obligations, not demonstrated errors in the completed mathematical enclosures.

## Additional checks actually performed

This review independently tested the nonseparable analytic function 1/(2-x-y-z), using its exact triple integral obtained from F'''(t)=1/t, with F(t)=t^2 log(t)/2-3t^2/4. Both tests passed:

- A narrow three-dimensional box gave an enclosure containing the analytic result and zero imaginary part, with real radius approximately 7.47e-10.
- A larger box required four adaptive leaves and also contained the exact result. Its large radius demonstrates a valid enclosure that is not yet numerically useful.

The exact outputs and reviewed quadrature-code hash are in `INDEPENDENT_GAUSS_CHECKS.json`. These are manufactured integral tests, not physical-cell reruns. The review also checked the installed interval inverse's documented behavior and verified that a simple interval matrix containing a singular member is rejected. This is a backend sanity check, not a proof of the arithmetic library itself.

The saved source-comparison checks and contour diagnostic results were inspected, including independent bond/source construction, all three charts, complex-source conjugation rejection, wrong contour sign, and omitted-edge controls. They were not represented as newly executed runs in this review.

## Open referee pass and limits

The main remaining risk is overinterpreting partial coverage or a numerical cost forecast. Four positive-area cells, or one angular row, do not cover any full chart. Their integrated values cannot be compared directly with the full selected matrices as if the omitted angular domain were zero. Extrapolating their cost or width to the full domain is a feasibility estimate, not an error enclosure or impossibility proof.

A successful reference-frequency certificate would apply to the stationary source-projected lattice calculation and specified coupling box. It would not establish an exact finite-window/direct-trajectory identity, all packet frequencies, changed stiffnesses, or a higher conversion efficiency. The present manuscript's computed-matrix floor remains appropriately scoped while the global error budgets are open.

No full angular coverage ledger, assembled 12-by-12 exact-to-selected operator errors, global conditional-bridge activation, second platform, independent human reproduction, or audit of interval-library internals was performed here. These limits do not undermine the reviewed local contour identities and integral enclosures, but they constrain the conclusion that may be reported.

## Focused final delta: local contours, row assembly and global feasibility

The subsequent `math/LOCAL_SEPARATOR.md` proof and checker, `high_order/local_endpoint.py`, final runner, density-driven subdivision and row merger were reviewed. No material error was identified. The local endpoint satisfies 0<t0<s; rank-one interlacing bounds the whole lower pair below E, while a single fixed-vector Rayleigh quotient is outwardly enclosed over the entire real angular cell and bounds the top branch above E. The vector is not fitted independently at sample points. Together with the existing radial census, these two inequalities identify exactly the same qT poles. This contour change therefore preserves the physical integral.

The nonreal-pole proof allows every finite h>0. No upper restriction h<=1/8 is necessary. Enlarged complex angular neighborhoods remain separately certified by the numerical inverse enclosure; the local real endpoint proof does not substitute for them.

The final row outputs bind the actual integration rectangle, source files including imported cell definitions, relevant settings and contour endpoint certificate. The merger verifies source/settings agreement and current hashes, requires each row exactly once, checks its rational rectangle, and sums all 17 moments outwardly. In this delta review, the ordinary four-row and body-diagonal two-row sums were reconstructed: every stored lower/upper endpoint matched exactly. Deliberately missing and duplicated rows were rejected. The three local endpoint routines were independently rerun and returned strictly positive margins. These cheap checks reran no physical quadrature. Results and source hashes are in `DELTA_CHECKS.json`.

The proposed planning comparison is algebraically correct. If every entry of the 12-by-12 Q error has modulus at most epsilon, then ||1.69 Delta Q||_2<=1.69*12*epsilon. Thus epsilon=1/4056 is sufficient for the 0.005 budget. A uniform absolute moment-radius density over the three unit-area charts would have to be at most 1/12168, approximately 8.218e-5, even before allowing for displacement from the selected cache center. These constants were checked with exact rational arithmetic.

The pilot densities exceed that simple uniform allocation, and only 1/384 of the combined three-chart angular parameter area has been covered. This supports holding the global campaign until a credible complete error-allocation and cost design exists. It does **not** prove that the existing method cannot meet a nonuniform global budget, that refinement cannot suffice, or that a different algorithm is mathematically necessary. Appropriate next options are tighter enclosures, more efficient quadrature, and/or validated nonuniform adaptive budgeting. The actual row-error pattern and selected-center displacement must ultimately replace this conservative planning comparison. No impossibility result or practical global-cost guarantee is claimed.
