#!/usr/bin/env python3
"""Reproduce rejection tests for incomplete or inconsistent checkpoint merges."""
import argparse,hashlib,json,tempfile
from pathlib import Path
from merge_rows import merge

def run():
    base=Path(__file__).resolve().parent/'results'
    paths=[base/f'certified_body_diagonal_a2_c32_tol001_row{i}.json' for i in range(2)]
    checks=[]
    def rejected(name,ps):
        try:merge(ps);passed=False
        except ValueError:passed=True
        checks.append({'name':name,'passed':passed})
    rejected('missing_row',paths[:1]);rejected('duplicate_row',[paths[0],paths[0]])
    with tempfile.TemporaryDirectory() as td:
        p=Path(td)/'changed_checkpoint.json'
        j=json.loads(paths[1].read_text());j['source_sha256']['high_order/certified_gauss.py']='0'*64;p.write_text(json.dumps(j))
        rejected('changed_source_identity',[paths[0],p])
        j=json.loads(paths[1].read_text());j['integrated_bounds_rational'][0]='1/2';p.write_text(json.dumps(j))
        rejected('changed_row_geometry',[paths[0],p])
        j=json.loads(paths[1].read_text());j['run_arguments']['height']='1/8';p.write_text(json.dumps(j))
        rejected('changed_integration_settings',[paths[0],p])
    return {'passed':all(x['passed'] for x in checks),'checks':checks,
            'source_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in [Path(__file__),Path(__file__).with_name('merge_rows.py')]}}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args();out=run();Path(a.output).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
    if not out['passed']:raise SystemExit(2)
