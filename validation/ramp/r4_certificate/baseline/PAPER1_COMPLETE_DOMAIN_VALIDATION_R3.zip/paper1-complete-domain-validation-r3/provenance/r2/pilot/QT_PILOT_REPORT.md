# Source-projected qT contour pilot

The four declared positive-area angular cells now have outward enclosures for all 17 source-projected qT moments. Refining the **same cells**, from 4 by 4 angular rectangles with 256 subsegments on each contour edge to 8 by 8 rectangles with 512 subsegments per edge, produced strictly narrower intervals contained in the previous intervals for every one of the 68 results. This establishes a functioning local enclosure method including cells that touch a coordinate plane, an axis, and the body diagonal. It does not establish a global qT error bound or transfer the computed-matrix floor to the exact lattice.

## Mathematical connection and source conventions

The proof in `../math/CONTOUR_DERIVATION.md` supplies the fixed separator `s=acos(3/4)`, the exterior shell cutoff `R=acos(1/4)`, and the absence of complex poles off the real axis in this strip. At exact reference energy `E=36/25`, the qT contribution consists of precisely the two later radial poles in `(s,R)`, including multiplicity. Summing their resolvent residues jointly avoids selecting a basis in a tied lower eigenspace.

For each chart, `source_moments.py` constructs the actual matrix `(D-EI)^(-1)` and centered source products. Its 17 values have order `a_0,...,a_5,c_0,...,c_5,b_1,...,b_5`; every signed cross moment is retained. They include `t²/pi³`, the Jacobian and positive-octant normalization. The source direction remains physical x in every chart. Complex source products are analytic continuations of their real-axis products; the contour implementation does not conjugate the complex coordinate.

The contour runs along `s -> s-i/8 -> R-i/8 -> R`. The imaginary part of its moment integral equals the normalized qT residue sum. A reflected upper path gives the closed contour justification. No angular point samples or guessed quadrature errors enter the enclosures: each complex segment and entire angular rectangle is evaluated as an Arb complex ball; the range is multiplied by its path increment and angular area and summed. Unsuccessful interval inversions produce a blocked result, never a replacement value.

## Same-domain results

Only chart `k=t(1,u,v)` was integrated on full angular cells. The other two charts were independently tested at real and complex points and against exact axis residues.

| Cell | u interval | v interval | Maximum radius / cell area, before | After | Fine stage seconds |
|---|---|---|---:|---:|---:|
| Ordinary | [3/8,7/16] | [5/8,11/16] | 0.093744 | 0.030735 | 10.29 |
| Coordinate plane | [7/16,1/2] | [0,1/32] | 0.019020 | 0.008509 | 16.44 |
| Axis | [0,1/32] | [0,1/32] | 0.0014022 | 0.00068494 | 15.77 |
| Body diagonal | [31/32,1] | [31/32,1] | 0.33171 | 0.034725 | 10.93 |

The numbers in this table are rounded diagnostics. The files contain exact binary outward interval endpoints, represented as integer mantissa times a power of two. Exact rational endpoint comparisons establish the nesting and strict contraction, rather than the rounded table numbers.

Each fine stage used 98,304 integrand evaluations. The four disjoint cells have combined chart parameter area `1/128`, or `1/384` of the combined area of the three unit-square charts. This is **not a solid-angle fraction** and is not full angular coverage. In particular, the body-diagonal cell covers the one-sided part inside the x-dominant chart; a whole-neighborhood global treatment must include adjacent charts too.

Two deliberately retained early attempts were blocked: ordinary at 1 angular interval and 64 contour segments, and body diagonal at 2 angular intervals and 128 contour segments. The underlying message `matrix is singular` means the interval inverse could not certify the broad matrix box. The mathematical proof excludes an actual exact-contour singularity. Partitioning the original cells resolved both blocks without shrinking their physical domains.

## Independent checks actually performed

- `check_source_moments.py`: constructed all nine bonds independently and the original four-node source with `exp(+ik·r)` / `exp(-ik·r)` factors. All 17 moments agreed at six real/complex points covering all three charts, using 160-bit balls. Deliberately replacing the analytic dual by complex conjugation failed the complex-point checks; treating a chart permutation as a physical source rotation was also rejected. These are implementation checks, not integral error estimates.
- `check_qt_axes.py`: compared interval contour integrals with exact analytical qT axis residues. On the x axis all moments vanish. On the y and z axes, each `a_d` equals `4 cos²(t_T/2) t_T²/(2 pi² sin(t_T))`, where `t_T=acos(7/25)`, and all `c_d,b_d` vanish. Every exact target was contained; opposite retarded sign and missing factor pi were rejected by the y/z tests.
- `summarize_qt_pilot.py`: exact binary endpoint arithmetic confirms all 68 fine intervals lie inside and are strictly narrower than their coarse counterparts on the same cell.
- `check_qt_runner.py`: invalid zero/negative partitions, zero/negative contour height, low precision and an invalid chart are rejected. The final runner writes results through an atomic temporary-file replacement. Its small positive replay reproduced all 17 serialized numerical intervals bit-for-bit from the earlier runner.

## Execution provenance and minimal correction

The original numerical-stage script is preserved exactly as `results/qt_cell_pilot.py.snapshot`, and the original stage hashes bind that snapshot. The current runner adds input validation, distinguishes unexpected failures from blocked interval inversions, and writes output atomically. Its numerical body is unchanged. The final replay and `QT_RUNNER_CHECKS.json` bind the current runner. Historical stage files are not relabelled as executions of the revised runner. The shared `source_moments.py` primitive was unchanged throughout these runs.

One validation-harness invocation initially supplied the negative fractional CLI argument as two tokens; argparse rejected it before the runner created a record. The harness was corrected to use `--height=-1/8`, and the negative-input suite then passed. This was a harness invocation correction, not a change to any numerical enclosure.

## Remaining limits and useful next step

These interval-Riemann enclosures are broad; the pilot does not demonstrate practical global certification at the required operator-norm budget. The observed contraction is specific to the performed refinements, with no asserted convergence rate. A production attempt needs a complete three-chart cover, sharper validated quadrature or Taylor bounds, all source moments of both the full Green matrix and qT matrix, full Toeplitz reconstruction, exact-to-selected-cache displacement, and the existing perturbation bridge. Refinement differences themselves must never replace outward errors.

The next numerical design decision should therefore be a bounded comparison against a higher-order validated enclosure on these same cells before scaling this first-order range method globally. The present results remain useful correctness references for that comparison. No manuscript, selected numerical matrix, historical certificate, or sealed prior validation package was edited.

## Reproduction

From this directory, use Python with python-flint installed (the performed runs used the existing validated environment), for example:

```bash
python check_source_moments.py
python check_qt_axes.py
python qt_cell_pilot.py --cell ordinary --angular-n 8 --contour-n 512 --output fresh_qt_ordinary.json
python summarize_qt_pilot.py
python check_qt_runner.py
```

The summary and runner checks consume the delivered records. The CLI supports each named cell and charts 0, 1, 2; only the specifically recorded runs should be described as performed. No optional unrecorded broader integration is implicit in these commands.
