# Certification mathematics assessment

**Result:** no confirmed mathematical flaw was found in the present finite cached-kernel certificate or its local principal-value pilot. The exact-lattice bottleneck remains incomplete global spectral integration and error bounds. The attachments do not supply those bounds. A checked symmetry reduction and a sharper bookkeeping rule can make a future integration attempt less expensive and less error-prone.

**Follow-up update:** the separate source audit subsequently confirmed an eigenbasis-dependent nodal interpolation defect. The affected original N128 arrays were traced exactly to the current certificate inputs. The matched numerical floor comparison in [FLOOR_IMPACT.md](FLOOR_IMPACT.md) gives `.10801890 → .10803242` under the minimally invariant nodal prescription. The old interval proof remains valid for its old caches; it is not a certificate for the new matrices. This follow-up changes the assessment of the numerical input accuracy, not the validity of the finite proof conditional on its declared inputs.

This assessment is a focused AI-assisted review on the same host. It does not repeat the completed 224-bit finite proof or 192-bit local proof. Their controlling source, recorded scope, error propagation, source basis and existing review were inspected. No paper or core validation source was changed.

## 1. What is already mathematically accounted for

The finite proof treats the two cached 12 by 12 Green/spectral matrices as exact dyadic approximants, builds the physical coupling matrices from exact rational coefficients, encloses the square roots, and proves the required positivity and norm inequalities. Its 64 vertices control convex auxiliary norms throughout the box, not hypothetical vertex extrema of transmission. The proof already propagates both the response change and the output-measure change. No missing factor of the stiffness scale, inverse condition, or output error was identified here.

The 10.8% result remains a statement about the specified computed matrices. The sufficient conditions `||1.69 Δg||₂ <= .020` and `||1.69 ΔQ||₂ <= .005` would support the existing conditional exact-lattice result above .1037, but no inspected source establishes those two global errors. An observed mesh difference cannot supply their upper bounds.

The local pilot correctly uses the positive simple middle-band root, the normalized X source, the determinant/cofactor identity, and a symmetric physical `kz = kz₀ + h` tube. Its zero integral for the subtracted `1/h` residue follows from that symmetric tube. It does not assert this cancellation on asymmetric chart cells or over the entire Brillouin zone. A full integration cannot silently reuse the cancellation there.

## 2. Checked symmetry reduction, with the cross terms preserved

The published bare medium is homogeneous with identical axial and face-diagonal spring constants fixed here to one. The six source cross sections use identical normalized X/R patterns. After removing a common Fourier phase, their form-factor columns are

\[
F_X=(A,0,0)^T,\qquad F_R=(0,-iB,-iC)^T,
\]

where

\[
A=2\cos(k_y/2)\cos(k_z/2),\quad
B=\sqrt2\sin(k_y/2)\cos(k_z/2),\quad
C=\sqrt2\cos(k_y/2)\sin(k_z/2).
\]

For the symmetric Cartesian resolvent or spectral integrand `R`, the projected symbol is

\[
H=F^\dagger R F=
\begin{pmatrix}
A^2R_{xx}&-iA(BR_{xy}+CR_{xz})\\
iA(BR_{xy}+CR_{xz})&B^2R_{yy}+2BCR_{yz}+C^2R_{zz}
\end{pmatrix}.
\]

The explicit Bloch matrix satisfies `D(-kx,ky,kz) = Sx D(kx,ky,kz) Sx`, with `Sx = diag(-1,1,1)`, and corresponding y/z identities. Matrix inversion and consistent spectral projectors preserve these transformations. Therefore H is even in ky and kz; its diagonal is even in kx and its cross entries are odd in kx. Translation between source segments contributes `exp(i kx d)` with `d=s−t`.

For a full-zone normalized average, the nonnegative-separation block has the form

\[
K_d=\begin{pmatrix}a_d&b_d\\-b_d&c_d\end{pmatrix},\qquad K_{-d}=K_d^T,\quad b_0=0.
\]

The full 12 by 12 matrix follows from six `a_d`, six `c_d` and five `b_d`: **17 scalar moment integrals**. For the full retarded g these moments are complex; PV, total spectral and qT spectral parts separately have real moments. This is an exact property of the declared source/bulk geometry, not an assumption that the loaded device has the bulk's full point-group symmetry.

In the positive octant the diagonal moments carry `cos(d kx)` and the cross moment carries `i sin(d kx) H_XR`. The normalized mean over the positive octant equals the corresponding full-zone moment; in an unnormalized integral this is a factor of eight. Reflection planes have measure zero for ordinary integrals, but a shell integration must still assign chart boundaries and any exceptional geometry consistently. This reduction does not prove shell completeness or permit omission of a sheet lying in a difficult chart.

**The cross moments must remain.** Their pointwise odd parity does not make them vanish after multiplication by the intersegment phase. Only `b₀` vanishes. This distinction is especially useful when applying Paper 3A's parity ideas to Paper 1: a source self-entry and a separated source-pair entry are different integrals.

Checks actually run:

- Exact symbolic projected-symbol and three-reflection identities.
- Independent direct full-zone sums versus the 17-moment positive-octant construction, at `omega=1.2`, `eta=.1`, on 16³ and 24³ reflection-paired midpoint grids, for both the complete retarded matrix and lower-pair regularized spectral matrix. Maximum absolute entry discrepancy: `3.98e-15`.
- Comparison against the existing finite-eta producer on the same grids, source, phase convention and eta. Maximum absolute entry discrepancy: `2.61e-16`.
- Cross-term-omission negative controls: removing all X/R entries changes the operator by approximately `.097–.117` in the tested normalized unscaled matrices. The incorrect simplification is decisively rejected.
- Source separation reaches five sites, below the Nyquist separation of either diagnostic grid; every separation and both component orders were assembled. These tests avoid an accidental phase-index collision, but **do not bound quadrature aliasing or a continuum/zero-eta limit**.
- The current cached PV, total spectral and lower-pair spectral matrices obey the derived template to maximum entry residuals `6.94e-18`, `1.59e-21`, and `3.07e-22`, respectively. These are diagnostic floating-point differences, not certified error bounds. A future enclosure about the actual cache must include any residual rather than silently replace the target by a projected matrix.

The existing producers already exploit translation through block-Toeplitz assembly. Thus the improvement is not a newly discovered reduction from 144 separately computed entries. The additional verified parity relations reduce the retained block moments and can restrict a suitably written integrator to the positive octant. Whether this delivers a useful speedup for shell charts or interval quadrature requires a bounded implementation trial; no production speedup was measured.

## 3. Two further safeguards with direct mathematical value

### Principal-value subtraction retains asymmetric boundary terms

For a simple pole `f(h)=r/h+g(h)` on `[-a,b]`, with positive a,b,

\[
\operatorname{PV}\int_{-a}^{b} f(h)\,dh
=\int_{-a}^{b}g(h)\,dh+r\log(b/a).
\]

The local pilot has a=b, so its omitted logarithm is exactly zero. A future adaptive cover can have asymmetric cutoffs and cannot omit the term. A change of normal coordinate also puts its Jacobian into the numerator before the residue is computed.

The algebra was checked on `f=1/h+2+3h`, `a=.01`, `b=.02` by explicit symmetric-epsilon limiting integration. The correct value is `1209/20000 + log(2)`; omitting the logarithm is wrong by `log(2)`. This confirms a future implementation requirement, **not a defect in the existing symmetric pilot**.

### Use the actual moment-error pattern to bound the matrix norm

If E is a nonnegative symmetric entrywise modulus envelope for the entire error matrix, then

\[
\|\Delta\|_2\le\sqrt{\|E\|_1\|E\|_\infty}
=\max_i\sum_j E_{ij}.
\]

The proof follows from entrywise domination of vector magnitudes and the standard induced-norm inequality; it applies to complex errors as well. The repeated Toeplitz moment errors must be placed at every occurrence, including X/R cross entries. This can be combined with the Frobenius bound by taking the smaller proven upper bound. It can avoid the earlier planning rule's wasteful allocation of the same error to every entry.

An illustrative six-segment nonuniform error pattern gave row-sum bound `.00083` and Frobenius bound `.00088769`; 32 fixed-seed complex perturbations satisfying that pattern lay below the row-sum bound. The algebra is the justification; the randomized examples only check implementation. These error numbers are fabricated test envelopes, **not measured or certified errors of Paper 1**. Scaling by 1.69 and accounting for enclosure-center displacement from the actual cached values remain required.

## 4. What the attachments contribute

| Attachment and inspected locus | Valid transfer | Boundary of transfer |
|---|---|---|
| Paper 2, Supplemental SVI source construction and root census | Keep raw unsymmetrized matrices, complete propagating/root accounting, and compare numerical maps at matched physical inputs. | Its exact-real prescription is not an interval enclosure of Paper 1's integrals; source geometry and numerical values differ. |
| Paper 3A, `sec:sigma` | A symmetry reduction needs the resolvent, source support and boundaries to transform consistently. Parity must include the complete integrand. | The gauge-lift diagonality result does not imply Paper 1's separated X/R cross blocks vanish. The negative control above shows they do not. |
| Echo draft, discrete flux/action statement and one-port Wronskian argument | A self-adjoint source/lead problem should obey a consistently normalized energy ledger. | A unitary or closed ledger can hold for an inaccurately integrated Green matrix; it does not prove spectral completeness or convergence. |
| QG draft, `eq:H1Asourcecovector`, `eq:H1Bactionsource`, and interacting comparison | Derive sources and reaction from the actual discrete action; a source-shaped continuum coordinate is not automatically the action-derived source. | No equivalence map takes that finite two-dimensional parent to this 3D elastic source, and its continuum approximation supplies no missing factor here. |

The lower qT doublet must be summed consistently. A separate exact-degeneracy diagnostic rotated a two-dimensional eigenspace: the complete projector changed only at `3.15e-17`, whereas a single selected eigenvector's source power changed by `.346`. This confirms that an arbitrary split can be unstable while the cluster is well defined. It does **not** allow replacing two unequal eigenvalue denominators by a common average, or ignoring an unresolved gap to the third branch.

## 5. Recommended consequence for the present work

1. Preserve the existing finite and local certificates as valid results for their declared inputs. The separate nodal-basis correction touches the controlling surface cache; if that corrected prescription is accepted for production, rebuild affected numerical evidence and issue a new input-bound interval certificate. Do not carry the old strict floor to the new cache without that step.
2. Use the derived reflection/template identities as diagnostics in any fresh frequency-kernel calculation. Preserve raw data before symmetry projection; a large discrepancy is a question to investigate, not permission to symmetrize it away.
3. If a future exact-lattice feasibility study is undertaken, integrate the 17 moments with a complete chart/root cover, preserve signed cross moments, include asymmetric PV terms, and use nonuniform outward error envelopes in the existing perturbation bridge.
4. Do not add these development details or the local pilot's tiny values to the main paper. They improve the validation route; they currently establish no sharper conversion value or global floor.

No full-zone singular integral enclosure, global gap/root census, limiting-absorption error, or independent-person/platform replication was performed here. The bounded symmetry tests cannot resolve the original omega=1 archived row, and this assessment does not identify its cause. That uncertainty belongs to the separate frequency-source reconstruction.

## Reproduction

Run from the workspace root with the existing dependency directories:

```bash
PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=/workspace/scratch/be1617cef594/analysis/proceed/certification/deps \
/workspace/scratch/be1617cef594/analysis/proceed/environment/fresh-validation-venv/bin/python \
-B analysis/math_resolution/certification/check_simplifications.py
```

The script writes `simplification_checks.json`, includes the exact inspected core source hashes, explicitly fails unsuccessful checks, and verifies those sources remained unchanged. The initial invocation through the unconfigured system Python failed at import because SymPy was absent there; the recorded successful calculation used the existing pinned validation environment plus its already available symbolic dependency directory. No installation or core edit was made.
