"""Certify a real contour endpoint between the upper and lower bands.

For |k_i|<=t0 and c=cos(t0)>=0, write D=S+2 sin(k)sin(k)^T.
The diagonal entries of S are <=2(2-c-c^2), so rank-one interlacing
gives lambda_middle(D)<=2(2-c-c^2). A fixed-vector Rayleigh lower
bound proves lambda_max(D)>E on the complete specified angular cell.
The existing radial root-count/complex-strip proof then identifies the
same two lower branches for a contour with this endpoint.
"""
from flint import arb
from source_moments import symbol_matrix,ball_serialization
from qt_cell_pilot import CELLS,exact
STARTS={'ordinary':'5/8','body_diagonal':'1/2','coordinate_plane':'11/16'}

def endpoint(cell,chart=0):
    if chart!=0:raise ValueError('local endpoint is proved only for x chart')
    if cell not in STARTS:raise ValueError('no declared local endpoint for this cell')
    t=exact(STARTS[cell]);a,b,c,d=map(exact,CELLS[cell]);u=a.union(b);v=c.union(d)
    if not (t>0 and t<(arb(3)/4).acos()):raise ArithmeticError('endpoint outside proven radial interval')
    if not (a>=0 and b<=1 and c>=0 and d<=1):raise ArithmeticError('cell outside unit angular square')
    D=symbol_matrix(t,u,v,chart);w=[arb(1),(a+b)/2,(c+d)/2]
    ray=sum(w[i]*D[i,j]*w[j] for i in range(3) for j in range(3))/sum(x*x for x in w)
    lower_margin=arb(36)/25-2*(2-t.cos()-t.cos()**2)
    upper_margin=ray.real-arb(36)/25
    if not lower_margin>0 or not upper_margin>0 or not ray.imag.contains(0):raise ArithmeticError('endpoint separation not certified')
    return t,{'cell':cell,'chart':chart,'t0_rational':STARTS[cell],
              'bounds_rational':CELLS[cell],
              'E_minus_lambda_middle_upper':ball_serialization(lower_margin),
              'lambda_top_lower_minus_E':ball_serialization(upper_margin),
              'status':'certified_endpoint_between_bands'}
