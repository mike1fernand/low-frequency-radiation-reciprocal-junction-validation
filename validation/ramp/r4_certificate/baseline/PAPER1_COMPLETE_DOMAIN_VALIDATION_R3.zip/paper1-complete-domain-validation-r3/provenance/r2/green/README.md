# Full-Green contour and exterior pilot

All 17 full-Green moments have outward enclosures on four fixed positive-area angular cells, including the regular exterior contribution. This is a local integrator validation; the four cells are not a complete chart or Brillouin-zone cover, and they establish no exact-to-selected matrix error budget.

The exact model is the reference nine-bond bare bulk at squared frequency `36/25`, with the published physical x-directed source. See `../math/CONTOUR_DERIVATION.md` for the contour identity and the pole-exclusion argument. No manuscript, selected matrix, or previously sealed archive was modified.

## Integral and enclosure method

In the x chart, `k=t(1,u,v)`. The source primitive returns moments in order `a0..a5,c0..c5,b1..b5`, including the volume Jacobian `t²` and positive-octant normalization `1/pi³`. At every angular cell, the full integral uses the lower contour

`0 → -i/4 → R-i/4 → R`, where `R=acos(1/4)`,

and the real regular exterior `R → pi`. Each segment is parameterized by a real variable in `[0,1]`. The program evaluates the complete angular and segment subintervals with 120-bit Arb arithmetic, multiplies the resulting complex rectangles by the exact subvolume and segment derivative, then sums outward. These are interval Riemann bounds, not error estimates inferred from mesh differences. The retained real part includes the principal value and its endpoint contributions through the contour identity.

The result files serialize lower and upper interval endpoints as exact binary mantissa/exponent pairs. Decimal midpoints, radii, timings and Gaussian-quadrature values are diagnostics. Result files bind the executed producer and source primitive by SHA-256.

## Actual results

| Cell | u interval | v interval | Largest real/imaginary radius, 4×4 angular and 128 radial parts per leg | Same radius, 8×8 and 256 |
|---|---|---|---:|---:|
| Ordinary | [3/8, 7/16] | [5/8, 11/16] | 7.7732e-4 | 2.6121e-4 |
| Coordinate plane | [7/16, 1/2] | [0, 1/32] | 9.0860e-5 | 4.0654e-5 |
| Axis | [0, 1/32] | [0, 1/32] | 1.1763e-5 | 5.7873e-6 |
| Body diagonal | [31/32, 1] | [31/32, 1] | 1.4884e-4 | 4.7299e-5 |

Every listed radius belongs to the full integral of that fixed physical cell; refinement did not shrink the physical domain. Successful levels have mutually overlapping enclosures and strictly decreasing maximum radii. The finest level uses 65,536 box evaluations per cell and took 5.2–8.6 seconds in the final recorded executions. Costs depend on the environment and competing work.

At the coarsest 1×1 angular/32 radial level, ordinary and body-diagonal cells could not certify their matrix inversions. These are recorded as `unresolved_interval_inversion`, with exit status 2. They do not establish physical poles on the contour. Subdivision resolved both failures at 2×2/64. No failed partial sum is used as an enclosure.

## Checks that were run

- The scalar integral of `t²/(t−1/2)` from 0 to 2 enclosed the exact value `3 + log(3)/4 + i*pi/4`. The upper-contour control gave its conjugate. Omitting the asymmetric endpoint logarithm or reversing the retarded sign was rejected at the finer test level.
- The full-Green x-axis residue was checked against its exact formula for all six `a_d`: `4*tL²*cos(d*tL)/(pi²*6*sin(tL))`, `tL=acos(19/25)`. Each analytic spectral value lies in the contour enclosure; every `c_d` and `b_d` is exactly zero on this axis.
- Separate NumPy quadrature constructed the symbol from the nine individual bonds and the source projection as `Fminus.T @ resolvent @ Fplus`. This checks the analytic source continuation without complex conjugation on the contour. All 17 whole-cell estimates lie inside the outward enclosures. Two contour heights, 1/4 and 1/8, agreed to at most 6.2e-19 in this diagnostic. That agreement supplies no rigorous error radius.
- The exterior contribution is exactly real in the interval output; all refinement files bind the final producer and primitive hashes.

The shared source's independent algebra and point diagnostics are recorded in `../pilot/results/SOURCE_MOMENT_CHECKS.json`. They are separate from the whole-cell quadrature enclosures here.

## Reproduction

Keep this `green` directory beside the supplied `pilot` directory. With the recorded environment's Python (python-flint 0.8.0 and NumPy), use fresh output locations. The following commands are portable after replacing `python` with that interpreter. Run each cell separately; the driver limits each producer subprocess to 30 seconds and allows `--timeout-seconds` to be changed on a slower machine.

```bash
python green/green_cell_pilot.py --scalar-only --output fresh/scalar_checks.json
python green/run_green_pilots.py --cell ordinary --output-dir fresh
python green/run_green_pilots.py --cell plane --output-dir fresh
python green/run_green_pilots.py --cell axis --output-dir fresh
python green/run_green_pilots.py --cell body --output-dir fresh
python green/check_green_pilot.py --input-dir fresh --output fresh/GREEN_PILOT_CHECKS.json
python green/check_green_runner.py --output fresh/CLI_NEGATIVE_CHECKS.json
```

The driver recognizes unresolved interval inversions, continues to finer subdivisions, and requires the final level to certify. The producer and checker write their JSON atomically. `*_execution.json` records actual statuses, output hashes and timings.

## Remaining obligation and next decision

These four cells cover angular area 1/128 of the x chart. Neither the other angular cells nor either other coordinate chart has been enclosed here. No extrapolation of the tabulated radii can certify them. The exact-lattice claim additionally requires the complete qT integral, source-preserving reconstruction, all Toeplitz multiplicities, exact-to-selected center displacement, and the existing finite-response norm-budget check.

The simple Riemann enclosures contract, but their widths and first-order refinement cost do not establish that a full campaign can reach those budgets economically. A higher-order method with a proved remainder, tested on the same physical cells, is the appropriate next feasibility step. Merely increasing floating-point quadrature order or observing contour-height agreement would not close that gap.
