# Higher-order validated cubature pilot

This is a feasibility investigation for the exact-lattice Green/qT calculation. It does not certify the global qT matrix or an exact-lattice floor. The fixed cell geometry and moment source are shared with the basic interval-Riemann pilots.

## Bound used

Let the real parameter box have centers c_j, halfwidths h_j, and volume V. For each j, the callback is holomorphic on the disk |z_j-c_j| <= rho_j for every real value of the other two parameters in their full intervals. Let M_j bound the modulus on this set, and r_j=h_j/rho_j<1. The code verifies a stronger sufficient condition: finite interval inversion and finite trigonometric moment evaluation on the square enclosing that disk. It does not infer complex-angle invertibility from a real-angle spectral gap.

The Taylor coefficients about c_j satisfy |a_k| <= M_j/rho_j^k. Both normalized integration and normalized three-point Gauss quadrature have norm 1, and they agree on polynomials of degree at most 5. Therefore their difference is bounded by 2 M_j r_j^6/(1-r_j). The tensor telescoping identity

I1 I2 I3 - Q1 Q2 Q3 = (I1-Q1) I2 I3 + Q1 (I2-Q2) I3 + Q1 Q2 (I3-Q3)

gives the complex absolute-error bound

V sum_j 2 M_j r_j^6/(1-r_j).

The square of real/imaginary error radius equal to this absolute-error bound safely contains the error disk. The implementation uses Arb outward interval arithmetic throughout. Normalized GL3 nodes are 0, +/-sqrt(3/5); normalized weights are 4/9, 5/18, 5/18. Interval node/weight errors are included. Floating-point numbers select among already valid radius candidates and select bisection axes; they do not determine certificate endpoints.

The contour integrand includes dz/dq, the t^2 radial Jacobian and 1/pi^3 positive-octant normalization. Only x-chart source coordinates are used in these local pilots. Q_T is identified with the imaginary part of the lower detour by the separate contour/root-count argument; this cubature module alone proves an integral enclosure.

## Checks and adaptive changes

Manufactured checks include positive weights, exact normalized moments of degree 0 through 5, rational and polynomial integrals with known exact values, a narrow rational integral with error radius below 1e-12, and rejection of a complex pole inside the proposed analytic neighborhood. The broad polynomial checks confirm enclosure but are not useful accuracy tests; the narrow rational check provides a non-vacuous accuracy test.

An initial adaptive rule stopped once all enlarged neighborhoods were finite. Its ordinary-cell enclosure was very wide, so mere finiteness was not accepted as adequate. The amended rule bounds the Cauchy error before performing 27 node evaluations and bisects the coordinate with largest bound when the declared density tolerance is unmet. This tolerance controls the truncation bound; it is not a bound on the final global lattice matrix or its certification floor.

Each output declares the exact integrated rational angular rectangle. Row outputs cover only the stated row, not the full parent cell. Successful rows can be retained independently. The runner refuses to overwrite evidence, writes output atomically, has a 25-second default stage limit and a finite adaptive-depth cap. Timed-out stages are blocked outputs, not partial certificates. The separate merge_rows.py checks current source hashes, integration settings and exact complete nonoverlapping row coverage before outward summation. It rejects missing/duplicate rows, changed source identities, changed geometry and changed integration settings. A global campaign still requires a full-chart checkpoint controller.

## Evidence status

The four complete-cell records selected in EVIDENCE_MANIFEST.json are authoritative local numerical results, with their current source/settings bindings. Row files support the two assembled cells. Blocked outputs are explicitly non-certificates. Earlier exploratory outputs are retained under history/development_results and are superseded; no scientific conclusion depends on their exact replayability.

The four-cell set is a feasibility probe. It does not cover the full angular square or the other physical charts. No full-domain quadrature, global cost guarantee, finite-window identity or exact-lattice floor transfer has been performed by this module.

## Review corrections

The imported `pilot/qt_cell_pilot.py` dependency supplies the cell geometry and exact-rational parser; its hash was initially omitted. Final authoritative runs include it. A proposed restriction h<=1/8 was checked and rejected as unnecessary: the proved sign-definite imaginary-part argument excludes nonreal poles for any nonzero imaginary radial part in the stated real strip. Positive contour height is sufficient; no artificial upper restriction was added.

The fixed global lower endpoint places the body-diagonal vertical edge close to a transverse pole. A cell-specific dyadic endpoint was therefore introduced with a runtime whole-cell spectral-separation certificate: a rank-one interlacing upper bound on the middle eigenvalue plus an outward interval fixed-vector Rayleigh lower bound on the top eigenvalue. This changes the contour, not the physical integral. It enlarges some usable neighborhoods but does not remove the angular enclosure bottleneck on the horizontal contour.

## Completed same-cell comparison

| Complete x-chart cell | GL3 maximum radius / angular area | Finest Riemann radius / angular area | Riemann / GL3 radius | GL3 sum of stage seconds |
|---|---:|---:|---:|---:|
| Axis | 0.000188808 | 0.000684935 | 3.63 | 3.42 |
| Coordinate plane | 0.0106219 | 0.00850866 | 0.80 | 4.93 |
| Ordinary | 0.00729811 | 0.0307354 | 4.21 | 55.03 |
| Body diagonal | 0.00763849 | 0.0347249 | 4.55 | 35.59 |

All 17 complete-cell moment intervals overlap their Riemann counterparts. The comparison uses the same physical cells and source moments. Different contour endpoints/heights represent the same qT integral by the certified contour deformation. The ordinary and body cells used cell-specific real endpoints and h=1/4; the coordinate plane used its local endpoint and h=1/8; the axis retained the global endpoint and h=1/8. Timings were obtained under changing concurrent load; they are descriptive, not a controlled benchmark.

The higher-order method produces narrower bounds in three cells. It is not uniformly better: the plane bound is about 25% wider than the finest Riemann enclosure. Ordinary/body cost more total stage time, although each successful row finished in less than 20 seconds. This demonstrates a valid alternative to first-order range integration and resolves the coarse-row timeouts through exact row decomposition. It does not establish practical global cost.

The completed four-cell union has angular area 1/128 of the x chart and 1/384 of the combined three-chart parameter domain. A numerical error bound cannot be extrapolated from this subset to its complement. No full-domain campaign, complete matrix reconstruction, exact-to-selected displacement or comparison with the scaled operator budgets was run. The evidence therefore supports proceeding with a better global integration design, not claiming a global exact-lattice floor now. Remaining work is to sharpen analytic bounds or validated quadrature order, develop a complete angular-cover controller, include all three physical charts and all Green exterior terms, and only then test the existing response-error budgets.

## Reproduction

Use the pinned python-flint environment specified by the continuation package. From its root, the following examples are bounded stages; output files must be new paths because the runner refuses to overwrite evidence.

```sh
python high_order/validate_gauss.py --output /tmp/manufactured_checks.json
python high_order/qt_gauss_pilot.py --cell axis --angular-n 2 --contour-n 32 --adaptive --density-tolerance 1/100 --output /tmp/axis_replay.json
python high_order/qt_gauss_pilot.py --cell ordinary --angular-n 4 --contour-n 32 --adaptive --density-tolerance 1/100 --local-start --height 1/4 --row 0 --output /tmp/ordinary_row0.json
python high_order/audit_results.py --output /tmp/result_audit.json
python high_order/check_merge_guards.py --output /tmp/merge_guards.json
```

Repeat ordinary rows 1, 2, 3 or body rows 0, 1 with angular-n 2 to cover their complete cells; use merge_rows.py with all corresponding row paths and a new --output path. Every final run records its complete run_arguments, source hashes, exact integrated rectangle and endpoint proof. Source/settings/coverage mismatches stop the merge.

## Standalone audit coverage correction

Delivery review found that a glob-based audit could pass when all selected complete-cell files were absent, or when only a subset was present. The auditor now first requires the manifest to select exactly the four unique expected complete cells, verifies every selected file hash, and checks status, chart and exact full-cell geometry. Only then does it run source-binding and interval comparisons. The corrected result audit passed 26 checks. A portable negative test verified rejection after removing one selected complete cell and after removing all selected complete cells. This correction changes validation behavior only; no integration was repeated.

```sh
python high_order/check_audit_coverage.py --output /tmp/audit_coverage_checks.json
```
