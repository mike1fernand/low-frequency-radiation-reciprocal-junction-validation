#!/usr/bin/env python3
"""Verify the standalone auditor rejects missing complete-cell evidence."""
import argparse,hashlib,json,shutil,tempfile
from pathlib import Path
from audit_results import audit

def run():
    source=Path(__file__).resolve().parent
    manifest=json.loads((source/'EVIDENCE_MANIFEST.json').read_text())
    checks=[]
    with tempfile.TemporaryDirectory() as td:
        fixture=Path(td)/'high_order';(fixture/'results').mkdir(parents=True)
        shutil.copy2(source/'EVIDENCE_MANIFEST.json',fixture/'EVIDENCE_MANIFEST.json')
        for entry in manifest['cells']:
            shutil.copy2(source/entry['file'],fixture/entry['file'])
        missing=fixture/manifest['cells'][0]['file'];missing.unlink()
        result=audit(fixture)
        checks.append({'name':'missing_one_selected_complete_cell','passed':result['passed'] is False and 'missing selected complete cell' in result['checks'][0]['error']})
        for p in (fixture/'results').glob('*.json'):p.unlink()
        result=audit(fixture)
        checks.append({'name':'missing_all_selected_complete_cells','passed':result['passed'] is False and 'missing selected complete cell' in result['checks'][0]['error']})
    return {'passed':all(c['passed'] for c in checks),'checks':checks,
      'source_sha256':{f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in [Path(__file__),source/'audit_results.py']}}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args();out=run();Path(a.output).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
    if not out['passed']:raise SystemExit(2)
