#!/usr/bin/env python3
"""Rigorous Cauchy-bounded GL3 qT integrals for fixed angular cells."""
from pathlib import Path
import argparse,hashlib,json,sys,time,math
from fractions import Fraction
from flint import arb,acb,ctx
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'pilot'))
from source_moments import moment_values,ball_serialization
from qt_cell_pilot import CELLS,exact
from certified_gauss import gauss3_box,adaptive_gauss3_box
from local_endpoint import endpoint

def integrate(name,angular_n,contour_n,chart=0,height='1/8',radius_multipliers=(2,4,8,16),adaptive=False,row=None,density_tolerance=None,max_seconds=25,local_start=False):
    if angular_n<=0 or contour_n<=0:raise ValueError('partitions must be positive')
    if not math.isfinite(max_seconds) or max_seconds<=0:raise ValueError('max_seconds must be finite and positive')
    if chart not in (0,1,2):raise ValueError('chart must be 0, 1, or 2')
    if not exact(height)>0:raise ValueError('height must be positive')
    if row is not None and not 0<=row<angular_n:raise ValueError('row outside partition')
    ulo,uhi,vlo,vhi=map(exact,CELLS[name]);du=(uhi-ulo)/angular_n;dv=(vhi-vlo)/angular_n
    s=(arb(3)/4).acos();R=(arb(1)/4).acos();h=exact(height)
    endpoint_check=None
    if local_start:s,endpoint_check=endpoint(name,chart)
    points=[acb(s),acb(s,-h),acb(R,-h),acb(R)]
    accum=[acb(0) for _ in range(17)];calls=0;rejected=0;boxes=0;radius_hist={};leaves=0;maxdepth=0;start=time.monotonic()
    for i in (range(angular_n) if row is None else [row]):
      for j in range(angular_n):
        for edge,(a,b) in enumerate(zip(points[:-1],points[1:])):
          def integrand(q,u,v):
              nonlocal calls
              if time.monotonic()-start>max_seconds:raise TimeoutError('bounded stage time limit reached')
              calls+=1
              return [f*(b-a) for f in moment_values(a+(b-a)*q,u,v,chart)]
          for k in range(contour_n):
            bounds=[(arb(k)/contour_n,arb(k+1)/contour_n),
                    (ulo+i*du,ulo+(i+1)*du),(vlo+j*dv,vlo+(j+1)*dv)]
            try:vals,meta=(adaptive_gauss3_box if adaptive else gauss3_box)(integrand,bounds,radius_multipliers,density_tolerance=density_tolerance)
            except Exception as e:raise ArithmeticError(f'box i={i},j={j},edge={edge},k={k}: {e}') from e
            for m,val in enumerate(vals):accum[m]+=val
            rejected+=meta['rejected_neighborhoods'];boxes+=1
            leaves+=meta.get('leaf_boxes',1);maxdepth=max(maxdepth,meta.get('maximum_split_depth',0))
            key=','.join(map(str,meta['chosen_radius_multipliers']));radius_hist[key]=radius_hist.get(key,0)+1
    qt=[x.imag for x in accum];area=(uhi-ulo)*(vhi-vlo)/(angular_n if row is not None else 1)
    actual_bounds=list(CELLS[name])
    if row is not None:
        u0,u1=map(Fraction,actual_bounds[:2]);step=(u1-u0)/angular_n
        actual_bounds[:2]=[str(u0+row*step),str(u0+(row+1)*step)]
    return {'status':'rigorous_cell_enclosure','cell':name,'chart':chart,
            'bounds_rational':CELLS[name],'angular_partition_per_axis':angular_n,
            'integrated_bounds_rational':actual_bounds,'radius_multipliers':list(radius_multipliers),
            'density_tolerance':str(density_tolerance) if density_tolerance is not None else None,
            'local_start':local_start,'endpoint_certificate':endpoint_check,
            'segments_per_contour_edge':contour_n,'height_rational':height,
            'precision_bits':ctx.prec,'quadrature_order':3,'integrand_calls':calls,
            'boxes':boxes,'adaptive_leaf_boxes':leaves,'maximum_split_depth':maxdepth,
            'adaptive':adaptive,'angular_row':row,'rejected_neighborhoods_at_leaves':rejected,'chosen_radius_histogram':radius_hist,
            'seconds':time.monotonic()-start,'moments':[ball_serialization(x) for x in qt],
            'normalized_max_radius_diagnostic':max(float(x.rad()/area) for x in qt),
            'max_radius_diagnostic':max(float(x.rad()) for x in qt),
            'max_abs_midpoint_diagnostic':max(abs(float(x.mid())) for x in qt),
            'claim_limit':'Only integrated_bounds_rational at E=36/25. Cauchy-bounded GL3; no global qT or exact-lattice floor certificate.'}

def main():
 p=argparse.ArgumentParser();p.add_argument('--cell',choices=CELLS,required=True);p.add_argument('--angular-n',type=int,default=2);p.add_argument('--contour-n',type=int,default=32);p.add_argument('--chart',type=int,default=0);p.add_argument('--bits',type=int,default=128);p.add_argument('--height',default='1/8');p.add_argument('--output',required=True);p.add_argument('--radii',default='2,4,8,16');p.add_argument('--adaptive',action='store_true');p.add_argument('--row',type=int);p.add_argument('--density-tolerance');p.add_argument('--max-seconds',type=float,default=25);p.add_argument('--local-start',action='store_true')
 a=p.parse_args()
 if a.bits<64:p.error('--bits must be at least 64')
 ctx.prec=a.bits;t=time.monotonic()
 try:out=integrate(a.cell,a.angular_n,a.contour_n,a.chart,a.height,tuple(map(int,a.radii.split(','))),a.adaptive,a.row,exact(a.density_tolerance) if a.density_tolerance else None,a.max_seconds,a.local_start)
 except Exception as e:out={'status':'blocked_no_enclosure','cell':a.cell,'angular_partition_per_axis':a.angular_n,'segments_per_contour_edge':a.contour_n,'error_type':type(e).__name__,'error':str(e),'seconds':time.monotonic()-t}
 out['run_arguments']=vars(a)
 out['source_sha256']={str(f.relative_to(Path(__file__).resolve().parents[1])):hashlib.sha256(f.read_bytes()).hexdigest() for f in [Path(__file__).resolve(),Path(__file__).with_name('certified_gauss.py').resolve(),Path(__file__).with_name('local_endpoint.py').resolve(),Path(__file__).resolve().parents[1]/'pilot/source_moments.py',Path(__file__).resolve().parents[1]/'pilot/qt_cell_pilot.py']}
 dest=Path(a.output);dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():raise FileExistsError('refusing to overwrite existing evidence: '+str(dest))
 tmp=dest.with_name(dest.name+'.partial');tmp.write_text(json.dumps(out,indent=2)+'\n');tmp.replace(dest)
 print(json.dumps({k:v for k,v in out.items() if k not in ('moments','source_sha256','chosen_radius_histogram')},indent=2))
 if out['status']!='rigorous_cell_enclosure':raise SystemExit(2)
if __name__=='__main__':main()
