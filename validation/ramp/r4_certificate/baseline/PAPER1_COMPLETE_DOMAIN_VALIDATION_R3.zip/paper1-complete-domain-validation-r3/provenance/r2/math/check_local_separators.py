#!/usr/bin/env python3
"""Outward whole-cell endpoint proof for three optional radial separators."""
from pathlib import Path
from fractions import Fraction
import argparse
import hashlib
import json
import os
import platform
import tempfile

import flint
from flint import arb, fmpq, ctx

HERE=Path(__file__).resolve().parent
BONDS=((1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,-1,0),
       (1,0,1),(1,0,-1),(0,1,1),(0,1,-1))
CASES=(
 {'name':'ordinary','u':('3/8','7/16'),'v':('5/8','11/16'),'t0':'5/8','high_margin':'11/50','low_margin':'37/100'},
 {'name':'coordinate_plane','u':('7/16','1/2'),'v':('0','1/32'),'t0':'11/16','high_margin':'13/100','low_margin':'9/50'},
 {'name':'body_diagonal','u':('31/32','1'),'v':('31/32','1'),'t0':'1/2','high_margin':'11/20','low_margin':'73/100'},
)

def ball(value):
    f=Fraction(value)
    return arb(fmpq(f.numerator,f.denominator))

def interval(bounds):
    lo,hi=map(Fraction,bounds)
    if not 0<=lo<hi<=1:
        raise ValueError('Invalid angular cell')
    return ball(lo).union(ball(hi))

def need(ok,message):
    if not ok:
        raise RuntimeError(message)

def atomic_json(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=None
    try:
        with tempfile.NamedTemporaryFile('w',encoding='utf-8',dir=path.parent,prefix=path.name+'.',suffix='.tmp',delete=False) as f:
            temporary=Path(f.name)
            json.dump(data,f,indent=2)
            f.write('\n')
            f.flush()
            os.fsync(f.fileno())
        os.replace(temporary,path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=HERE/'LOCAL_SEPARATOR_CHECKS.json')
    parser.add_argument('--precision',type=int,default=160)
    args=parser.parse_args()
    if not 80<=args.precision<=4096:
        parser.error('--precision must lie in [80,4096]')
    ctx.prec=args.precision
    E=ball('36/25')
    rows=[]
    for case in CASES:
        a=[arb(1),interval(case['u']),interval(case['v'])]
        w=[Fraction(1),sum(map(Fraction,case['u']))/2,sum(map(Fraction,case['v']))/2]
        t0=ball(case['t0'])
        c=t0.cos()
        need(t0>0 and c>ball('3/4'),'Candidate is outside proved separator range')
        quotient=arb(0)
        for b in BONDS:
            phase=t0*sum(ai*bi for ai,bi in zip(a,b))
            wb=sum(wi*bi for wi,bi in zip(w,b))
            bb=sum(bi*bi for bi in b)
            quotient+=2*(1-phase.cos())*ball(wb*wb/Fraction(bb))
        quotient/=ball(sum(wi*wi for wi in w))
        lambda2_upper=2*(2-c-c*c)
        high_gap=quotient-E
        low_gap=E-lambda2_upper
        need(high_gap>ball(case['high_margin']),'Highest-branch whole-cell margin failed')
        need(low_gap>ball(case['low_margin']),'Lower-pair whole-cell margin failed')
        # Independently evaluate the same Rayleigh quotient from the explicit
        # diagonal/off-diagonal symbol. Overlap is a bookkeeping diagnostic;
        # the direct outward bond sum above proves the recorded lower bound.
        cs=[(t0*ai).cos() for ai in a]
        ss=[(t0*ai).sin() for ai in a]
        explicit=arb(0)
        for i in range(3):
            j,k=[r for r in range(3) if r!=i]
            explicit+=ball(w[i]*w[i])*(6-2*cs[i]*(1+cs[j]+cs[k]))
            for j in range(i+1,3):
                explicit+=4*ball(w[i]*w[j])*ss[i]*ss[j]
        explicit/=ball(sum(wi*wi for wi in w))
        need(quotient.overlaps(explicit),'Independent symbol enclosure does not overlap bond-sum enclosure')
        rows.append({**case,'chart':'x','test_vector':[str(wi) for wi in w],
          'cos_t0':c.str(50),'lambda2_upper_enclosure':lambda2_upper.str(50),
          'fixed_Rayleigh_quotient_enclosure':quotient.str(50),
          'lambda3_minus_E_lower_bound_enclosure':high_gap.str(50),
          'E_minus_lambda2_lower_bound_enclosure':low_gap.str(50),
          'independent_explicit_Rayleigh_enclosure':explicit.str(50),
          'whole_cell_outward_endpoint_checks_passed':True})
    result={'status':'passed_whole_cell_outward_endpoint_certificates','precision_bits':args.precision,
      'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'local_derivation_sha256':hashlib.sha256((HERE/'LOCAL_SEPARATOR.md').read_bytes()).hexdigest(),
      'preceding_contour_derivation_sha256':hashlib.sha256((HERE/'CONTOUR_DERIVATION.md').read_bytes()).hexdigest(),
      'runtime':{'python':platform.python_version(),'python_flint':flint.__version__},
      'cells':rows,
      'limits':['The exact separator is valid for the stated complete real angular cell.',
                'No complex angular neighborhood or integration remainder is certified by this endpoint test.',
                'No global exact-to-selected kernel error or lattice floor is established.']}
    atomic_json(args.output,result)
    print(json.dumps({'status':result['status'],'precision_bits':args.precision,
       'cells':[{key:row[key] for key in ['name','t0','lambda3_minus_E_lower_bound_enclosure','E_minus_lambda2_lower_bound_enclosure']} for row in rows]},indent=2))

if __name__=='__main__':
    main()
