#!/usr/bin/env python3
"""Exact endpoint audit of qT pilot refinement records."""
from pathlib import Path
from fractions import Fraction
import json,hashlib
from qt_cell_pilot import CELLS
BASE=Path(__file__).with_name('results')

def value(e):return Fraction(int(e['mantissa']))*Fraction(2)**e['exponent2']
def interval(m):return value(m['lower']),value(m['upper'])
rows=[]
for name in CELLS:
 paths=[BASE/f'qt_{name}_a{a}_c{c}.json' for a,c in ((4,256),(8,512))]
 records=[json.loads(p.read_text()) for p in paths]
 assert all(r['status']=='rigorous_cell_enclosure' for r in records)
 assert records[0]['bounds_rational']==records[1]['bounds_rational']==list(CELLS[name])
 assert records[0]['source_sha256']==records[1]['source_sha256']
 checks=[]
 for i,(before,after) in enumerate(zip(records[0]['moments'],records[1]['moments'])):
  lo,hi=interval(before);l,h=interval(after)
  assert l<=h and lo<=hi
  assert lo<=l<=h<=hi, (name,i,'not nested')
  assert h-l<hi-lo,(name,i,'did not strictly contract')
  checks.append({'moment_index':i,'refinement_subset_of_previous':True,
   'strict_width_contraction':True,'width_ratio_diagnostic':float((h-l)/(hi-lo))})
 rows.append({'cell':name,'checks':checks,
  'normalized_max_radius_before_diagnostic':records[0]['normalized_max_radius_diagnostic'],
  'normalized_max_radius_after_diagnostic':records[1]['normalized_max_radius_diagnostic'],
  'fine_seconds':records[1]['seconds'],'fine_integrand_calls':records[1]['integrand_calls'],
  'fine_file':paths[1].name})
blocked=[]
for p in sorted(BASE.glob('qt_*.json')):
 r=json.loads(p.read_text())
 if r['status']=='blocked_no_enclosure':blocked.append({'file':p.name,'error':r['error'],
  'meaning':'Interval inverse could not certify this broad box; not proof of a singular exact contour.'})
covered=sum((Fraction(b[1])-Fraction(b[0]))*(Fraction(b[3])-Fraction(b[2])) for b in CELLS.values())
out={'status':'passed','scope':'four disjoint x-chart angular rectangles only',
 'all_68_moment_intervals_nested_and_strictly_contracting':True,
 'x_chart_area_covered_exact':str(covered),'full_positive_octant_chart_area_exact':'3',
 'fraction_of_three_chart_parameter_area_exact':str(covered/3),
 'rows':rows,'retained_blocked_stages':blocked,
 'interpretation':'Enclosures are valid on full cells. Contraction is observed for these staged rigorously enclosed partitions; no rate or global budget bound follows.',
 'input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(BASE.glob('qt_*.json'))},
 'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(BASE/'QT_REFINEMENT_AUDIT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ('rows','input_sha256','source_sha256')},indent=2))
