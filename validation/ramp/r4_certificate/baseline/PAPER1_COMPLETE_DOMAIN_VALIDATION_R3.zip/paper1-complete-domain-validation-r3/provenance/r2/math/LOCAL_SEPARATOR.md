# Certified cell-specific radial separators

The global separator s = arccos(3/4) remains correct. On selected angular cells, a smaller fixed separator can place the contour farther from both groups of real poles and may allow larger complex quadrature neighborhoods. This is a numerical optimization of the same qT contour identity, not a change to its observable. Whether a larger complex neighborhood is actually valid must still be checked by the higher-order integrator.

## Endpoint test

Consider an x-maximum chart a=(1,u,v) on a closed angular cell. Choose an exact positive rational t0 with t0 <= s, and put c=cos(t0). Every cos(t0 a_i) lies in [c,1], with c >= 3/4. Applying the existing diagonal-plus-rank-one decomposition gives

\[
\lambda_2(D(t_0 a))
\le2\max_{r\in[c,1]}[2+r^2-r(1+2c)]
=2(2-c-c^2).
\]

The equality follows because the convex quadratic has endpoint values 2-c-c^2 and 2-2c, whose difference is c(1-c) >= 0. This is a uniform upper bound over the whole cell, and indeed over every maximum-coordinate chart. Since c >= 3/4, it is at most 11/8 < E = 36/25.

For the highest eigenvalue choose the fixed real, exact rational vector

\[
w=(1,(u_-+u_+)/2,(v_-+v_+)/2).
\]

The Rayleigh principle supplies the lower bound

\[
\lambda_3(D(t_0a))\ge
\frac{2}{w^Tw}\sum_b[1-\cos(t_0 a\cdot b)]
\frac{(w\cdot b)^2}{b\cdot b}.
\]

All coefficients other than cosine are exact rational numbers. Evaluating the cosines by outward Arb arithmetic for the complete angular box gives an enclosure of this single fixed-vector Rayleigh quotient. If its lower endpoint exceeds E, the highest branch has already crossed and neither lower branch has crossed. The existing radial monotonicity and complete census then prove that the contour from t0 to R encloses exactly the same lower-two poles as the original contour from s to R.

This test does not approximate an eigenvector or infer a bound from its midpoint value: w is constant, and its Rayleigh quotient is enclosed on every point in the cell. The same construction works in a different maximum-coordinate chart after inserting the fixed coordinate and test-vector component at that chart's position. The physical source axis is not permuted by this bulk-only test.

## Candidates actually checked

`check_local_separators.py` evaluates the complete real angular cells at 160-bit working precision. The recorded runs certify these deliberately rounded-down margins:

| Cell in the x chart | t0 | Certified lambda_3 - E greater than | Certified E - lambda_2 greater than |
|---|---:|---:|---:|
| Ordinary: [3/8,7/16] x [5/8,11/16] | 5/8 | 11/50 = 0.22 | 37/100 = 0.37 |
| Coordinate-plane: [7/16,1/2] x [0,1/32] | 11/16 | 13/100 = 0.13 | 9/50 = 0.18 |
| Body-diagonal: [31/32,1] x [31/32,1] | 1/2 | 11/20 = 0.55 | 73/100 = 0.73 |

The x-axis cell retains the global separator; no new axis claim is made here. Raw outward intervals, exact rational inputs, code and derivation hashes, and runtime are in `LOCAL_SEPARATOR_CHECKS.json`. These endpoint enclosures are rigorous whole-cell results. They do not by themselves certify a complex angular polydisk, higher-order remainder, full angular cover, or global kernel error.

The checker writes atomically to `--output` and accepts `--precision`. It performs no integration and does not modify the earlier contour proof or its recorded run.
