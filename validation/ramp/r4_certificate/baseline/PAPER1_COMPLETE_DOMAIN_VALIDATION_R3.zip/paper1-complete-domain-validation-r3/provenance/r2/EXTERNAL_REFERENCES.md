# External implementation references consulted

- Fredrik Johansson, *Numerical integration in arbitrary-precision ball arithmetic* (2018), https://arxiv.org/abs/1802.07942. The abstract describes validated integration using analytic bounds and adaptive Gaussian quadrature. It informed the algorithm search; the specific three-variable telescoping/Cauchy bound used here is derived in `high_order/PROOF_AND_FINDINGS.md` and separately reviewed.
- Official python-flint complex-ball documentation, https://python-flint.readthedocs.io/en/latest/acb.html, accessed 20 September 2026. This documents rectangular complex enclosures and outward magnitude bounds. The online page identifies version 0.9.0; the executed environment here uses **0.8.0**, whose actual methods were exercised by the supplied runs. No 0.9-only behavior was assumed.

The supplied Paper 2, Paper 3A and Operational Duration source transfer is recorded in `provenance/DONOR_TRANSFER_REASSESSMENT.md`. Those supplied sources guided root accounting, cluster handling and source consistency. They do not supply numerical error bounds for this Paper 1 model.
