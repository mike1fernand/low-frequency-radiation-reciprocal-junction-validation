#!/usr/bin/env python3
"""Check successful final source bindings, exact intervals and method overlap."""
import argparse,hashlib,json
from pathlib import Path
from fractions import Fraction

def endpoint(e):return Fraction(int(e['mantissa']))*Fraction(2)**int(e['exponent2'])
def interval(x):return endpoint(x['lower']),endpoint(x['upper'])

EXPECTED_CELLS={
    'axis':('0','1/32','0','1/32'),
    'coordinate_plane':('7/16','1/2','0','1/32'),
    'ordinary':('3/8','7/16','5/8','11/16'),
    'body_diagonal':('31/32','1','31/32','1'),
}

def require_complete_manifest(base):
    manifest=json.loads((base/'EVIDENCE_MANIFEST.json').read_text())
    entries=manifest['cells']
    if len(entries)!=4 or {e['cell'] for e in entries}!=set(EXPECTED_CELLS):
        raise ValueError('manifest must select exactly four unique expected cells')
    if len({e['file'] for e in entries})!=4:
        raise ValueError('manifest selected files must be distinct')
    for entry in entries:
        p=base/entry['file']
        if not p.is_file():raise ValueError('missing selected complete cell: '+entry['file'])
        if hashlib.sha256(p.read_bytes()).hexdigest()!=entry['sha256']:
            raise ValueError('selected complete-cell hash mismatch: '+entry['file'])
        j=json.loads(p.read_text());expected=tuple(map(Fraction,EXPECTED_CELLS[entry['cell']]))
        if entry['coverage']!='entire_declared_cell' or entry['chart']!=0:
            raise ValueError('manifest does not declare complete x-chart cell')
        if tuple(map(Fraction,entry['bounds_rational']))!=expected:
            raise ValueError('manifest whole-cell bounds changed')
        if j['cell']!=entry['cell'] or j['chart']!=0 or tuple(map(Fraction,j['integrated_bounds_rational']))!=expected:
            raise ValueError('selected result has incorrect cell, chart or whole-cell bounds')
        if j['status'] not in ('rigorous_cell_enclosure','rigorous_merged_cell_enclosure'):
            raise ValueError('selected result is not a completed certificate')

def audit(base):
    root=base.parent;checks=[];comparison=[]
    try:
        require_complete_manifest(base)
        checks.append({'name':'four_complete_manifest_selected_cells','passed':True})
    except (OSError,ValueError,KeyError,TypeError) as e:
        return {'passed':False,'checks':[{'name':'four_complete_manifest_selected_cells','passed':False,'error':str(e)}],
                'comparisons':[],'claim_limit':'Required complete-cell evidence is missing or invalid; no numerical audit passed.'}
    for p in sorted((base/'results').glob('certified_*.json')):
        j=json.loads(p.read_text())
        checks.append({'name':p.name+':source_bindings','passed':all(hashlib.sha256((root/k).read_bytes()).hexdigest()==v for k,v in j['source_sha256'].items())})
        if j['status'] not in ('rigorous_cell_enclosure','rigorous_merged_cell_enclosure'):continue
        checks.append({'name':p.name+':ordered_finite_exact_endpoints','passed':len(j['moments'])==17 and all(interval(m)[0]<=interval(m)[1] for m in j['moments'])})
        # Only compare complete identical angular cells, never row averages.
        reference=root/'pilot/results'/('qt_'+j['cell']+'_a8_c512.json')
        if not reference.exists():continue
        r=json.loads(reference.read_text())
        if list(j['integrated_bounds_rational'])!=list(r['bounds_rational']):continue
        overlap=[]
        for g,m in zip(j['moments'],r['moments']):
            gl,gu=interval(g);rl,ru=interval(m);overlap.append(max(gl,rl)<=min(gu,ru))
        checks.append({'name':p.name+':Riemann_overlap_all17','passed':all(overlap)})
        comparison.append({'cell':j['cell'],'gauss_file':p.name,'riemann_file':reference.name,
          'gauss_max_radius_density':j['normalized_max_radius_diagnostic'],
          'riemann_max_radius_density':r['normalized_max_radius_diagnostic'],
          'radius_improvement_ratio':r['normalized_max_radius_diagnostic']/j['normalized_max_radius_diagnostic'],
          'gauss_seconds':j['seconds'],'riemann_seconds':r['seconds'],
          'timing_limit':'Observed runs under varying concurrent load; not a controlled benchmark or a global cost estimate.'})
    return {'passed':all(x['passed'] for x in checks),'checks':checks,'comparisons':comparison,
      'claim_limit':'Overlap is a necessary consistency check, not an independent test of the shared physical integrand. No global cover has been run.'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args();out=audit(Path(__file__).resolve().parent);Path(a.output).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
    if not out['passed']:raise SystemExit(2)
