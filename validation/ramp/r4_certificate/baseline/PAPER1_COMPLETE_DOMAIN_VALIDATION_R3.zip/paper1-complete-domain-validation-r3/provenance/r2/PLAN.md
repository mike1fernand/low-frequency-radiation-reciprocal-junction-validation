# Paper 1: checked continuation plan

## Objective and controlling state

Continue from the completed Extension 1 validation package. Determine whether the remaining exact-lattice integration bounds can be obtained by a reproducible method, implementing and testing the required primitives before allocating a full-domain campaign. Preserve the present physical claims unless a confirmed error or a complete stronger result justifies changing them.

Authority: `paper1-validation-repository-pass18-rc4-validation-extension1.zip`, SHA-256 `0b64dd1c22622fc1ce85880100a863e57f691d287a60a33e0ce211bb3ed274ea`. The completed N160 packet refinement, selected surface prediction, fixed-matrix certificate and manuscript are retained. This continuation does not repeat them. The reference model is the nine-bond unit bare bulk at E=36/25, the original six X/R source sections, actual phase conventions and lower-two spectral observable. These are explicit model settings, not inferred universal properties.

## Decisions about all remaining work

| Issue | Work now | Condition for a stronger paper claim |
|---|---|---|
| Global exact-lattice error bounds | Derive and independently review a radial contour route; implement four full-cell pilots; measure rigorously enclosed widths and cost. Advance to global coverage only after mathematical and practical gates pass. | Both complete source-projected matrix errors satisfy the existing operator-norm budgets, including center displacement, arithmetic, all charts and the regular exterior. |
| Finite-window versus stationary comparison | Confirm the existing numerical interpretation remains applicable. Preserve q/v, normalization and reporting window. | A stronger identity needs a separate phase-resolved causal calculation and enclosed readout errors. This is future work, not a necessary change to the current claim. |
| Numerical refinement | Reuse the completed full N160 evidence. | More refinement only to diagnose a concrete discrepancy that can change the paper's conclusion. |
| Reproducibility | Bind new code, inputs, exact interval results and commands; test the delivered addition after fresh extraction. | Same-host replay does not become second-platform or independent-person replication. |
| Public release | Carry forward exact unresolved metadata/licensing/archive decisions from the existing package. Prepare the new work for private reproducible handoff. | Do not invent publication identifiers, permissions, human reviews or a GitHub destination. |
| Connection failures | Use short resumable stages and visible milestones; preserve outputs before starting another stage. | The earlier user-visible connection cause remains undiagnosed without the actual error/time or client logs. It is not a scientific uncertainty. |

## Plan improvements checked before implementation

1. **Replace direct singular quadrature by an analytic radial contour, if the proof passes.** For t=x+iy in a maximum-coordinate chart, the imaginary part of each bond term has sign y for 0<x<=R=acos(1/4); the active bond directions span the three-dimensional space. This excludes off-real resolvent poles in the required strip. The retarded convention is (D-E-i0)^(-1), so the full Green integral uses a lower-half-plane detour. This captures the PV and endpoint contributions without separately subtracting singular eigenvector terms. Check the sign on a scalar pole with unequal endpoints and check the source's holomorphic extension.
2. **Use a fixed contour enclosing the lower pair.** Independent derivations identify s=acos(3/4) as a separator: at t=s, lambda_2<=11/8<E and lambda_3>=3/2>E. Exact margins are 13/200 and 3/50. Together with the existing root census, a positive counterclockwise rectangle spanning [s,R] encloses exactly the qT poles, including lower-pair degeneracies. A reviewer must challenge the endpoint bound and pole classification before numerical acceptance.
3. **Enclose whole angular cells.** Use dyadic rectangles of positive area representing an ordinary direction, a coordinate plane, an axis and the body diagonal. A pointwise root or residue check does not validate its neighborhood. Refine the same physical cells, not just progressively smaller domains, to measure contraction.
4. **Retain complete source moments and geometry.** Use 17 signed moments with t^2/pi^3 for positive-octant chart integration; never conjugate complex t in the continued source formula, discard X/R cross terms, or permute the physical source with the chart. Check y and z chart orientation as well as x.
5. **Select a global algorithm from proved widths, not mesh agreement.** Start with transparent interval segment/cell enclosures. If their cost is prohibitive at the required global error, identify the validated higher-order quadrature needed; do not launch a futile larger mesh or claim convergence from ordinary quadrature agreement.

## Execution stages and checks

| Stage | Work | Check before continuing | Action if it fails |
|---|---|---|---|
| 0: recovery and environment | Read current plan/results; validate original archive identity; use existing pinned environment; record versions. | Inputs match; NumPy, SciPy, SymPy and python-flint import. | Fix environment/path only, then repeat the failed check. |
| 1: mathematical review | Derive full Green and qT contour formulas from the actual bond sum and source projection; prove endpoint and nonreal-pole statements. | Independent derivation, exact rational algebra, sign/normalization and multiple-root review. | Correct the derivation; no numerical promotion of an unproved contour. |
| 2: primitives | Implement ball-valued symbol, source moments, chart map, integrator, serialization and diagnostics. | Finite outward intervals, scalar asymmetric-PV test, exact plane/axis limits, source parity and selected finite numerical comparisons. | Correct the minimum affected code and recheck its dependencies. |
| 3: bounded pilots | Run the four positive-area cells with radial and angular refinements; include full retarded Green, qT cluster and regular exterior. | Each returned interval encloses its entire domain by construction; contractions compare fixed domains; report absolute and per-area widths, runtime and work counts. | Preserve failure; distinguish excessive enclosure width from a physics discrepancy. Modify the local method before expanding. |
| 4: global feasibility | Use measured results and a complete coverage/error-budget design to decide whether a full campaign is practical. | A justified global error allocation and affordable validated quadrature; all exceptional regions handled; no omitted source or exterior pieces. | Keep the exact-lattice guarantee unresolved, specify the missing algorithm and retain valid pilot results. |
| 5: full campaign, conditional on stage 4 | Integrate all three positive-octant charts, sum outwardly, reconstruct every matrix occurrence and include distance from selected cached centers. | Prove ||1.69 Delta g||_2<=0.020 and ||1.69 Delta Q||_2<=0.005 with exact Q positive semidefinite. Recheck the conditional bridge on the stated budgets. | Diagnose dominant contributions; do not transfer the fixed-input certificate or loosen criteria silently. |
| 6: review and delivery | Inspect changed code/results for material and open referee issues; bind hashes; run the exported addition from a clean extraction. | Exact runnable commands, fresh result records, unchanged baseline, all limits stated once at the claims they affect. | Fix affected content and replay only affected checks; do not rerun completed large simulations. |

Stage 4 has a genuine decision: this plan completes when either all global obligations pass or a tested, precisely identified mathematical/computational obstacle prevents a defensible full campaign. It does not declare an exact-lattice theorem merely because pilots ran. If a new tractable correction resolves the obstacle, apply it and reassess instead of stopping at the first difficulty.

## Batching and stopping rules

Keep individual computational checkpoints around 30 seconds where practical. Bind model, source, cell, contour, precision, algorithm and subdivision settings to each output; write atomically. Resume from matching completed outputs only. One stage's measured widths and cost determine the next stage. No unbounded retry loop and no whole-campaign restart after a local failure.

Check after derivation changes, each new numerical primitive, the first pilot, each refinement level, any material code correction, matrix assembly if reached, and final export. Additional review passes must address a concrete remaining risk. Deterministic interval bounds and successful checks are evidence; no calibrated 95% probability is inferred from solver agreement.

The new work belongs in a validation addition. A manuscript change requires either a confirmed correction or a genuinely new result that materially improves the physical argument. Development history and repeated safeguards do not justify added paper length.

## Implementation outcome and final plan check

Stages 0 through 4 and the delivery review were implemented. The global and local contour arguments passed separate mathematical reviews. All four whole-cell qT/Green pilots and all four higher-order qT cells completed, with exact row coverage where staged. The higher-order method tightened three cells and widened the plane result; no uniform improvement is claimed. Source/settings checks and finite numerical comparison were kept distinct from rigorous enclosure proofs.

Stage 5 was not launched: no complete adaptive cover/error-allocation/cost plan establishes that its global operator budgets can be reached with the tested configuration. This is a feasibility hold, not a proof of impossibility or a claim that every further algorithm would fail. Nonuniform budgeting and sharper bounds remain valid options. The existing paper claims do not require this optional stronger theorem.

The implementation improved the plan by proving whole-cell local separators, adopting a rigorous higher-order remainder, subdividing slow cells into independently saved rows, and checking their exact reassembly. Each change was checked at its mathematical and software dependencies. No physical source, observable, selected result or manuscript was changed.
