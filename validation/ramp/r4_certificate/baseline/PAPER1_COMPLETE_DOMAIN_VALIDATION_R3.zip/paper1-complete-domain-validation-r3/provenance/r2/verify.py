#!/usr/bin/env python3
"""Verify this standalone validation addition and replay bounded checks.

All live outputs are written to an external work copy. A completed stage is
reused only when its command, package identity and output file hashes match.
This runner never treats a pilot as a full-zone integration certificate.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
BASELINE_SHA256 = '0b64dd1c22622fc1ce85880100a863e57f691d287a60a33e0ce211bb3ed274ea'


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, indent=2) + '\n')
    os.replace(temp, path)


def verify_manifest(root=ROOT):
    manifest = json.loads((root / 'MANIFEST.json').read_text())
    for name, expected in manifest['files'].items():
        rel = Path(name)
        if rel.is_absolute() or '..' in rel.parts:
            raise ValueError('Unsafe manifest path: ' + name)
        p = root / rel
        if not p.is_file() or sha(p) != expected:
            raise ValueError('File identity mismatch: ' + name)
    return manifest


def tasks(work, out):
    python = sys.executable
    commands = [
        ('contour_derivation', [python, '-B', str(work/'math/check_contour_derivation.py'),
          '--bulk-source', str(work/'provenance/combined_tetra_diagnostic.py'),
          '--shell-proof', str(work/'provenance/RADIAL_SHELL_PROOF.md'),
          '--output', str(out/'contour_derivation.json')]),
        ('source_moments', [python, '-B', str(work/'pilot/check_source_moments.py')]),
        ('local_separators', [python, '-B', str(work/'math/check_local_separators.py'),
          '--output', str(out/'local_separators.json')]),
        ('qt_axes', [python, '-B', str(work/'pilot/check_qt_axes.py')]),
        ('scalar_contour', [python, '-B', str(work/'green/green_cell_pilot.py'),
          '--scalar-only', '--output', str(out/'scalar_contour.json')]),
        ('gauss_manufactured', [python, '-B', str(work/'high_order/validate_gauss.py')]),
        ('higher_order_evidence', [python, '-B', str(work/'high_order/audit_results.py'),
          '--output', str(out/'higher_order_evidence.json')]),
        ('merge_guards', [python, '-B', str(work/'high_order/check_merge_guards.py'),
          '--output', str(out/'merge_guards.json')]),
        ('coverage_guards', [python, '-B', str(work/'high_order/check_audit_coverage.py'),
          '--output', str(out/'coverage_guards.json')]),
        ('higher_order_axis', [python, '-B', str(work/'high_order/qt_gauss_pilot.py'),
          '--cell', 'axis', '--angular-n', '2', '--contour-n', '32', '--adaptive',
          '--density-tolerance', '1/100', '--output', str(out/'higher_order_axis.json')]),
    ]
    for qt, green in [('ordinary','ordinary'), ('coordinate_plane','plane'),
                      ('axis','axis'), ('body_diagonal','body')]:
        commands.append(('qt_' + qt, [python, '-B', str(work/'pilot/qt_cell_pilot.py'),
          '--cell', qt, '--angular-n', '4', '--contour-n', '256',
          '--output', str(out/('qt_' + qt + '.json'))]))
        commands.append(('green_' + green, [python, '-B', str(work/'green/green_cell_pilot.py'),
          '--cell', green, '--angular', '2', '--radial', '64',
          '--output', str(out/('green_' + green + '.json'))]))
    return commands


def expected_output(name, work, out):
    special = {
        'source_moments': work/'pilot/results/SOURCE_MOMENT_CHECKS.json',
        'qt_axes': work/'pilot/results/QT_AXIS_CHECKS.json',
        'gauss_manufactured': work/'high_order/MANUFACTURED_CHECKS.json',
    }
    return special.get(name, out/(name+'.json'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--baseline-archive', type=Path)
    parser.add_argument('--stored-only', action='store_true')
    parser.add_argument('--stage', help='Run only this named live stage.')
    parser.add_argument('--timeout', type=int, default=60)
    args = parser.parse_args()
    if args.timeout <= 0:
        parser.error('timeout must be positive')
    out = args.output_dir.resolve()
    if out == ROOT or ROOT in out.parents:
        parser.error('output-dir must be outside the validation addition')
    manifest = verify_manifest()
    baseline = 'not supplied; standalone tests use included model provenance'
    if args.baseline_archive:
        if sha(args.baseline_archive) != BASELINE_SHA256:
            raise ValueError('Baseline archive identity does not match Extension 1')
        baseline = 'matched exact Extension 1 archive'
    out.mkdir(parents=True, exist_ok=True)
    package_id = sha(ROOT/'MANIFEST.json')
    runtime = {'python': sys.version, 'executable': sys.executable}
    if not args.stored_only:
        import importlib
        runtime['dependencies'] = {name: importlib.import_module(name).__version__
            for name in ['numpy','scipy','sympy','mpmath','flint']}
    identity_path = out/'REPLAY_IDENTITY.json'
    identity = {'manifest_sha256': package_id, 'runtime': runtime}
    if identity_path.exists():
        if json.loads(identity_path.read_text()) != identity:
            raise ValueError('Replay directory belongs to a different package/runtime; choose a fresh output directory')
    else:
        atomic_json(identity_path, identity)
    summary = {'status':'passed', 'baseline':baseline, 'files_verified':len(manifest['files']),
        'manifest_sha256':package_id, 'runtime':runtime, 'live_stages':[],
        'claim':'Standalone bounded validation addition; no full-zone integral or exact-lattice floor certified.'}
    if not args.stored_only:
        work = out/'work'
        if not work.exists():
            shutil.copytree(ROOT, work, ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        # Replay checkers may update their own result records in this work copy;
        # code and input bytes must continue to match the immutable delivery.
        for name, digest in manifest['files'].items():
            if name.endswith(('.py','.py.snapshot','.md','.csv','.txt')):
                if sha(work/name) != digest:
                    raise ValueError('Replay code/input changed: ' + name)
        commands = tasks(work, out)
        if args.stage:
            commands = [(n,c) for n,c in commands if n == args.stage]
            if not commands:
                parser.error('unknown stage')
        for name, command in commands:
            record_path = out/(name + '_execution.json')
            key = {'command':command, 'manifest_sha256':package_id}
            if record_path.exists():
                old = json.loads(record_path.read_text())
                if old.get('key') == key and old.get('returncode') == 0 and all(
                    (out/p).is_file() and sha(out/p)==h for p,h in old.get('output_sha256',{}).items()
                ) and old.get('output_sha256'):
                    summary['live_stages'].append({'name':name,'status':'reused_matching_completed_stage'})
                    continue
            start = time.monotonic()
            expected = expected_output(name, work, out)
            # Require fresh evidence from this execution, even if an inherited
            # record happened to have identical contents.
            if expected.exists():
                expected.unlink()
            env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', OPENBLAS_NUM_THREADS='1')
            try:
                completed = subprocess.run(command, cwd=work, env=env,
                    capture_output=True, text=True, timeout=args.timeout)
                returncode, stdout, stderr = completed.returncode, completed.stdout, completed.stderr
            except subprocess.TimeoutExpired:
                returncode, stdout, stderr = 124, '', 'Stage exceeded declared timeout; prior completed stages retained.'
            changed = {}
            if returncode == 0:
                if not expected.is_file():
                    returncode, stderr = 3, stderr + '\nExpected result was not freshly written.'
                else:
                    result = json.loads(expected.read_text())
                    status = result.get('status', '')
                    passed = result.get('passed') is True or status.startswith('passed') or status in (
                        'rigorous_cell_enclosure', 'certified_partial_cell_enclosure')
                    if not passed:
                        returncode, stderr = 3, stderr + '\nResult did not pass its declared gate.'
                    changed[str(expected.relative_to(out))] = sha(expected)
            (out/(name+'.stdout.txt')).write_text(stdout)
            (out/(name+'.stderr.txt')).write_text(stderr)
            record = {'key':key,'returncode':returncode,'seconds':time.monotonic()-start,
                      'output_sha256':changed}
            atomic_json(record_path, record)
            summary['live_stages'].append({'name':name,'status':'passed' if returncode==0 else 'failed',
                                          'seconds':record['seconds']})
            atomic_json(out/'REPLAY_SUMMARY.json',summary)
            print(name + ': ' + ('passed' if returncode==0 else 'failed'), flush=True)
            if returncode:
                summary['status']='failed'
                atomic_json(out/'REPLAY_SUMMARY.json',summary)
                raise SystemExit(returncode)
    atomic_json(out/'REPLAY_SUMMARY.json',summary)
    print(json.dumps({'status':summary['status'],'files_verified':summary['files_verified'],
                      'live_stages':len(summary['live_stages'])}))


if __name__ == '__main__':
    main()
