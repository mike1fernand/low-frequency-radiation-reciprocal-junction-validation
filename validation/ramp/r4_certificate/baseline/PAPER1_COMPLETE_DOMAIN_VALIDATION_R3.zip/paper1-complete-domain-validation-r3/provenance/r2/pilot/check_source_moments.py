#!/usr/bin/env python3
"""Independent finite-bond/source checks of the analytic continuation primitive.

These point checks catch implementation/normalization errors; they do not
replace the analytic identity or certify an angular integral.
"""
import hashlib,json,time
from pathlib import Path
from flint import arb,acb,acb_mat,ctx
from source_moments import moment_values,coordinate_values,ball_serialization
ctx.prec=160
BONDS=((1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,-1,0),(1,0,1),(1,0,-1),(0,1,1),(0,1,-1))

def independently_projected(t,u,v,chart):
 k=coordinate_values(t,u,v,chart);D=acb_mat(3,3)
 for b in BONDS:
  phase=sum((k[i]*b[i] for i in range(3)),acb(0))
  weight=2*(1-phase.cos())/sum(x*x for x in b)
  for i in range(3):
   for j in range(3):D[i,j]+=weight*b[i]*b[j]
 for i in range(3):D[i,i]-=arb(36)/25
 R=D.inv()
 Fp=acb_mat(3,2);Fm=acb_mat(3,2)
 for y in (-1,0):
  for z in (-1,0):
   src=(arb(1)/2,(2*y+1)/(2*arb(2).sqrt()),(2*z+1)/(2*arb(2).sqrt()))
   phase=k[1]*y+k[2]*z
   ep=(-acb(0,1)*phase).exp();em=(acb(0,1)*phase).exp()
   for F,e in ((Fp,ep),(Fm,em)):
    F[0,0]+=e*src[0];F[1,1]+=e*src[1];F[2,1]+=e*src[2]
 H=Fm.transpose()*R*Fp
 fac=acb(t)**2/arb.pi()**3
 vals=[fac*(d*k[0]).cos()*H[0,0] for d in range(6)]
 vals +=[fac*(d*k[0]).cos()*H[1,1] for d in range(6)]
 vals +=[fac*acb(0,1)*(d*k[0]).sin()*H[0,1] for d in range(1,6)]
 wrongH=Fp.conjugate().transpose()*R*Fp
 wrong=[fac*(d*k[0]).cos()*wrongH[0,0] for d in range(6)]
 return vals,wrong

start=time.monotonic();checks=[]
for chart in range(3):
 for imag in (arb(0),-arb(1)/8):
  t=acb(arb(9)/8,imag);u=arb(3)/8;v=arb(5)/8
  got=moment_values(t,u,v,chart);want,wrong=independently_projected(t,u,v,chart)
  assert all(a.overlaps(b) for a,b in zip(got,want))
  max_difference=max(float(abs(a-b).upper()) for a,b in zip(got,want))
  assert max_difference<1e-40
  rejected_conjugation=any(not a.overlaps(b) for a,b in zip(got[:6],wrong))
  if imag!=0:assert rejected_conjugation
  checks.append({'chart':chart,'complex_t':imag!=0,'all_17_moments_overlap':True,
     'maximum_difference_bound_diagnostic':max_difference,
     'wrong_complex_conjugation_rejected':rejected_conjugation})
# Chart relabelling must not rotate the physical source: x/y charts differ.
x=moment_values(acb(arb(9)/8,-arb(1)/8),arb(3)/8,arb(5)/8,0)
y=moment_values(acb(arb(9)/8,-arb(1)/8),arb(3)/8,arb(5)/8,1)
assert any(not a.overlaps(b) for a,b in zip(x,y))
out={'status':'passed','scope':'six point implementation comparisons; no integral error estimate',
 'precision_bits':ctx.prec,'checks':checks,'incorrect_source_axis_permutation_rejected':True,
 'seconds':time.monotonic()-start,
 'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
  (Path(__file__),Path(__file__).with_name('source_moments.py'))}}
path=Path(__file__).with_name('results')/'SOURCE_MOMENT_CHECKS.json'
path.parent.mkdir(exist_ok=True);path.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
