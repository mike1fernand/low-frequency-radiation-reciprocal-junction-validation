#!/usr/bin/env python3
"""Validated interval-Riemann qT contour integrals on fixed angular cells.

This certifies the entire declared cells, not just sampled angles. The analytic
proof identifies the two lower-band residues between s=acos(3/4) and R=acos(1/4).
Only Im of the lower 3-edge path is required by Schwarz reflection. Each segment
is enclosed over its whole real path parameter and angular rectangle, then
multiplied by the exact positive parameter lengths and angular area. Finite
interval sums are enclosures regardless of accuracy. Failure to invert any
interval matrix aborts instead of supplying a sampled or guessed bound.
"""
from pathlib import Path
import argparse, hashlib, json, os, time
from fractions import Fraction
from flint import arb,acb,ctx
from source_moments import moment_values,ball_serialization

CELLS={
 'ordinary':('3/8','7/16','5/8','11/16'),
 'coordinate_plane':('7/16','1/2','0','1/32'),
 'axis':('0','1/32','0','1/32'),
 'body_diagonal':('31/32','1','31/32','1'),
}

def exact(x):
    q=Fraction(x); return arb(q.numerator)/q.denominator

def interval(a,b):
    # Union of exact/rational endpoint enclosures outwardly includes [a,b].
    return a.union(b)

def integrate_cell(name, angular_n, contour_n, chart=0, height='1/8'):
    if name not in CELLS: raise ValueError('unknown cell')
    if not isinstance(angular_n,int) or angular_n <= 0: raise ValueError('angular_n must be positive integer')
    if not isinstance(contour_n,int) or contour_n <= 0: raise ValueError('contour_n must be positive integer')
    if chart not in (0,1,2): raise ValueError('chart must be 0, 1, or 2')
    if ctx.prec < 80: raise ValueError('precision must be at least 80 bits')
    if Fraction(height) <= 0: raise ValueError('height must be positive')
    bounds=CELLS[name]; ulo,uhi,vlo,vhi=map(exact,bounds)
    du=(uhi-ulo)/angular_n; dv=(vhi-vlo)/angular_n
    s=(arb(3)/4).acos(); R=(arb(1)/4).acos(); h=exact(height)
    points=[acb(s),acb(s,-h),acb(R,-h),acb(R)]
    accum=[acb(0) for _ in range(17)]; calls=0
    start=time.monotonic()
    for i in range(angular_n):
      u=interval(ulo+i*du,ulo+(i+1)*du)
      for j in range(angular_n):
        v=interval(vlo+j*dv,vlo+(j+1)*dv)
        for a,b in zip(points[:-1],points[1:]):
          dz=(b-a)/contour_n
          for k in range(contour_n):
            # z=a+(b-a)*r, r real; this enclosure deliberately includes the
            # full segment rectangle and is not a midpoint quadrature claim.
            r=interval(arb(k)/contour_n,arb(k+1)/contour_n)
            t=a+(b-a)*r
            values=moment_values(t,u,v,chart)
            for m,val in enumerate(values): accum[m]+=val*dz*du*dv
            calls+=1
    qt=[a.imag for a in accum]
    if not all(q.is_finite() for q in qt): raise ArithmeticError('nonfinite integrated enclosure')
    area=(uhi-ulo)*(vhi-vlo)
    return {'cell':name,'chart':chart,'bounds_rational':bounds,
        'angular_partition_per_axis':angular_n,'segments_per_contour_edge':contour_n,
        'precision_bits':ctx.prec,'height_rational':height,'integrand_calls':calls,
        'seconds':time.monotonic()-start,'moments':[ball_serialization(q) for q in qt],
        'normalized_max_radius_diagnostic':max(float(q.rad()/area) for q in qt),
        'max_radius_diagnostic':max(float(q.rad()) for q in qt),
        'max_abs_midpoint_diagnostic':max(abs(float(q.mid())) for q in qt),
        'status':'rigorous_cell_enclosure',
        'claim_limit':'Only this angular cell, at E=36/25. No global qT error or floor certificate.'}

def main():
 p=argparse.ArgumentParser();p.add_argument('--cell',choices=CELLS,required=True)
 p.add_argument('--angular-n',type=int,default=1);p.add_argument('--contour-n',type=int,default=64)
 p.add_argument('--chart',type=int,default=0);p.add_argument('--bits',type=int,default=128)
 p.add_argument('--height',default='1/8');p.add_argument('--output',required=True)
 a=p.parse_args();t=time.monotonic()
 try:
  if a.bits < 80: raise ValueError('precision must be at least 80 bits')
  ctx.prec=a.bits
  out=integrate_cell(a.cell,a.angular_n,a.contour_n,a.chart,a.height)
 except Exception as e:
  status='blocked_no_enclosure' if isinstance(e,(ZeroDivisionError,ArithmeticError)) else 'failed_execution'
  out={'status':status,'cell':a.cell,'chart':a.chart,
   'bounds_rational':CELLS[a.cell],'angular_partition_per_axis':a.angular_n,
   'segments_per_contour_edge':a.contour_n,'precision_bits':ctx.prec,
   'height_rational':a.height,'error_type':type(e).__name__,'error':str(e),
   'seconds':time.monotonic()-t}
 out['source_sha256']={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in
  [Path(__file__),Path(__file__).with_name('source_moments.py')]}
 dest=Path(a.output);dest.parent.mkdir(parents=True,exist_ok=True)
 temporary=dest.with_name(dest.name+'.tmp')
 temporary.write_text(json.dumps(out,indent=2)+'\n')
 os.replace(temporary,dest)
 print(json.dumps({k:v for k,v in out.items() if k not in ('moments','source_sha256')},indent=2))
 if out['status']!='rigorous_cell_enclosure':raise SystemExit(2)
if __name__=='__main__':main()
