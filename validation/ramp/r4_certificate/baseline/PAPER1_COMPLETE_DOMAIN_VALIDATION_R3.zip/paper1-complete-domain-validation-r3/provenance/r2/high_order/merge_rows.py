#!/usr/bin/env python3
"""Verify source/settings identities and exact row coverage before summing."""
import argparse,hashlib,json,sys
from pathlib import Path
from fractions import Fraction
from flint import arb,ctx
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'pilot'))
from source_moments import ball_serialization

def decode(x):
    def endpoint(e):return arb(int(e['mantissa']))*arb(2)**int(e['exponent2'])
    return endpoint(x['lower']).union(endpoint(x['upper']))

def merge(paths):
    js=[json.loads(Path(p).read_text()) for p in paths]
    if not js:raise ValueError('no rows')
    first=js[0];n=first['angular_partition_per_axis'];ctx.prec=first['precision_bits']
    identity={k:v for k,v in first['run_arguments'].items() if k not in ('output','row','max_seconds')}
    if sorted(j['angular_row'] for j in js)!=list(range(n)):raise ValueError('missing or duplicate rows')
    a,b,c,d=map(Fraction,first['bounds_rational']);du=(b-a)/n
    base=Path(__file__).resolve().parents[1]
    for j in js:
        if j['status']!='rigorous_cell_enclosure':raise ValueError('uncertified row')
        if {k:v for k,v in j['run_arguments'].items() if k not in ('output','row','max_seconds')}!=identity:raise ValueError('settings changed')
        if j['source_sha256']!=first['source_sha256']:raise ValueError('source identities differ')
        if any(hashlib.sha256((base/k).read_bytes()).hexdigest()!=v for k,v in j['source_sha256'].items()):raise ValueError('source changed; refuse resume')
        row=j['angular_row'];expected=[a+row*du,a+(row+1)*du,c,d]
        if list(map(Fraction,j['integrated_bounds_rational']))!=expected:raise ValueError('row geometry changed')
        if len(j['moments'])!=17:raise ValueError('wrong moment count')
    result=[sum((decode(j['moments'][m]) for j in js),arb(0)) for m in range(17)]
    area=arb((b-a).numerator)/(b-a).denominator*arb((d-c).numerator)/(d-c).denominator
    return {'status':'rigorous_merged_cell_enclosure','cell':first['cell'],'chart':first['chart'],
      'integrated_bounds_rational':first['bounds_rational'],'moments':[ball_serialization(x) for x in result],
      'normalized_max_radius_diagnostic':max(float(x.rad()/area) for x in result),
      'max_radius_diagnostic':max(float(x.rad()) for x in result),'seconds':sum(j['seconds'] for j in js),
      'integrand_calls':sum(j['integrand_calls'] for j in js),'source_sha256':first['source_sha256'],
      'row_sha256':{Path(p).name:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths},
      'merger_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'claim_limit':'Only this declared x-chart cell. No full angular cover or exact-lattice floor.'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('rows',nargs='+');p.add_argument('--output',required=True);a=p.parse_args()
    out=merge(a.rows);dest=Path(a.output)
    if dest.exists():raise FileExistsError(dest)
    tmp=dest.with_name(dest.name+'.partial');tmp.write_text(json.dumps(out,indent=2)+'\n');tmp.replace(dest)
    print(json.dumps({k:v for k,v in out.items() if k not in ('moments','source_sha256','row_sha256')},indent=2))
