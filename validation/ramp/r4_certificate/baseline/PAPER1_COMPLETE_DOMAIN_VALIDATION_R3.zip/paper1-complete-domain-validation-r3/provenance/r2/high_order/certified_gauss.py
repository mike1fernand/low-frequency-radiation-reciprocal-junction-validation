"""Tensor 3-point Gauss with Cauchy-tail bounds and outward Arb arithmetic.

The callback must be a holomorphic formula in each enlarged coordinate and
must raise, or return a nonfinite ball, whenever that cannot be established.
Finite interval evaluations alone do not establish holomorphy for arbitrary
callbacks: the caller supplies that proof (rational/trigonometric functions
with a finite interval matrix inverse in the present application).
"""
from itertools import product
from flint import arb, acb

class NeighborhoodFailure(ArithmeticError):
    def __init__(self,axis):
        self.axis=axis
        super().__init__('no certified complex neighborhood on axis '+str(axis))

def finite_values(callback, xs):
    result = list(callback(*xs))
    if not all(v.is_finite() for v in result):
        raise ArithmeticError('nonfinite analytic-neighborhood enclosure')
    return result


def gauss3_box(callback, bounds, radius_multipliers=(2, 4, 8, 16),density_tolerance=None):
    """Enclose the integral on a real 3-box. All weights normalized to sum 1.

    On the disk |z-c_j|<=rho_j, with the other parameters anywhere in their
    real intervals, |f_m|<=M_jm. Cauchy bounds the Taylor tail starting at
    degree 6 by M_jm*r_j**6/(1-r_j), r_j=h_j/rho_j<1. Both normalized
    integration and Gauss quadrature have operator norm 1. Their difference
    is bounded by twice that tail. Telescoping the three tensor factors
    gives volume*sum_j[2*M_jm*r_j**6/(1-r_j)].
    """
    center=[(a+b)/2 for a,b in bounds]
    half=[(b-a)/2 for a,b in bounds]
    if not all(h > 0 for h in half):
        raise ValueError('bounds must have strictly positive widths')
    volume=8*half[0]*half[1]*half[2]
    real_boxes=[acb(a.union(b)) for a,b in bounds]
    errors=[]; chosen=[]; calls=0; rejected=0
    for axis in range(3):
        options=[]
        for mult in radius_multipliers:
            if mult <= 1: raise ValueError('radius multiplier must exceed 1')
            radius=half[axis]*mult
            xs=list(real_boxes)
            # The square contains the complex disk; it is deliberately
            # larger, so inverse existence over the square suffices.
            xs[axis]=acb(center[axis]+arb(0,radius.abs_upper()),
                         arb(0,radius.abs_upper()))
            try:
                vals=finite_values(callback,xs); calls+=1
                r=half[axis].abs_upper()/radius.lower()
                if not (r < 1): raise ArithmeticError('noncontracting radius')
                err=[2*abs(v).upper()*r**6/(1-r) for v in vals]
                options.append((float(max(x.upper() for x in err)),err,mult))
            except (ArithmeticError, ZeroDivisionError, ValueError):
                calls+=1; rejected+=1
        if not options:
            raise NeighborhoodFailure(axis)
        _,err,mult=min(options,key=lambda x:x[0]); errors.append(err);chosen.append(mult)
    if density_tolerance is not None:
        if not density_tolerance>0:raise ValueError('density tolerance must be positive')
        per_axis=[max(e.upper() for e in ee) for ee in errors]
        if not sum(per_axis)<density_tolerance:
            # This is an accuracy split, not evidence of a pole.
            axis=max(range(3),key=lambda j:float(per_axis[j]))
            raise NeighborhoodFailure(axis)
    root=(arb(3)/5).sqrt()
    nodes=[-root,arb(0),root]
    weights=[arb(5)/18,arb(4)/9,arb(5)/18]
    accum=[acb(0) for _ in errors[0]]
    for ijk in product(range(3), repeat=3):
        xs=[acb(center[j]+half[j]*nodes[ijk[j]]) for j in range(3)]
        vals=finite_values(callback,xs); calls+=1
        if len(vals)!=len(accum):raise ValueError('callback size changed')
        weight=weights[ijk[0]]*weights[ijk[1]]*weights[ijk[2]]
        for m,val in enumerate(vals):accum[m]+=weight*val
    remainder=[volume*sum(errors[j][m] for j in range(3)) for m in range(len(accum))]
    q=[x*volume for x in accum]
    out=[x+acb(arb(0,e.upper()),arb(0,e.upper())) for x,e in zip(q,remainder)]
    return out,{'calls':calls,'rejected_neighborhoods':rejected,
                'chosen_radius_multipliers':chosen,
                'remainder_max_diagnostic':float(max(e.upper() for e in remainder))}

def adaptive_gauss3_box(callback,bounds,radius_multipliers=(2,4,8,16),depth=0,max_depth=18,density_tolerance=None):
    """Bisect the failed coordinate; summing child enclosures is rigorous."""
    try:
        out,meta=gauss3_box(callback,bounds,radius_multipliers,density_tolerance)
        meta['leaf_boxes']=1;meta['maximum_split_depth']=depth
        return out,meta
    except NeighborhoodFailure as e:
        if depth>=max_depth:raise
        axis=e.axis;mid=sum(bounds[axis])/2
        left=list(bounds);right=list(bounds)
        left[axis]=(bounds[axis][0],mid);right[axis]=(mid,bounds[axis][1])
        a,ma=adaptive_gauss3_box(callback,left,radius_multipliers,depth+1,max_depth,density_tolerance)
        b,mb=adaptive_gauss3_box(callback,right,radius_multipliers,depth+1,max_depth,density_tolerance)
        return [x+y for x,y in zip(a,b)],{
            'calls':ma['calls']+mb['calls'],
            'rejected_neighborhoods':ma['rejected_neighborhoods']+mb['rejected_neighborhoods'],
            'leaf_boxes':ma['leaf_boxes']+mb['leaf_boxes'],
            'maximum_split_depth':max(ma['maximum_split_depth'],mb['maximum_split_depth']),
            'chosen_radius_multipliers':['adaptive']}
