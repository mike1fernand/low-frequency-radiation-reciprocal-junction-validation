"""Arb source-projected resolvent moments at exact E=36/25.

Moment order: a_0..a_5, c_0..c_5, b_1..b_5.  All values include
positive-octant normalization 1/pi**3 and the cube-ray Jacobian t**2.
For complex t, the source products are analytic continuations of their
real-t values.  Conjugating t or the source on the contour is incorrect.
No angular permutation is applied to the physical source x direction.
"""
from flint import arb, acb, acb_mat


def coordinate_values(t, u, v, chart=0):
    t,u,v=acb(t),acb(u),acb(v)
    if chart == 0: return (t,t*u,t*v)
    if chart == 1: return (t*u,t,t*v)
    if chart == 2: return (t*u,t*v,t)
    raise ValueError('chart must be 0, 1, or 2')


def symbol_matrix(t,u,v,chart=0):
    k=coordinate_values(t,u,v,chart)
    c=[x.cos() for x in k]; s=[x.sin() for x in k]
    return acb_mat([[6-2*c[i]*(1+c[(i+1)%3]+c[(i+2)%3])
                     if i==j else 2*s[i]*s[j]
                     for j in range(3)] for i in range(3)])


def shifted_matrix(t,u,v,chart=0):
    D=symbol_matrix(t,u,v,chart)
    E=arb(36)/25
    for i in range(3): D[i,i]-=E
    return D


def moment_values(t,u,v,chart=0):
    """Return 17 complex balls enclosing every input represented by t,u,v."""
    t=acb(t); kx,ky,kz=coordinate_values(t,u,v,chart)
    R=shifted_matrix(t,u,v,chart).inv()
    root2=arb(2).sqrt()
    A=2*(ky/2).cos()*(kz/2).cos()
    B=root2*(ky/2).sin()*(kz/2).cos()
    C=root2*(ky/2).cos()*(kz/2).sin()
    aa=A*A*R[0,0]
    cc=B*B*R[1,1]+2*B*C*R[1,2]+C*C*R[2,2]
    bb=A*(B*R[0,1]+C*R[0,2])
    factor=t*t/(arb.pi()**3)
    out=[factor*aa*(d*kx).cos() for d in range(6)]
    out += [factor*cc*(d*kx).cos() for d in range(6)]
    out += [factor*bb*(d*kx).sin() for d in range(1,6)]
    if not all(x.is_finite() for x in out):
        raise ArithmeticError('nonfinite resolvent moment enclosure')
    return out


def ball_serialization(x):
    """Exact binary endpoints plus explicitly diagnostic decimal summaries."""
    def endpoint(a):
        m,e=a.man_exp()
        return {'mantissa':str(m),'exponent2':int(e)}
    def realball(a):
        return {'lower':endpoint(a.lower()), 'upper':endpoint(a.upper()),
                'midpoint_diagnostic':float(a.mid()), 'radius_diagnostic':float(a.rad())}
    if isinstance(x,acb): return {'real':realball(x.real),'imag':realball(x.imag)}
    return realball(x)
