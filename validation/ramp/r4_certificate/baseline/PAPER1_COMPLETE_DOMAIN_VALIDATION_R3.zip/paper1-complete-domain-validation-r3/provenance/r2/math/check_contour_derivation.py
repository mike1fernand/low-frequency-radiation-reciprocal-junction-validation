#!/usr/bin/env python3
"""Exact algebra plus bounded contour diagnostics; not global integration bounds."""
from pathlib import Path
import argparse
import hashlib
import json
import platform
import sys

import numpy as np
import scipy
from scipy.integrate import quad
import sympy as sp
import mpmath as mp
from flint import arb, fmpq, ctx

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]
ACCEPTED_SOURCE = WORKSPACE/'analysis/remaining_resolution/baseline/paper1-validation-repository/validation/current_numerics/analysis/math_resolution/tetra/combined_tetra_diagnostic.py'
EXPECTED_SOURCE_SHA256 = 'a04f1469250ce240c8802d1e788aec8a5c2f2c76c47438a88b02cb6b0d9c4818'
ENERGY = 36/25
BONDS = np.array(((1,0,0),(0,1,0),(0,0,1),(1,1,0),(1,-1,0),
                  (1,0,1),(1,0,-1),(0,1,1),(0,1,-1)), dtype=float)
UNITS = BONDS / np.linalg.norm(BONDS, axis=1)[:,None]

def need(ok, message):
    if not ok:
        raise RuntimeError(message)

def bulk(k):
    return np.einsum('b,bi,bj->ij', 2*(1-np.cos(BONDS@k)), UNITS, UNITS)

def explicit(k):
    c=np.cos(k); v=np.sin(k)
    d=2+c*c-c*(1+c.sum()-c)
    return 2*(np.diag(d)+np.outer(v,v))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bulk-source',type=Path,default=ACCEPTED_SOURCE)
    parser.add_argument('--shell-proof',type=Path,default=WORKSPACE/'analysis/remaining_resolution/lattice/RADIAL_SHELL_PROOF.md')
    parser.add_argument('--output',type=Path,default=HERE/'CONTOUR_DERIVATION_CHECKS.json')
    args=parser.parse_args()
    source_hash=hashlib.sha256(args.bulk_source.read_bytes()).hexdigest()
    need(source_hash==EXPECTED_SOURCE_SHA256,'Accepted source identity changed')
    x,y,z=sp.symbols('x y z', real=True)
    d=2+x*x-x*(1+y+z)
    upper=2+x*x-sp.Rational(5,2)*x
    # Valid on x,y,z in [3/4,1]. RHS x(y-3/4)+x(z-3/4) is >=0.
    identities={'d_upper_difference':sp.expand(upper-d-x*(y-sp.Rational(3,4))-x*(z-sp.Rational(3,4)))==0,
      'separator_high_margin':sp.Rational(3,2)-sp.Rational(36,25)==sp.Rational(3,50),
      'separator_low_margin':sp.Rational(36,25)-sp.Rational(11,8)==sp.Rational(13,200),
      'quadratic_lower_endpoint':upper.subs(x,sp.Rational(3,4))==sp.Rational(11,16),
      'quadratic_upper_endpoint':upper.subs(x,1)==sp.Rational(1,2),
      'quadratic_convex':sp.diff(upper,x,2)==2,
      'chart_constant_volume_normalization':sp.simplify(3*sp.integrate(x*x,(x,0,sp.pi))/sp.pi**3)==1}
    need(all(identities.values()),'Separator algebra failed')
    ctx.prec=160
    s_arb=arb(fmpq(3,4)).acos(); r_arb=arb(fmpq(1,4)).acos()
    need(s_arb>0 and r_arb>s_arb and 2*r_arb<arb.pi(),'Contour geometry failed')
    rng=np.random.default_rng(20260920)
    directions=[]
    for chart in range(3):
        for uv in [(0,0),(.5,0),(1,0),(1,1),(.5,.5),(1e-8,.5),*rng.uniform(-1,1,(100,2)).tolist()]:
            a=np.insert(np.array(uv),chart,1.)
            directions.append(a)
    s=float(s_arb.mid()); R=float(r_arb.mid())
    lam=np.array([np.linalg.eigvalsh(bulk(s*a)) for a in directions])
    need(lam[:,1].max()<=11/8+1e-12 and lam[:,2].min()>=1.5-1e-12,'Separator diagnostic falsified proof')
    maxerr=0.; minsign=np.inf
    for a in directions:
        for real_t in [.01,s,R]:
            for imag_t in [-.25,-.01,.01,.25]:
                zz=real_t+1j*imag_t
                D=bulk(zz*a)
                maxerr=max(maxerr,float(np.max(np.abs(D-explicit(zz*a)))))
                minsign=min(minsign,float(np.linalg.eigvalsh(np.sign(imag_t)*D.imag)[0]))
        D0=bulk(-.25j*a)
        need(np.linalg.eigvalsh(D0.real-ENERGY*np.eye(3))[-1]<0,'Imaginary endpoint definiteness failed')
    need(maxerr<3e-14 and minsign>0,'Complex strip diagnostic failed')

    # y-axis: a=(0,1,0). Lower doublet has lambda=2(1-cos t),
    # X couples to it; R couples only to lambda_L=6(1-cos t).
    # This tests a genuinely degenerate lower pole without choosing a basis.
    mp.mp.dps=50
    Em=mp.mpf(36)/25; sm=mp.acos(mp.mpf(3)/4); Rm=mp.acos(mp.mpf(1)/4)
    norm=mp.pi**3
    axis=[]
    max_pv_error=mp.mpf(0); max_residue_error=mp.mpf(0)
    def path_integral(fun,left,right,height):
        points=[left,left-1j*height,right-1j*height,right]
        return sum(mp.quad(fun,[a,b]) for a,b in zip(points[:-1],points[1:]))
    for kind,stiff in [('XX',2),('RR',6)]:
        root=mp.acos(1-Em/stiff)
        def numerator(t):
            return (4*t*t*mp.cos(t/2)**2 if kind=='XX' else 2*t*t*mp.sin(t/2)**2)/norm
        def denom(t): return stiff*(1-mp.cos(t))-Em
        def fun(t): return numerator(t)/denom(t)
        dp=stiff*mp.sin(root); ddp=stiff*mp.cos(root)
        residue=numerator(root)/dp
        g0=mp.diff(numerator,root)/dp-numerator(root)*ddp/(2*dp*dp)
        def regular(t):
            if abs(t-root)<mp.mpf('1e-23'): return g0
            return fun(t)-residue/(t-root)
        pv=mp.quad(regular,[0,root,mp.pi])+residue*mp.log((mp.pi-root)/root)
        expected_total_im=mp.pi*residue
        expected_qt=expected_total_im if kind=='XX' else mp.mpf(0)
        rows=[]
        for height in map(mp.mpf,['0.1','0.2','0.3']):
            total=path_integral(fun,mp.mpf(0),Rm,height)+mp.quad(fun,[Rm,mp.pi])
            qt=path_integral(fun,sm,Rm,height).imag
            errpv=abs(total.real-pv); errim=abs(total.imag-expected_total_im); errqt=abs(qt-expected_qt)
            max_pv_error=max(max_pv_error,errpv)
            max_residue_error=max(max_residue_error,errim,errqt)
            need(max(errpv,errim,errqt)<mp.mpf('1e-20'),'Independent axis PV/residue mismatch')
            rows.append({'height':str(height),'total_real':str(total.real),'total_imag':str(total.imag),
                         'qT':str(qt),'PV_error':str(errpv),'total_residue_error':str(errim),'qT_residue_error':str(errqt)})
        axis.append({'source':kind,'root':str(root),'residue':str(residue),'independent_PV':str(pv),
                     'expected_total_imag':str(expected_total_im),'expected_qT':str(expected_qt),'contours':rows})

    # Wrong analytic continuation is an actual falsifiable failure: |A(z)|²
    # instead of analytic A(z)² breaks the exact imaginary residue identity.
    def double_path(fun,left,right,h):
        points=[left,left-1j*h,right-1j*h,right]
        total=0j
        for aa,bb in zip(points[:-1],points[1:]):
            f=lambda u:fun(aa+(bb-aa)*u)*(bb-aa)
            total+=quad(lambda u:f(u).real,0,1,epsabs=1e-11,epsrel=1e-11)[0]+1j*quad(lambda u:f(u).imag,0,1,epsabs=1e-11,epsrel=1e-11)[0]
        return total
    correct=lambda t:t*t*(2*np.cos(t/2))**2/(np.pi**3*(2*(1-np.cos(t))-ENERGY))
    wrong=lambda t:t*t*abs(2*np.cos(t/2))**2/(np.pi**3*(2*(1-np.cos(t))-ENERGY))
    expected=float(mp.pi*(4*mp.acos(mp.mpf(7)/25)**2*mp.cos(mp.acos(mp.mpf(7)/25)/2)**2/norm)/(2*mp.sin(mp.acos(mp.mpf(7)/25))))
    low=double_path(correct,s,R,.2)
    upper=double_path(correct,s,R,-.2)
    conjugated=double_path(wrong,s,R,.2)
    bottom=quad(lambda t:correct(t-.2j).imag,s,R,epsabs=1e-11,epsrel=1e-11)[0]
    controls={'wrong_upper_path_imag_error':abs(upper.imag-expected),
              'conjugated_source_imag_error':abs(conjugated.imag-expected),
              'omitted_vertical_edges_imag_error':abs(bottom-expected),
              'correct_double_precision_error':abs(low.imag-expected)}
    need(controls['correct_double_precision_error']<1e-10,'Double contour positive control failed')
    need(all(controls[k]>1e-5 for k in controls if k!='correct_double_precision_error'),'A negative control was inconclusive')
    result={'status':'passed_declared_exact_algebra_and_contour_diagnostics',
      'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'derivation_sha256':hashlib.sha256((HERE/'CONTOUR_DERIVATION.md').read_bytes()).hexdigest(),
      'accepted_source_sha256':source_hash,
      'preceding_shell_proof_sha256':hashlib.sha256(args.shell_proof.read_bytes()).hexdigest(),
      'runtime':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'sympy':sp.__version__,'mpmath':mp.__version__},
      'exact_separator_checks':identities,'outward_constants':{'s':str(s_arb),'R':str(r_arb)},
      'diagnostics':{'directions':len(directions),'max_separator_lower_eigenvalue':float(lam[:,1].max()),
        'min_separator_highest_eigenvalue':float(lam[:,2].min()),'maximum_complex_bond_formula_error':maxerr,
        'sampled_minimum_signed_imaginary_eigenvalue':minsign},
      'axis_contours':axis,'max_axis_PV_error':str(max_pv_error),'max_axis_residue_error':str(max_residue_error),
      'negative_controls':controls,
      'limits':['Finite diagnostics are not global interval integral bounds.',
        'Global separator and complex-strip exclusions follow from the written analytic proofs, not these samples.',
        'No selected-center displacement or 12-by-12 operator error was bounded here.']}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'max_axis_PV_error':str(max_pv_error),'max_axis_residue_error':str(max_residue_error),'negative_controls':controls},indent=2))

if __name__=='__main__':
    main()
