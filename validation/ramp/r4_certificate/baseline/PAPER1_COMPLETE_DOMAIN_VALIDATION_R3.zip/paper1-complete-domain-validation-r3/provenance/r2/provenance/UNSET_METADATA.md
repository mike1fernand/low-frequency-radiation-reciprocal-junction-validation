# Unset publication and release metadata

The following fields remain deliberately unset rather than guessed:

- preferred publication name;
- corresponding-author email;
- complete author-attested AI tool/model-version inventory;
- final GitHub repository URL, release tag, and commit;
- code, data, and documentation licences;
- Zenodo or equivalent archive DOI and citation;
- final Data and Code Availability wording.
