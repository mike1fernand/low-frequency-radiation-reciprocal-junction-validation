# Paper 1 certified-integration pilot

This is a standalone validation addition to the completed Extension 1 package.
It contains the reviewed continuation plan, new analytic contour proofs, four
whole-cell interval pilots, a higher-order quadrature prototype, and the actual
execution records. Start with `REPORT.md`, then `PLAN.md`.

The addition does not replace the manuscript, selected numerical matrices, or
existing fixed-matrix floor certificate. It does not certify a full-zone
integration error or an unconditional lattice floor.

## Reproduce the bounded checks

The recorded environment is Python 3.12 with the versions in `requirements.txt`.
Use an existing matching environment, or install those dependencies in a fresh
virtual environment. From this directory:

```bash
python verify.py --output-dir ../pilot-replay
```

This first checks the package manifest, then makes a working copy outside this
directory and runs the contour/source/axis/scalar/quadrature checks and fresh
qT and Green enclosures for all four cells. Each stage has a timeout and a
separate execution record. Inspect `../pilot-replay/REPLAY_SUMMARY.json`.
Interrupted execution can use the same command: matching completed stages are
reused only when their recorded outputs still match. A changed package or
environment requires a fresh output directory. On slower hardware, increase
the per-stage limit with `--timeout 120`; this changes no scientific tolerance.

To verify the exact inherited archive as well:

```bash
python verify.py --output-dir ../pilot-replay-with-baseline \
  --baseline-archive /path/to/paper1-validation-repository-pass18-rc4-validation-extension1.zip
```

The original archive's expected SHA-256 is
`0b64dd1c22622fc1ce85880100a863e57f691d287a60a33e0ce211bb3ed274ea`.
Its large simulation is not repeated by this runner. For integrity checking
without live numerical execution, use `--stored-only` with a fresh output
directory. This option does not validate the mathematical results anew.

## Deeper and staged reproduction

- `math/CONTOUR_DERIVATION.md` gives the global separator, pole exclusion,
  retarded sign, source continuation and multiple-root argument.
- `math/LOCAL_SEPARATOR.md` gives the whole-cell proof of improved local
  contour endpoints. Its checker accepts `--output` and `--precision`.
- `pilot/QT_PILOT_REPORT.md` documents the four qT cells, refinement and exact
  binary endpoints. The snapshot beside historical records is their executed
  producer; it is deliberately preserved.
- `green/README.md` gives commands for reproducing all four Green refinements,
  including the regular exterior and the independent diagnostics.
- `high_order/PROOF_AND_FINDINGS.md` states the Cauchy/Gauss error theorem and
  the tested algorithm's limitations. Read the final result index before
  using a row result: a row covers only its declared angular subrectangle.
- `review/` contains the independent AI-assisted mathematical and code reviews.

The quick replay regenerates representative rigorous cell enclosures. It does
not rerun every finest refinement or every exploratory higher-order attempt.
The individual scripts and records specify those calculations separately.

## Relation to the main validation repository

This directory can be retained beside the original repository or placed under
its `validation/` directory without changing its internal relative paths. Its
own manifest and runner validate this addition. It is not silently included in
the original repository's already-issued execution receipt; that receipt
continues to refer to its original archive identity. Integrating this addition
into a later formal repository release requires regenerating that release's
manifest and execution records.

The `provenance/` directory contains specific inherited inputs and their exact
hashes. Historical assessment text there is not a new scientific authority;
the paired Extension 1 result states the current claim boundaries. Public
release remains subject to the recorded author metadata, licence, archive and
publication decisions. No publication action is performed by these scripts.
