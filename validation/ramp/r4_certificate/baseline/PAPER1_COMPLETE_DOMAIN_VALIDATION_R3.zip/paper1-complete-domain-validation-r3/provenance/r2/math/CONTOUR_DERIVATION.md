# Radial contour formulation for the reference Paper 1 kernels

This note proves a route around moving lower-pair projectors and explicit principal-value subtraction. It does not enclose a full Brillouin-zone integral or transfer the existing finite-matrix floor to the exact lattice. Its assumptions are precisely the reference bare bulk: unit mass and lattice spacing, unit axial and face-diagonal springs, and squared frequency E = 36/25. It uses the complete shell census already proved in `analysis/remaining_resolution/lattice/RADIAL_SHELL_PROOF.md`.

## 1. A fixed radial separator for every chart

Use any maximum-coordinate chart k = t a, where a is real and max_i |a_i| = 1. The positive-octant implementation uses a = (1,u,v), (u,1,v), or (u,v,1), with 0 <= u,v <= 1. Let

\[
R=\arccos(1/4),\qquad s=\arccos(3/4).
\]

All three ordered eigenvalues of D(t a) cross E exactly once in (0,R), including multiplicity; the highest branch crosses first. A stronger fact than the previous direction-dependent spectral-gap construction is available: **the same s separates the highest-branch root from both lower-branch roots for every chart direction.**

At t=s, write c_i=cos(s a_i), so 3/4 <= c_i <= 1. At least one c_i=3/4. For that coordinate,

\[
D_{ii}=6-2c_i(1+c_j+c_k)\ge6-6(3/4)=3/2,
\]

and hence lambda_3 >= 3/2. From the exact decomposition

\[
D/2=\operatorname{diag}(d_i)+v v^T,
\quad d_i=2+c_i^2-c_i(1+c_j+c_k),\quad v_i=\sin(s a_i),
\]

rank-one interlacing gives lambda_2 <= 2 max_i d_i. Since c_i is positive,

\[
d_i\le2+c_i^2-\tfrac52c_i.
\]

This convex quadratic takes its maximum on [3/4,1] at an endpoint. Its endpoint values are 11/16 and 1/2. Thus

\[
\lambda_2(D(sa))\le11/8,
\qquad E-\lambda_2\ge13/200,
\qquad\lambda_3-E\ge3/50.
\]

Combined with radial monotonicity, this proves

\[
0<t_L<s<t_{T,2}\le t_{T,1}<R.
\]

The previous exterior argument supplies D(Ra)-EI >= (3/50)I, uniformly. These fixed endpoint margins also prove the real endpoints remain nonsingular on coordinate planes, axes and the body diagonal. The lower-pair degeneracies cause no exception.

## 2. No nonreal poles in the radial strip

The exact central-force symbol has the entire continuation

\[
D(za)=2\sum_b[1-\cos(z\,a\cdot b)]n_b n_b^T,
\qquad n_b=b/|b|,
\]

using the three positive axial and six positive face-diagonal bond representatives. For z=x+iy with 0<x<=R and y != 0,

\[
\operatorname{Im}D(za)
=2\sum_b\sin(x\,a\cdot b)\sinh(y\,a\cdot b)n_b n_b^T.
\]

Because |x a dot b| <= 2R < pi, each nonzero coefficient has the sign of y. The active bond vectors span R^3: every nonzero coordinate a_i activates its axial bond; choosing one such i, a diagonal i+j activates a direction into every zero coordinate a_j. Therefore Im D is positive definite for y>0 and negative definite for y<0. Here Im D is also the Hermitian imaginary part, because the complex symbol is symmetric. If (D-EI)w=0, taking the imaginary part of w* (D-EI)w contradicts definiteness. Thus there are no nonreal zeros of det(D-EI) in this strip, for arbitrarily large |y|.

On the remaining boundary x=0, each 1-cosh(y a dot b) is nonpositive, so D(iya)-EI is negative definite. At z=0 it equals -EI. Together with the endpoint inequalities, every finite rectangular contour used below avoids poles. This does not by itself control interval overestimation on wide angular boxes; an implementation must still produce valid inverse enclosures on all boxes it integrates.

## 3. Analytic continuation of the actual source moments

The centered source columns on real k are F_X=(A,0,0)^T and F_R=(0,-iB,-iC)^T, with

\[
A=2\cos(k_y/2)\cos(k_z/2),\quad
B=\sqrt2\sin(k_y/2)\cos(k_z/2),\quad
C=\sqrt2\cos(k_y/2)\sin(k_z/2).
\]

For complex k, continue each sine and cosine analytically. **Do not take the numerical conjugate transpose of F evaluated at complex k.** Continue the real-axis conjugate row instead: F_X^sharp=(A,0,0), F_R^sharp=(0,+iB,+iC). Thus F^sharp(z)=overline(F(overline(z)))^T is holomorphic; F(z)^dagger generally is not.

Let H(z)=(D(za)-EI)^(-1), and retain the fixed physical source x-axis when selecting any of the three charts. The 17 real-axis moment integrands, including radial Jacobian and positive-octant normalization, continue as

\[
f_{a,d}(z)=\frac{z^2}{\pi^3}\cos(dza_x)A^2H_{xx},\quad d=0,\ldots,5,
\]
\[
f_{c,d}(z)=\frac{z^2}{\pi^3}\cos(dza_x)
(B^2H_{yy}+2BCH_{yz}+C^2H_{zz}),\quad d=0,\ldots,5,
\]
\[
f_{b,d}(z)=\frac{z^2}{\pi^3}\sin(dza_x)A(BH_{xy}+CH_{xz}),\quad d=1,\ldots,5.
\]

The sign of b follows from i sin(d k_x) times the X/R projected entry -iA(BH_xy+CH_xz). It is positive in the displayed convention d=source segment minus target segment. b_0=0. Every f is meromorphic and obeys f(conjugate(z))=conjugate(f(z)). The factor pi^(-3) is 8/(2pi)^3, and z^2 is the chart Jacobian; both are essential. There is no extra 1/(2 omega) multiplier: the resolvent uses the squared-frequency variable E, and the radial residue already divides by d lambda/dt.

## 4. Exact contour identities, signs and degeneracies

For a real interval [a,b] whose endpoints are nonsingular, define the lower path

\[
L_h(a,b):a\longrightarrow a-ih\longrightarrow b-ih\longrightarrow b,
\quad h>0.
\]

The retarded convention here is (D-(omega+i0)^2 I)^(-1), equivalently (D-EI-i0)^(-1) at positive omega. Its poles move above the real t-axis. Therefore the lower path gives the retarded integral:

\[
\int_0^\pi f(t;E+i0)\,dt
=\int_{L_h(0,R)}f(z;E)\,dz+\int_R^\pi f(t;E)\,dt.
\]

One rigorous justification first keeps a positive imaginary energy, deforms into the lower half-plane where the imaginary matrix part is strictly negative, and then takes its zero limit on the compact nonsingular contour. The exterior is real and uniformly nonsingular. The lower path has the sign PV + i pi times the sum of residues; an upper path would give the advanced sign. The contour identity automatically retains the actual Jacobian and asymmetric endpoint terms. Omitting either vertical segment is generally incorrect.

Each chosen finite path, together with the closed angular square of any chart, is compact. Exact nonsingularity throughout this set therefore supplies a finite uniform inverse bound by continuity, even before a useful numerical bound is computed. The source numerator is likewise bounded there. This justifies the dominated zero-regulator limit and angular integration of the deformed expression; a pointwise deformation alone would not have justified an exchange of singular limits. The integration program must still compute useful outward bounds rather than rely on this qualitative compactness argument.

For the lower-two spectral kernel Q, only the poles in (s,R) contribute. Let C_h(s,R) be the counterclockwise rectangle formed by L_h(s,R) and its reflected upper path in reverse. Then

\[
Q_{\mathrm{radial}}=\pi\sum_{t_*\in(s,R)}\operatorname{Res}_{t_*}f
=\frac{1}{2i}\oint_{C_h(s,R)}f(z)\,dz
=\operatorname{Im}\int_{L_h(s,R)}f(z)\,dz.
\]

This is a spectral-weight identity, not the usual normalized residue sum 1/(2pi i) times the contour integral; the spectral pi factor must remain. Integrating these identities over u,v and all three charts yields the exact corresponding 17 moments. Signed cross moments remain signed; positive semidefiniteness concerns the assembled physical Q matrix.

At a multiple lower-pair root t_*, let P project onto the null space of D(t_*a)-EI. The previously proved radial inequality makes P D'(t_*) P positive definite on its range. A block Schur-complement expansion gives

\[
(D(ta)-EI)^{-1}
=\frac{P\,[P D'(t_*)P]_{\mathrm{ran}P}^{-1}P}{t-t_*}+O(1).
\]

Thus the matrix inverse has a simple pole even when its determinant has a double zero. The contour integrates its correct full residue without selecting eigenvectors, dividing by a lower-pair gap, or assigning equal-rank weights. Split and coincident lower poles are handled by the same formula. The implementation must not replace the resolvent by an inverse of averaged lower eigenvalues.

## 5. What this resolves, and what remains necessary

The fixed separator removes the need for angular root tracking and moving qT projector bounds. The lower contour removes explicit singular subtraction and its endpoint-log bookkeeping. The construction works on all four proposed pilot geometries, including generic coordinate-plane degeneracies. These are improvements to the proof route; no change to the physical observable or source is involved.

Still required before an exact-lattice claim: outward enclosure of all three-dimensional contour and exterior integrals; complete nonoverlapping angular coverage; outward summation of all 17 signed moments; all repeated Toeplitz placements in the 12-by-12 matrices; selected-center displacement; and the existing scaled operator error budgets. Pointwise contour identities and finite floating-point agreement do not discharge these obligations. The contour height is a numerical choice whose effect must be tested on certified enclosure cost and width; it does not change the exact integral.

For interval box quadrature, each accepted box must enclose the whole integrand range including complex path derivative, and the integral enclosure is that range multiplied by the real parameter volume. Subdivision gives a rigorous, if potentially slow, baseline. Higher-order validated quadrature needs its own remainder theorem. A failed interval inverse may signal interval overestimation despite exact nonsingularity; subdivide or change the numerical enclosure method before interpreting it as a physical singularity.

## 6. Checks and donor-paper relevance

`check_contour_derivation.py` checks the separator algebra exactly, its constants outward with Arb, and finite bond-sum/complex-definiteness diagnostics. It also compares contour integrals on an exactly solvable symmetry direction against independently subtracted radial PV integrals and exact pole residues, including a doubly degenerate lower root. Different contour heights and deliberate wrong-sign, omitted-edge and conjugated-source controls test the sign and analytic-source obligations. These numerical diagnostics test implementation; the global inequalities above supply the mathematical proofs. Actual run results are recorded separately in `CONTOUR_DERIVATION_CHECKS.json`.

The checker binds the accepted nine-bond producer and preceding shell-proof hashes, but does not rerun that producer's earlier complete audit. Its axis numerical errors are diagnostic discrepancies, not rigorously outward integration-error enclosures.

The supplied-paper transfer assessment was read in `analysis/remaining_resolution/papers/TRANSFER_REASSESSMENT.md`. Paper 2's complete root census and whole-cluster treatment support keeping the full resolvent residue; Operational Duration's outward event certificate distinguishes complete coverage from accurate individual roots; Paper 3A's source/resolvent symmetry requirement supports the checked 17-moment reduction. None supplies the separator or complex-strip proof, which are derived here from Paper 1's actual symbol. No donor numerical result is used as a bound for Paper 1.
