#!/usr/bin/env python3
"""Assemble a complete-domain enclosure, including explicit fallback regions.

Exact geometry and interval summation are separate from mathematical proofs
of the imported per-cell enclosures and analytic fallback majorants.
"""
import argparse,hashlib,json,sys
from fractions import Fraction as F
from pathlib import Path
from coverage import area,full_cover
from matrix.matrix_budget import bound,json_exact,NAMES


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dyadic(endpoint):
    if set(endpoint)!={'mantissa','exponent2'} or type(endpoint['exponent2']) is not int:
        raise ValueError('invalid exact endpoint')
    return F(int(endpoint['mantissa']))*F(2)**endpoint['exponent2']


def interval(obj):
    lo,hi=dyadic(obj['lower']),dyadic(obj['upper'])
    if lo>hi:raise ValueError('reversed endpoints')
    return lo,hi


def add(a,b):return [a[0]+b[0],a[1]+b[1]]


def read_evidence(root,entry):
    path=root/entry['path']
    if sha(path)!=entry['sha256']:raise ValueError('evidence hash mismatch')
    obj=json.loads(path.read_text())
    fmt=entry['format'];kind=entry['kind']
    if kind not in ('g','Q'):raise ValueError('invalid evidence observable')
    if fmt=='r2_qt':
        if kind!='Q' or obj['status'] not in ('rigorous_cell_enclosure','rigorous_merged_cell_enclosure'):
            raise ValueError('not a completed qT cell')
        chart=obj['chart'];bounds=obj['integrated_bounds_rational'];vals=obj['moments']
        values=[[list(interval(v)),[F(0),F(0)]] for v in vals]
    elif fmt=='r2_green':
        if kind!='g' or obj['status']!='certified_partial_cell_enclosure':raise ValueError('not a Green cell')
        chart=obj['chart'];bounds=obj['angular_endpoints'];vals=obj['moments']
        values=[[list(interval(v['real'])),list(interval(v['imag']))] for v in vals]
    elif fmt in ('r3_tile','r3_tile_sharp','r3_tile_preconditioned'):
        # Partition audit alone does not establish completeness. Check both
        # complete status and empty pending queue, and all required legs.
        sys.path.insert(0,str(Path(__file__).resolve().parent/'quadrature'))
        if fmt=='r3_tile':
            from arbitrary_tile import audit_partition,source_hashes,endpoint_certificate
        else:
            from arbitrary_tile_sharp import audit_partition,source_hashes,endpoint_certificate
        expected_sources=source_hashes()
        if fmt=='r3_tile_preconditioned':
            base=Path(__file__).resolve().parent/'quadrature'
            # This producer changes only the interval inverse. Require the
            # same controller and quadrature before reusing their audit.
            for name in ('arbitrary_tile_sharp.py','certified_tensor_sharp.py'):
                if sha(base/name)!=sha(base/'preconditioned'/name):
                    raise ValueError('preconditioned controller/rule diverges from audited adapter')
            expected_sources={name:sha(base/'preconditioned'/name) for name in
                              ('arbitrary_tile_sharp.py','certified_tensor_sharp.py','source_moments.py')}
        from flint import ctx
        if obj['status']!='rigorous_complete_tile_enclosure' or obj['pending']:
            raise ValueError('incomplete tile')
        if obj['identity']['sources']!=expected_sources:raise ValueError('tile producer mismatch')
        mode={'g':'green','Q':'qt'}[kind]
        if obj['settings']['mode']!=mode or obj['leg_count']!={'g':4,'Q':3}[kind]:
            raise ValueError('missing or wrong contour components')
        bits=obj['settings']['bits']
        if type(bits) is not int or bits<64:raise ValueError('invalid tile precision')
        previous_precision=ctx.prec
        try:
            ctx.prec=bits
            _,certificate=endpoint_certificate(obj['settings']['bounds'],obj['settings']['chart'],obj['settings'].get('endpoint_candidates',('1/2','9/16','5/8','11/16')))
            if obj['endpoint_certificate']!=certificate:raise ValueError('tile endpoint certificate differs from recomputation')
        finally:
            ctx.prec=previous_precision
        audit_partition(obj)
        chart=obj['settings']['chart'];bounds=obj['settings']['bounds']
        values=[[[F(0),F(0)],[F(0),F(0)]] for _ in range(17)]
        for leaf in obj['accepted']:
            if len(leaf['moments'])!=17:raise ValueError('missing leaf moment')
            for j,val in enumerate(leaf['moments']):
                if kind=='Q':values[j][0]=add(values[j][0],interval(val['imag']))
                else:
                    values[j][0]=add(values[j][0],interval(val['real']))
                    values[j][1]=add(values[j][1],interval(val['imag']))
        if len(obj['moments'])!=17:raise ValueError('missing complete moment')
        for j,val in enumerate(obj['moments']):
            reported=[interval(val),[F(0),F(0)]] if kind=='Q' else [interval(val['real']),interval(val['imag'])]
            if any(not(lo<=x<=y<=hi) for (lo,hi),(x,y) in zip(reported,values[j])):
                raise ValueError('reported total does not enclose leaf sum')
    else:raise ValueError('unknown evidence format')
    if len(values)!=17:raise ValueError('all17 moments required')
    bounds=list(map(str,map(F,bounds)))
    if entry.get('transform')=='swap_uv_chart0':
        if chart!=0:raise ValueError('u/v symmetry only chart0')
        bounds=bounds[2:]+bounds[:2]
    elif entry.get('transform')=='chart1_to_chart2':
        if chart!=1:raise ValueError('chart symmetry source must be1')
        chart=2
    elif entry.get('transform') is not None:raise ValueError('unknown symmetry')
    if entry['chart']!=chart or list(map(F,entry['bounds']))!=list(map(F,bounds)):
        raise ValueError('evidence geometry mismatch')
    area(bounds)
    return {'chart':chart,'bounds':bounds,'values':values,'evidence':entry}


def assemble(root,manifest_path,targets_path,fallback_path):
    manifest=json.loads(manifest_path.read_text())
    targets=json.loads(targets_path.read_text());fallback=json.loads(fallback_path.read_text())
    if tuple(targets['moment_order'])!=NAMES:raise ValueError('target moment order')
    if [x.replace('_','') for x in fallback['moment_order']]!=list(NAMES):raise ValueError('fallback moment order')
    if fallback['status']!='proved_complete_chart_fallback_bounds':raise ValueError('fallback status')
    records=[read_evidence(root,e) for e in manifest['evidence']]
    out={}
    for kind in ('g','Q'):
        selected=[x for x in records if x['evidence']['kind']==kind]
        cover=full_cover(selected)
        total=[[[F(0),F(0)],[F(0),F(0)]] for _ in range(17)]
        for entry in selected:
            for j,z in enumerate(entry['values']):
                for part in range(2):total[j][part]=add(total[j][part],z[part])
        rem=sum(F(x['fallback_area']) for x in cover.values())
        rates=fallback['per_unit_angular_area']
        for j in range(17):
            keys=['g_real','g_imag'] if kind=='g' else ['qt',None]
            for part,key in enumerate(keys):
                if key is None:continue
                v=rem*dyadic(rates[key][j]['upper'])
                nonnegative=(j in (0,6) and (kind=='Q' or part==1))
                total[j][part]=add(total[j][part],[F(0) if nonnegative else -v,v])
        norms=bound(total,targets['targets'][kind],kind)
        out[kind]={'coverage':cover,'refined_parameter_area':str(3-rem),'fallback_parameter_area':str(rem),
                   'total_parameter_area':'3','enclosed_moments':json_exact(total),'operator_budget':json_exact(norms),
                   'scaled_operator_upper_diagnostic':float(norms['scaled_operator_upper']),
                   'certified_integration_radius_max_diagnostic':max(float((z[0][1]-z[0][0])/2) for z in total)}
    passed=all(out[k]['operator_budget']['arithmetic_budget_pass'] for k in ('g','Q'))
    return {'status':'complete_domain_enclosure_budgets_pass' if passed else 'complete_domain_enclosure_budgets_unresolved',
            'model':'Reference E=36/25, exact nine-bond bare bulk and declared six X/R source sections',
            'moment_order':list(NAMES),'results':out,'exact_Q_psd':'analytic full spectral-residue argument in math/COMPLETE_FALLBACK_PROOF.md',
            'exact_lattice_floor_certified':False,
            'claim_limit':'These are sufficient operator bounds. A failed sufficient bound is not a lower bound on the true cache error. A bridge replay is required before any floor promotion.',
            'input_sha256':{'evidence_manifest':sha(manifest_path),'targets':sha(targets_path),'fallback':sha(fallback_path)}}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--manifest',type=Path,required=True);p.add_argument('--targets',type=Path,required=True);p.add_argument('--fallback',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();r=assemble(a.root,a.manifest,a.targets,a.fallback);a.output.write_text(json.dumps(r,indent=2)+'\n')
    print(json.dumps({'status':r['status'],'observables':{k:{key:v[key] for key in ('refined_parameter_area','fallback_parameter_area','scaled_operator_upper_diagnostic')} for k,v in r['results'].items()}}))
