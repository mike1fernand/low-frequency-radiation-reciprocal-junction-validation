# Final independent referee pass

## Conclusion

The R3 continuation materially improves the validation route. It now has a complete-domain conservative enclosure, actual selected-matrix accounting, a proved sharper quadrature remainder, and positive-area certified results outside the earlier x-chart pilots. The report correctly keeps the exact-lattice floor unproved because the complete operator bounds remain too wide. This is a limitation of the current certification, not evidence that the physical result or selected numerical matrices are invalid.

I reviewed the R3 plan, load-bearing mathematical derivations, matrix accounting and selected-target recovery, quadrature/controller code, complete ledger, complete-domain numerical diagnostic and conditional allocation, and the draft REPORT/README/verify.py. Performed replays and corrections are recorded in the associated review reports and JSON results. No new Hamiltonian, normalization, observable or manuscript defect was confirmed. The main paper does not need a longer safeguard section as a consequence of this work.

## Confirmed corrections and checks

- A malformed selected-target entry could omit its imaginary comparison through `zip`; two-component validation now rejects it, and the exact matrix suite was independently rerun.
- The checkpoint partition auditor trusted the saved contour-leg count; a directly reproduced incomplete Green state passed that old guard. The corrected validator derives the required count from the observable, preserving the exterior requirement.
- The ledger now independently recomputes the tile endpoint certificate at a validated precision, restores the prior Arb precision on every path, and explicitly matches ordinary versus sharpened producers.
- The sharpened-rule test reuse was corrected to test `sharp.rule` directly. The corrected44-check suite was independently rerun.

These were validation or test-coverage defects. Their existence did not establish incorrect physical outputs. The reviewed mathematical improvements retain the original integrand, source phases, model and observable.

## Open skeptical pass

The most consequential interpretive risk is to confuse a mathematical upper bound with an estimated physical error. The report avoids that: broad fallback enclosures establish finite complete coverage but do not put broad error bars on the conversion coefficient. Likewise the small complete-domain numerical mesh differences are diagnostics, not rigorous bounds. Exact arithmetic around a numerical candidate center proves only a conditional allocation, and the final actual-cache comparison remains necessary.

A second risk is to mistake a cost improvement in an error formula for a computational feasibility theorem. The report separates the improved remainder constant, measured leaf-count reductions on identical regions, local integration-loop times, and full-process checkpoint overhead. It does not extrapolate an easy axis cell into a global runtime guarantee. Partial work remains excluded from complete-cell evidence and is preserved for a future explicit continuation.

A third risk is indirect circular validation from the attached papers. The report clearly identifies its use of retained donor assessments rather than claiming a fresh reading or replay of the primary manuscripts. Donor lessons guide completeness, tied modes, source symmetry and readout preservation; they do not supply the new Paper 1 integration values or error bounds.

## Paper versus future work

The present paper's narrower finite-input floor and numerical physical claim can retain their existing concise scope statements. The new technical material belongs in the validation addition. A stronger paper statement requires tight complete-domain g and Q enclosures, both actual-cache norm budgets, exact Q positivity and a fresh bridge replay. The positivity premise is now discharged analytically; the tight integration budgets remain open. No exact finite-window identity, new whole-band theorem or broader physical claim is needed to complete the current paper.

The justified next certification work is a measured nonuniform allocation and treatment of costly regions/checkpoint overhead, with changed methods tested first on the same complete physical regions. Failure of the current sufficient bounds must not be rewritten as a lower bound on the true error or a proof that certification is impossible.

## Replay runner review

The draft runner uses independent subprocess caps, preserves sealed evidence and records each executed stage. Two minimum changes were requested before final export: final post-run comparison failures must save `status=failed` rather than leave the receipt `in_progress`; and the fresh complete-domain floating diagnostic should be explicitly compared with the sealed baseline under a stated diagnostic tolerance. These requests concern reliable replay reporting. Final exported replay records, rather than this draft-runner review, determine whether those checks were completed successfully.

This was a focused material and open referee review. It did not rerun the old N160 production, the full costly certified campaign, the finite-response bridge, primary donor-paper calculations, or any second-platform/independent-person replication. No calibrated95% probability is inferred from deterministic checks.
