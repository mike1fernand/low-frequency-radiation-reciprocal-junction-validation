# Sharpened quadrature and conditional allocation review

I independently read `certified_tensor_sharp.py` and `SHARP_CAUCHY_PROOF.md`. The sharper error factor retains eleven even Gauss-moment residuals at powers `2n,...,2n+20` and adds `2 r^(2n+22)/(1-r^2)` for every omitted even power. Odd residuals vanish by exact paired-node symmetry, not by small floating-point residuals. Cauchy's bound controls the complex Taylor coefficients. The tensor telescoping, complete real parameter intervals, physical box-volume factor and finite complex-neighborhood inverse checks remain the same as the reviewed original method. Cached residuals include the precision in their key.

No mathematical error was identified in this refinement. I reran the checker and obtained44 passing checks, including a power in the omitted tail and a complex rational integral with an analytic target. The final replay is `SHARP_REPLAY.json`. During review the reused exact-rule tests were corrected to bind `sharp.rule` as well as `sharp.gauss_box`; the original and sharpened formulas were identical, but explicitly testing the implementation under review avoids a future silent mismatch. I reran the corrected suite and all44 checks passed. The improved Cauchy factor is not, by itself, a measured runtime speedup; physical stage timings decide that.

I also inspected the complete-domain ordinary contour diagnostic and its allocation assessment. The implementation retains the physical source axis, all17 moments, the spectral sign, t-squared Jacobian, all Green contour pieces and real exterior. The optional y/z reuse is supported by the reviewed exact symmetry. The first full run evaluates all three chart orientations directly; subsequent reuse is not presented as independent numerical evidence for that symmetry.

The saved float64 candidate centers are treated as exact dyadic numbers only for the center-to-cache comparison. I independently recalculated the exact rational equalities

`(169/100) * (center_operator_upper + 11 * radius) = threshold`

and `radius = 3 * density` for both operators. `ALLOCATION_RECHECK.json` records this check. The resulting sufficient per-chart-area planning densities are approximately `3.25319e-4` for g and `7.48135e-5` for Q. They assume that the actual full integral is enclosed within the proposed modulus radius about those particular centers. That containment was not established by the floating diagnostic or this review.

The reported mesh and contour-height agreements are appropriate diagnostics, not rigorous error bounds. The exact allocation arithmetic proves an implication with an unproved premise. A future independently centered rigorous integral enclosure must still include its displacement from the saved candidate centers or compare directly to the actual selected matrices, as the complete ledger does. No whole-box floor proof, full numerical campaign or primary donor-paper calculation was rerun in this review.
