#!/usr/bin/env python3
"""Test replay post-failure reporting with manufactured subprocess outputs.

These are runner controls only; no mocked calculation is physical evidence.
"""
import argparse,contextlib,importlib.util,io,json,tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


def run(root):
    spec=importlib.util.spec_from_file_location('runner_under_test',root/'verify.py')
    runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
    checks=[]
    for case in ('matching','changed_ledger','changed_diagnostic','changed_fallback'):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td)/'package';out=Path(td)/'out';base.mkdir()
            for sub in ('math','matrix/numerical'):(base/sub).mkdir(parents=True)
            ledger={'status':'fixture'};fallback={'per_unit_angular_area':{'fixture':'1'}}
            diag={'status':'complete_domain_numerical_diagnostic_not_certified','comparison':{k:{'moments':[[0.0,0.0] for _ in range(17)]} for k in ('g','Q')}}
            (base/'MANIFEST.json').write_text(json.dumps({'files':{}}))
            (base/'COMPLETE_DOMAIN_LEDGER.json').write_text(json.dumps(ledger))
            (base/'math/COMPLETE_FALLBACK_CHECKS.json').write_text(json.dumps(fallback))
            (base/'matrix/numerical/gl12_48.json').write_text(json.dumps(diag))
            def fake_subprocess(argv,**kwargs):
                target=Path(argv[argv.index('--output')+1]);value={'status':'fixture'}
                if target.name=='ledger.json':value={'status':'changed'} if case=='changed_ledger' else ledger
                if target.name=='fallback.json':value={'per_unit_angular_area':{}} if case=='changed_fallback' else fallback
                if target.name=='diagnostic.json':
                    value=json.loads(json.dumps(diag))
                    if case=='changed_diagnostic':value['comparison']['Q']['moments'][0][0]=1e-6
                target.write_text(json.dumps(value))
                return SimpleNamespace(returncode=0,stdout='manufactured runner-control output',stderr='')
            with patch.object(runner,'__file__',str(base/'verify.py')),patch.object(runner.sys,'argv',['verify.py','--output',str(out)]),patch.object(runner.subprocess,'run',fake_subprocess),contextlib.redirect_stdout(io.StringIO()):
                code=runner.main()
            result=json.loads((out/'REPLAY.json').read_text())
            if case=='matching':assert code==0 and result['status']=='passed'
            else:assert code==2 and result['status']=='failed' and result['post_validation_error']
            checks.append(case)
    return {'status':'passed','checks':checks,'scope':'Manufactured runner-output controls only; no physical computations occurred in this checker.'}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();r=run(a.root.absolute());a.output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
