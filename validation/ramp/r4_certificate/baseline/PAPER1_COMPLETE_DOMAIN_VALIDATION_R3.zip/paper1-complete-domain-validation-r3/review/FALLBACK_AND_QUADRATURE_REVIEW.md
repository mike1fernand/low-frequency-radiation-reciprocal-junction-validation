# Independent mathematical review of complete fallback and tensor quadrature

## Complete fallback

I read `math/complete_fallback.py`, the inherited radial-shell proof and contour derivation, then re-executed the fallback checker. The replay is `FALLBACK_REPLAY.json`. This review tests the conservative complete-chart bounds, not the exact-lattice error budgets.

The following load-bearing deductions check:

1. For the nine unit-projector bonds, `sum (a.b)^2 n n^T = |a|^2 I + 2 a a^T` and `sum n n^T = 3 I`. The supplied symbolic checker verifies both. Since a maximum-coordinate chart has `1 <= |a|^2 <= 3`, the first matrix is bounded below by I and above by 9I.
2. With `c = sin(2R)/(2R)>0`, `-Im D((x-iy)a) >= 2xy c I` for `0<x<=R`, `y>0`: `sin(xq)/(xq)>=c` and `sinh(yq)/(yq)>=1` for every bond phase q. Thus the inverse norm is at most `1/(2xy c)` on the portions using that estimate.
3. At the real endpoints s and R, the smallest absolute eigenvalue of `D-EI` is at least `m=3/50`. For `0<=y<=epsilon=1/512`, the perturbation bound is `||D((x-iy)a)-D(xa)|| <= 6(exp(2epsilon)-1)<m/2`. The near-endpoint inverse bound `2/m` follows; the far-vertical integral uses the preceding imaginary coercivity. The code retains both vertical segments.
4. At x=0, `D(-iya)-EI <= -EI`, giving inverse norm at most 1/E. Along the bottom contour for `0<=x<=delta=1/4`, all real bond phases have absolute value at most 1/2<pi/2, hence `Re D((x-ih)a) <= D(xa) <= 9x^2 I`. The inverse norm is at most `1/(E-9delta^2)`. This removes the artificial `1/x` singularity that would result from applying imaginary coercivity at the origin.
5. Multiplication by `|z^2|=x^2+y^2` and direct elementary integration gives the four Green-contour integrals appearing in the code. Complex source norms for each of the three scalar source forms are bounded by `4 cosh(h/2)^4`; the intersegment sine/cosine contributes at most `cosh(dh)`. The code includes the positive-octant factor `pi^-3`.
6. The real exterior has inverse norm at most 1/m. The bounds on the three source forms are 4, 2 and `2 sqrt(2)`, respectively, and integrating t^2 gives `(pi^3-R^3)/3`. This is included in the Green real bound.
7. On the shells `t<=R`, the inherited inequality `tD'(t)>=beta D(t)` gives a full residue norm at most `t/(beta E)`; this includes the inverse of the restricted derivative at a tied pole. The radial t^2 Jacobian and spectral pi give at most `C R^3/(pi^2 beta E)` per root multiplicity. Three multiplicities bound the total imaginary Green part and two bound qT. On these shells, the rotational source norm squared is at most `15/16`, because `sin^2(ki/2)<=3/8` and `2(r+s-2rs)` increases in each variable on `[0,3/8]^2`. The cross-source norm is at most `sqrt(15)/2`.
8. Exact qT positivity follows from the source-projected spectral representation. The full residue at a root is `P(PD'P)^{-1}P >= 0`; projection through the complete source Fourier map and integration with nonnegative Jacobian/spectral factors preserve positivity. The 17-moment reduction is an equality to that full source integral; the separately signed moments need not be positive. The nonnegative a0,c0 scalar limits used by the fallback are consequently valid.

The fallback replay completed four symbolic checks, 216 finite imaginary-coercivity comparisons, and 204 finite source-symmetry comparisons. The finite samples are falsification checks; the inequalities above establish whole-domain scope. Per-chart maximum magnitude rates are approximately 27.5855624 for Re g, 2.84080846 for Im g and 1.89387231 for Q. These are broad upper bounds, not errors in the selected numerical results.

## Tensor quadrature

I read `quadrature/certified_tensor.py` and `validate_tensor.py`, verified the normalized GL3/GL5 radical nodes and weights, and re-executed the checker. `TENSOR_REPLAY.json` records 30 passing checks, including exact symbolic moments through degrees5/9, a nonzero degree10 error, nonseparable analytic examples, a tight rational example, and rejection of a pole inside the proposed analytic neighborhood.

The remainder theorem is appropriate for the implemented orders: normalized Gauss integration is exact through degree `2n-1`; Taylor/Cauchy coefficient bounds and the norm-one positive quadrature functional give `2 M (h/rho)^(2n)/(1-h/rho)`. Tensor telescoping adds one remainder per coordinate. In each coordinate's complex neighborhood the others range over their complete real intervals, which is sufficient for that telescoping argument. The actual interval matrix inverse must be finite on the containing square, so real-angle pole exclusion is not being substituted for a complex-angle analyticity check. Multiplication by the complete physical box volume appears after the normalized bounds.

No material mathematical defect was identified in these reviewed primitives. This does not certify any full adaptive campaign, ledger, source binding or final matrix budget; those require review of their concrete implementation and results.
