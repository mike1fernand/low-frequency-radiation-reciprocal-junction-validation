# Independent review of the R3 continuation plan

## Result

The plan correctly advances beyond the completed R2 pilots: it targets the actual selected matrices, a complete three-chart cover, and measurable feasibility at the existing operator budgets. No defect was found in its decision to preserve the manuscript and existing numerical claims. A complete exact-lattice guarantee is a stronger optional result, not a correction already required by the current paper.

Two minimum plan clarifications should be made before interpreting numerical success:

1. **Retain the exact spectral positivity premise.** The final bridge requires exact `Q >= 0` in addition to `||1.69 Delta g||_2 <= 0.020` and `||1.69 Delta Q||_2 <= 0.005`. State how the declared lower-pair spectral measure proves positivity for the full source-projected matrix. A positive midpoint matrix, interval enclosure of its entries, or the positivity of the old cached matrix cannot substitute for this premise. The natural proof is the integral of source-projected orthogonal spectral projectors with a nonnegative spectral measure, with the same source, branch definition and normalization as the contour formula. This is not a demand to establish a new numerical eigenvalue floor.
2. **Make the cost decision testable.** Fix per-stage work/time caps and the immediate campaign allocation before launching probes; record achieved enclosure widths and work counts. Following a slow/failed stage, change a specific diagnosed feature or stop that route. Compare subsequent settings using the accuracy requirement actually needed by matrix budgets, not merely finite enclosures. Timing extrapolations remain empirical and may be revised after later tiles. This gives operational content to the plan's existing bounded-campaign stopping rule.

The following are already present and need no further safeguards: include cache-center displacement; include all 17 moments at every matrix occurrence; preserve the physical source when switching charts; cover the Green exterior; reject missing/overlapping domain evidence; bind checkpoints to settings; distinguish numerical diagnostics from rigorous enclosures; replay exported work; avoid rerunning N160.

## What the supplied papers can contribute

For this review I read the retained `DONOR_TRANSFER_REASSESSMENT.md` and `SOURCE_MOMENT_ASSESSMENT.md`, not the original donor manuscripts. Their reported source-specific lessons remain relevant:

- Operational Duration motivates completeness of the enclosed root/event set, separately from accuracy of individual roots.
- Paper 2 motivates full root accounting and use of whole degenerate eigenspaces. It does not give Paper 1's reciprocal-space integration bounds.
- Paper 3A requires source, resolvent and boundaries to share the proposed symmetry. Paper 1's separated X/R cross moments therefore remain present; their pointwise odd factor does not make the full phased integral vanish.
- The other donor assessments emphasize actual source/action and readout conventions. They do not supply a missing term in this model or identify a new correction to the selected numerical kernels.

The source-moment assessment is historically superseded in its cache discussion: it explicitly records a later basis-dependent nodal defect. The controlling Extension 1 selection, not that earlier snapshot's matrices, must determine this continuation's target. The R3 plan correctly requires this identity check.

No new donor-supported change to the Hamiltonian, physical normalization, stationary observable, packet preparation, or finite-time reporting window was identified. This is an assessment of the retained donor reviews, not a new claim of having re-read or re-executed the donor papers.

## Referee triage and manuscript consequence

| Question | Needed for the current paper? | Needed for the stronger exact-lattice floor? |
|---|---|---|
| Accurate binding of the existing finite-input certificate to its selected matrices | Yes | Yes |
| Complete rigorous Green/qT integration with both operator budgets | No: current wording explicitly excludes it | Yes |
| Exact qT positivity and contour/spectral agreement | Needed if using the new bridge | Yes |
| Exact finite-window/stationary identity | No: observables are already distinguished | No |
| A new whole-band theorem or optimized device | No | No for the reference-frequency guarantee |
| Independent-person or second-platform replication | Not represented as completed | Separate reproducibility work |
| Release metadata/licensing decisions | Required for the intended public release, not for mathematical validity | Separate release work |

This development belongs in a validation addition. If the complete bridge eventually succeeds, the manuscript could replace the existing limited floor statement with the stronger result and a short pointer to the proof. If it does not, new enclosure details, timing logs, and repeated caveats would add length without strengthening the physical result; keep them out of the main narrative.

## Open skeptical pass on the plan

The most plausible hidden failure is a ledger that proves all cells were named while its mathematical majorant does not enclose the integrand on the complete cell or contour component. Coverage and enclosure validity are distinct. In particular, real-angle pole exclusion alone does not prove a nonzero lower singular-value bound on a chosen complex angular neighborhood. Any fallback or high-order remainder must prove the actual finite bound used over its own stated domain. The plan already requires this, so this is an implementation review target rather than another plan amendment.

A second risk is overinterpreting failed sufficient error allocations. A conservative row-sum allocation can fail even when the true matrix error would fit the bridge. Failure of that allocation establishes only that the tested certification route has not closed the budget. It must not become evidence against the physical conversion result or proof that the theorem is unattainable.

Reviewed sources: R3 `PLAN.md`; R2 `PLAN.md` and `REPORT.md`; Extension 1 `CLAIM_SCOPE.md` and `LIMITATIONS.md`; the two retained donor/source assessments above. No numerical runs, manuscript edits, source modifications or primary-donor replays were performed in this plan review.
