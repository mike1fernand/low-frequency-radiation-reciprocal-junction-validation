#!/usr/bin/env python3
"""Wide-ball inverse checks; finite interval inversion supplies the proof."""
import argparse,hashlib,json,sys
from pathlib import Path

def run(producer):
    sys.path.insert(0,str(producer.absolute()))
    from source_moments import shifted_matrix,preconditioned_inverse,certified_inverse,finite_matrix
    from flint import arb,acb,ctx
    ctx.prec=128;checks=[]
    for chart in range(3):
        t=acb(arb('0.9'),-arb(1)/4)
        u=acb(arb('0.2','0.005'),arb(0,'0.005'));v=arb('0.7','0.005')
        M=shifted_matrix(t,u,v,chart);pre=preconditioned_inverse(M);chosen=certified_inverse(M)
        assert finite_matrix(pre) and finite_matrix(chosen)
        product=M*pre
        assert all(product[i,j].contains(1 if i==j else 0) for i in range(3) for j in range(3))
        for du in ('-0.005','0.005'):
            for iu in ('-0.005','0.005'):
                for dv in ('-0.005','0.005'):
                    P=shifted_matrix(t,acb(arb('0.2')+arb(du),arb(iu)),arb('0.7')+arb(dv),chart).inv()
                    assert all(pre[i,j].contains(P[i,j]) for i in range(3) for j in range(3))
        checks.append({'chart':chart,'wide_ball_finite_inverse_and_identity':True,'sampled_corner_inverses_contained':8})
    return {'status':'passed','precision_bits':128,'checks':checks,
        'scope':'Whole-box finiteness plus24 pointwise corner falsification checks; corner checks are not the enclosure proof.',
        'source_sha256':hashlib.sha256((producer/'source_moments.py').read_bytes()).hexdigest(),
        'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--producer',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();r=run(a.producer);a.output.write_text(json.dumps(r,indent=2)+'\n');print(r['status'])
