#!/usr/bin/env python3
"""Independent ledger checks; manufactured states test IO/coverage, not physics."""
import argparse,copy,hashlib,json,sys,tempfile
from fractions import Fraction as F
from pathlib import Path


def run(root):
    sys.path.insert(0,str(root));sys.path.insert(0,str(root/'quadrature'))
    import complete_ledger as ledger
    import arbitrary_tile as tile
    from flint import ctx,acb
    from source_moments import ball_serialization
    checks=[]
    def check(name,condition):
        if not condition:raise AssertionError(name)
        checks.append(name)
    def rejects(name,callback):
        try:callback()
        except (ValueError,KeyError,TypeError,IndexError):checks.append(name)
        else:raise AssertionError(name+' unexpectedly accepted')
    manifest=root/'EVIDENCE_MANIFEST.json';targets=root/'matrix/TARGETS.json';fallback=root/'math/COMPLETE_FALLBACK_CHECKS.json'
    baseline=ledger.assemble(root,manifest,targets,fallback)
    check('both_observables_cover_exactly_three_chart_areas',all(F(v['refined_parameter_area'])+F(v['fallback_parameter_area'])==3 for v in baseline['results'].values()))
    check('conservative_current_budget_not_promoted',not baseline['exact_lattice_floor_certified'] and baseline['status']=='complete_domain_enclosure_budgets_unresolved')
    m=json.loads(manifest.read_text())
    with tempfile.TemporaryDirectory() as td:
        tmp=Path(td)
        empty=tmp/'empty.json';empty.write_text(json.dumps({'evidence':[]}))
        allfallback=ledger.assemble(root,empty,targets,fallback)
        check('missing_all_refinements_retains_all_fallback',all(v['fallback_parameter_area']=='3' and v['refined_parameter_area']=='0' for v in allfallback['results'].values()))
        duplicate=copy.deepcopy(m);duplicate['evidence'].append(copy.deepcopy(m['evidence'][0]));p=tmp/'duplicate.json';p.write_text(json.dumps(duplicate))
        rejects('reject_duplicate_refined_area',lambda:ledger.assemble(root,p,targets,fallback))
        baseentry=copy.deepcopy(m['evidence'][0]);baseobj=json.loads((root/baseentry['path']).read_text())
        def fixture(obj,entry):
            file=tmp/'evidence.json';file.write_text(json.dumps(obj));entry=copy.deepcopy(entry);entry['path']='evidence.json';entry['sha256']=hashlib.sha256(file.read_bytes()).hexdigest();return entry
        en=fixture(baseobj,baseentry);en['sha256']='0'*64
        rejects('reject_mismatched_evidence_hash',lambda:ledger.read_evidence(tmp,en))
        altered=copy.deepcopy(baseobj);altered['moments']=altered['moments'][:-1]
        en=fixture(altered,baseentry)
        rejects('reject_missing_inherited_moment',lambda:ledger.read_evidence(tmp,en))
        en=fixture(baseobj,baseentry);en['chart']=2
        rejects('reject_evidence_chart_mismatch',lambda:ledger.read_evidence(tmp,en))
        en=fixture(baseobj,baseentry);en['transform']='chart1_to_chart2'
        rejects('reject_unproved_source_axis_permutation',lambda:ledger.read_evidence(tmp,en))
        # A source-bound manufactured all-zero tile tests structural acceptance
        # only; it is never included in the physical ledger or output enclosures.
        settings={'bounds':['0','1/32','0','1/32'],'chart':0,'mode':'green','height':'1/4','orders':[5,5,5],'density_tolerance':'1/25000','bits':128}
        prev=ctx.prec
        try:
            ctx.prec=128;_,cert=tile.endpoint_certificate(settings['bounds'],0)
            z=ball_serialization(acb(0))
        finally:ctx.prec=prev
        roots=[{'id':str(j)+':','leg':j,'bounds':[['0','1'],['0','1/32'],['0','1/32']],'depth':0} for j in range(4)]
        state={'status':'rigorous_complete_tile_enclosure','settings':settings,'identity':{'sources':tile.source_hashes()},'endpoint_certificate':cert,'leg_count':4,'pending':[],'splits':[],'accepted':[{'node':n,'moments':[copy.deepcopy(z) for _ in range(17)]} for n in roots],'moments':[copy.deepcopy(z) for _ in range(17)]}
        entry={'format':'r3_tile','kind':'g','chart':0,'bounds':settings['bounds']}
        en=fixture(state,entry);ctx.prec=96
        accepted=ledger.read_evidence(tmp,en)
        check('manufactured_complete_leaf_sum_and_geometry_accepted',len(accepted['values'])==17 and accepted['bounds']==settings['bounds'])
        check('endpoint_recheck_restores_global_precision',ctx.prec==96)
        import arbitrary_tile_sharp as sharp
        sharpstate=copy.deepcopy(state);sharpstate['identity']['sources']=sharp.source_hashes()
        sharpentry=copy.deepcopy(entry);sharpentry['format']='r3_tile_sharp'
        en=fixture(sharpstate,sharpentry)
        check('sharp_producer_explicitly_matched',len(ledger.read_evidence(tmp,en)['values'])==17)
        en=fixture(sharpstate,entry)
        rejects('reject_sharp_payload_with_old_producer_format',lambda:ledger.read_evidence(tmp,en))
        prestate=copy.deepcopy(state)
        prestate['identity']['sources']={name:hashlib.sha256((root/'quadrature/preconditioned'/name).read_bytes()).hexdigest() for name in ('arbitrary_tile_sharp.py','certified_tensor_sharp.py','source_moments.py')}
        preentry=copy.deepcopy(entry);preentry['format']='r3_tile_preconditioned'
        en=fixture(prestate,preentry)
        check('preconditioned_producer_explicitly_matched',len(ledger.read_evidence(tmp,en)['values'])==17)
        en=fixture(prestate,sharpentry)
        rejects('reject_preconditioned_payload_as_unpreconditioned',lambda:ledger.read_evidence(tmp,en))
        alterations=[
            ('reject_partial_tile',lambda s:s.__setitem__('status','partial_checkpoint_no_tile_enclosure')),
            ('reject_pending_leaf',lambda s:s['pending'].append(copy.deepcopy(roots[0]))),
            ('reject_missing_exterior_even_with_reduced_count',lambda s:(s.__setitem__('leg_count',3),s['accepted'].pop())),
            ('reject_missing_leaf',lambda s:s['accepted'].pop()),
            ('reject_missing_leaf_moment',lambda s:s['accepted'][0]['moments'].pop()),
            ('reject_changed_endpoint_certificate',lambda s:s['endpoint_certificate'].__setitem__('kind','wrong')),
            ('reject_changed_source_identity',lambda s:s['identity']['sources'].__setitem__('source_moments.py','wrong')),
            ('reject_invalid_precision',lambda s:s['settings'].__setitem__('bits',32)),
        ]
        for name,mut in alterations:
            obj=copy.deepcopy(state);mut(obj);en=fixture(obj,entry)
            rejects(name,lambda:ledger.read_evidence(tmp,en))
            check(name+'_preserves_global_precision',ctx.prec==96)
        obj=copy.deepcopy(state)
        obj['accepted'][0]['moments'][0]['real']['lower']={'mantissa':'-1','exponent2':0}
        obj['accepted'][0]['moments'][0]['real']['upper']={'mantissa':'1','exponent2':0}
        en=fixture(obj,entry)
        rejects('reject_reported_total_narrower_than_exact_leaf_sum',lambda:ledger.read_evidence(tmp,en))
        ctx.prec=prev
    return {'status':'passed','checks':checks,'count':len(checks),'scope':'Complete coverage and arithmetic/adversarial IO checks. Manufactured zero tiles were not physical integrations or included in the actual ledger.','sources':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'complete_ledger.py',root/'coverage.py',Path(__file__))},'input_sha256':baseline['input_sha256']}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();r=run(a.root.absolute());a.output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'count':r['count']}))
