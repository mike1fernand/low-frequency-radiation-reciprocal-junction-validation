# Independent preconditioned inverse review

The new inverse uses an exact dyadic matrix P0 chosen from a computed midpoint inverse. It never treats the midpoint calculation as the exact inverse of M. If the interval inverse of P0 M is finite, then P0 M is nonsingular for every represented matrix, hence both square factors are nonsingular, and

`M^-1 = (P0 M)^-1 P0`.

The product order is correct. Interval multiplication with the fixed exact P0 encloses every transformed matrix; a successful interval inverse therefore provides a bound over the complete box. Its subsequent multiplication by P0 retains that enclosure. The direct and preconditioned candidates are each independently valid. Choosing either according to a diagnostic maximum-entry magnitude cannot invalidate the bound. The width threshold only decides whether to try an additional valid method.

This changes the bounding procedure, not the analytic physical integrand. The algorithm need not choose P0 holomorphically as a function of the box. For each fixed complex neighborhood it supplies a finite uniform enclosure of the same holomorphic inverse. Thus the previously reviewed Cauchy remainder argument continues to apply. It does not infer analyticity from sampled point inverses.

I inspected the new source and its tests, then independently replayed29 checks: exact dyadic P0, pointwise consistency and identity in all three charts, a noncommuting wrong-product-order negative control, and singular-matrix rejection. I additionally ran `check_preconditioned_wide.py`: three genuinely wide complex angular boxes returned finite inverse enclosures, their interval products contained the identity, and24 independently evaluated corner inverses were contained. These finite corner checks are falsification diagnostics; complete-box validity follows from interval inversion and the algebra above.

No material error was found. The source is separately frozen, and old leaves must not be relabeled as products of this new bound. New completed physical tiles can enter the ledger after the usual exact partition, endpoint, source and aggregate checks. The reported ordinary-cell completion is a material improvement in feasibility; any earlier conclusion based on its unresolved predecessor needs updating to the final preconditioned evidence. This review does not itself certify a complete-domain floor or predict a global runtime.
