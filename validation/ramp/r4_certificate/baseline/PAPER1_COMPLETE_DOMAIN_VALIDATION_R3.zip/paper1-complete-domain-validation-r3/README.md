# Paper 1: complete-domain validation addition R3

This addition advances the optional exact-lattice guarantee beyond the R2 pilots. It provides a complete-domain enclosure ledger, exact selected-matrix error accounting, tighter certified quadrature, complete numerical diagnostics, and resumable physical integrations. **The exact-lattice floor remains unproved.** The manuscript and selected fixed-input certificate are unchanged.

Read `REPORT.md` for results and the remaining decision, and `PLAN.md` for correction gates. This is a standalone addition alongside the existing Extension 1 validation repository. It has its own manifest; the original repository's receipt does not automatically cover it. No GitHub upload, publication or licensing decision is performed here.

## Reproduce

Python 3.12 was used. Create an isolated environment, install `requirements.txt`, then run:

```bash
python verify.py --output /absolute/path/to/new-replay --physical-replay
```

The verifier checks every sealed payload, the exact matrix accounting, whole-domain fallback, quadrature rules and remainder, checkpoint and coverage controls, the complete ledger, and a complete-domain floating diagnostic. `--physical-replay` additionally freshly recomputes both completed chart-1 axis integrals and the preconditioned ordinary and body-diagonal qT cells. Each subprocess has a 55-second hard limit. Records are written after each stage. Original evidence is read-only during replay. A new empty output directory is required; the replay output is not automatically part of the sealed package.

The slower ordinary Green checkpoint and the completed plane result are audited as saved evidence, rather than rerun by the default bounded replay. Their exact producers and commands are retained. The costly N160 campaign is inherited and is not repeated here. No same-host result is represented as independent-person or second-platform replication.

## Resume an integration

The validated preconditioned producer is preferred for new runs. The checkpoint records its exact source hashes, runtime, precision, physical tile, contour and quadrature settings. Reissue its recorded `settings` with the corresponding producer and existing `--output` path to continue in the matching environment. For example, a new ordinary qT run is:

```bash
python quadrature/preconditioned/arbitrary_tile_sharp.py --bounds 3/8,7/16,5/8,11/16 --chart 1 --mode qt --height 1/4 --orders 5,5,5 --density-tolerance 1/25000 --max-seconds 25 --output /absolute/path/to/ordinary-qt.json
```

Repeat that command only while its saved pending domain remains and a further stage is justified. A different runtime or producer must start a new output; changing an identity field by hand does not validate inherited work. The included controller migration is limited to its documented, independently checked repair of bookkeeping; it preserves the old producers and does not authorize general migration of mathematical changes.

`--max-seconds` limits the integration loop, not checkpoint loading, auditing and writing. Use `quadrature/run_stage.py` for a separately bounded full-process invocation and wall-time receipt. A hard external timeout can lose the currently unsaved stage but leaves the preceding atomic checkpoint. A saved partial checkpoint has no complete-tile moments and never enters `EVIDENCE_MANIFEST.json` as a finished enclosure.

## Meaning of the records

- `matrix/TARGETS.json` contains the exact dyadic selected g and Q targets, including the actual rounded sum used for Q. `matrix/matrix_budget.py` compares every matrix occurrence, including cache symmetry residuals.
- `matrix/numerical/` contains ordinary complete-domain quadrature and exact conditional error allocations around its candidate centers. Mesh/height agreement is diagnostic; those candidate centers are not exact integrals.
- `math/` proves finite analytic fallback bounds, exact physical Q positivity and allowed y/z source symmetry. The bounds apply to every unrefined region.
- `quadrature/` contains rigorously bounded Gauss integration, complete/partial physical checkpoints, earlier producer snapshots, and measured stage receipts.
- `EVIDENCE_MANIFEST.json` selects only complete cells. `COMPLETE_DOMAIN_LEDGER.json` combines them with explicit fallback rectangles in all three charts. The broad fallback widths do not describe actual physical error.
- `review/` records independent reviews and checks, including confirmed guard defects and their correction. Manufactured zero callbacks test controller logic only and are never physical evidence.
- `provenance/r2/` preserves the verified R2 package. `provenance/selected_repository/` is a four-file, hash-checked subset sufficient to recover the actual selected targets, not a replacement for the full repository.

The complete-domain ledger is a rigorous enclosure under the stated reference model and inherited contour/shell proofs. Its operator upper bounds are currently too wide for the existing 0.020 Green and 0.005 qT budgets. Failure of a sufficient upper bound does not show the actual kernels violate a budget or the physical conversion claim is wrong.
