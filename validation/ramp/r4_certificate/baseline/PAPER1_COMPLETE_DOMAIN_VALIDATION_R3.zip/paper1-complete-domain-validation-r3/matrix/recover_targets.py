"""Recover the exact selected certificate targets without altering inputs."""
import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import numpy as np
from matrix_budget import NAMES, bound, json_exact, multiplicities, norm_bounds, slot

PREFIX=Path('validation/current_numerics/analysis/resolution_execution/certificate')
EXPECTED={
 'SELECTION.json':'d13f65f7fc1aa666fe29bca774584acd88644027204f0729106b2b0c78af14b6',
 'canonical_selected/pv_selected_20.npy':'ce45000dbd154d556c1cb2a967cc5992149bb2f0b8a98153d654c855b8280e24',
 'canonical_selected/surface_selected_12.npz':'af6620513ca1e81def55d0ddcc1ddffdaa3d2f4a46d5c2cd3d0acf1f13e8c0bb',
 'basis_invariant_n192_sobol23_m256_v1/proof160/finite_kernel_certificate.json':'9011e60be07bc62dcb1695ef92b108a8365319957f7a59abc7eb6965fdbdf594'}


def need(test,message):
    if not test: raise ValueError(message)


def exact_matrix(a):
    return [[[F(float(z.real)), F(float(z.imag))] for z in row] for row in a]


def representatives(a):
    # First positive-separation block, agreeing with d=s-t.
    v=[a[2*d][0] for d in range(6)]
    v += [a[2*d+1][1] for d in range(6)]
    v += [a[2*d][1] for d in range(1,6)]
    return v


def recover(repo):
    root=repo/PREFIX
    hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in EXPECTED}
    need(hashes==EXPECTED,'Selected authority/source hashes do not match')
    selection=json.loads((root/'SELECTION.json').read_text())
    proof=json.loads((root/'basis_invariant_n192_sobol23_m256_v1/proof160/finite_kernel_certificate.json').read_text())
    need(selection['status']=='selected_for_fixed_kernel_certificate','Wrong authority status')
    need(proof['status']=='finite_cached_kernel_certificate_passed','Wrong proof status')
    need(proof['selection_sha256']==hashes['SELECTION.json'],'Proof does not bind selection')
    need(proof['hypothetical_kernel_error_conclusion']['eG']=='1/50','Unexpected g budget')
    need(proof['hypothetical_kernel_error_conclusion']['eQ']=='1/200','Unexpected Q budget')
    pv=np.load(root/'canonical_selected/pv_selected_20.npy',allow_pickle=False)
    need(pv.shape==(20,20),'Wrong PV shape')
    pv=pv[:12,:12]
    with np.load(root/'canonical_selected/surface_selected_12.npz',allow_pickle=False) as z:
        imag=z['Im_total']; q0=z['Im_branch_0']; q1=z['Im_branch_1']
    for a in (pv,imag,q0,q1):
        need(a.shape==(12,12) and a.dtype==np.dtype('float64') and np.isfinite(a).all(), 'Wrong input array type/shape')
        need(np.array_equal(a,a.T),'Target not exactly symmetric')
    # The existing proof explicitly targets the saved-in-memory float64 sum,
    # not exact rational addition of the separate branches.
    q=q0+q1
    g=pv+1j*imag
    targets={'g':exact_matrix(g),'Q':exact_matrix(q)}
    residual={}
    for kind,M in targets.items():
        reps=representatives(M)
        points=[((z[0],z[0]),(z[1],z[1])) for z in reps]
        residual[kind]={'representative_moments':reps,
                        'point_template_to_actual_target':bound(points,M,kind)}
    # Float addition is reproduced then stored as exact fractions. Record the
    # largest discrepancy from hypothetical exact addition to catch ambiguity.
    sum_rounding=max(abs(F(float(q[i,j]))-F(float(q0[i,j]))-F(float(q1[i,j])))
                     for i in range(12) for j in range(12))
    return json_exact({
      'schema':'paper1.exact-selected-targets.v1',
      'status':'recovered_hash_bound_dyadic_targets_not_lattice_certificate',
      'authority_prefix':str(PREFIX),'source_sha256':hashes,
      'revision':selection['revision'],
      'moment_order':NAMES,'targets':targets,
      'template_diagnostics_exact':residual,
      'q_float64_sum_vs_exact_branch_sum_maximum':sum_rounding,
      'entry_multiplicities':multiplicities(),
      'bridge':proof['hypothetical_kernel_error_conclusion'],
      'fixed_floor_enclosure':proof['finite_floor_enclosure'],
      'input_claim':'Exact dyadic targets recovered. No lattice integration was run.'})


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args()
    result=recover(args.repo)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'revision':result['revision'],
      'template_diagnostics':{k:v['point_template_to_actual_target'] for k,v in result['template_diagnostics_exact'].items()},
      'q_float64_sum_vs_exact_branch_sum_maximum':result['q_float64_sum_vs_exact_branch_sum_maximum']}))
