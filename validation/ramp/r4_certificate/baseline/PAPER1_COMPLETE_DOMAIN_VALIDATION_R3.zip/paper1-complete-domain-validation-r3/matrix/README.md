# Complete-matrix error accounting

The selected targets are now recovered exactly and the moment-to-matrix budget
is executable. This resolves the bookkeeping needed to assess future complete
integration enclosures. It does not enclose the lattice integrals itself.

`TARGETS.json` binds the **current** selection
`basis_invariant_n192_sobol23_m256_v1`, with PV SHA-256 beginning `ce45000d`
and surface SHA-256 beginning `af662051`. Historical filenames embedded in the
finite proof still say M192/N128; the selection records identify these actual
contents as the adopted N192 surface and two-Sobol M256 PV reference. The
recoverer reads the canonical selected files and verifies their full hashes,
the selection hash and the bound proof record hash. It does not infer authority
from a filename.

The proof's selected fixed-matrix floor is
`[0.1080401795285133773085230187856824608202 +/- 3.00e-41]`.
Its conditional lattice floor is
`[0.1037986667791380149124393077511413006385 +/- 4.04e-41]`,
under the existing hypotheses

\[
\|\tfrac{169}{100}(g-g_c)\|_2\le\tfrac1{50},\qquad
\|\tfrac{169}{100}(Q-Q_c)\|_2\le\tfrac1{200},\qquad Q\succeq0.
\]

Those are inherited proof records, not fresh reruns of the whole-box proof.
Recovering their inputs and checking the following arithmetic does not prove
their unproved lattice-integration hypotheses.

## Exact mapping and bounds

The source order is `X0,R0,X1,R1,...,X5,R5`; moment order is
`a0,...,a5,c0,...,c5,b1,...,b5`. For `d=s-t>=0`, the block is

\[
K_d=\begin{pmatrix}a_d&b_d\\-b_d&c_d\end{pmatrix},
\qquad b_0=0,\qquad K_{-d}=K_d^T.
\]

Each nonzero-separation moment is inserted at **every** occurrence. The
entry multiplicities are `6,10,8,6,4,2` for each of a/c and
`20,16,12,8,4` for b. Every row has eleven potentially nonzero structural
entries; its twelfth entry is the same-segment X/R zero.

`matrix_budget.bound` compares each assembled complex rectangle with the
corresponding **actual dyadic target entry**. This includes all center
displacements and all tiny departures of the cache from the exact template.
For a rectangle `([l_r,h_r],[l_i,h_i])` and target `(t_r,t_i)`, its modulus
envelope is an upward rational bound on

\[
\sqrt{\max(|l_r-t_r|,|h_r-t_r|)^2+
       \max(|l_i-t_i|,|h_i-t_i|)^2}.
\]

If the resulting nonnegative 12-by-12 envelope is E, the code proves the
sufficient bound

\[
\|\Delta\|_2\le\min\!\left[
 \sqrt{(\max_i\sum_j E_{ij})(\max_j\sum_i E_{ij})},
 \sqrt{\sum_{ij}E_{ij}^2}\right].
\]

This follows from entrywise domination of vector magnitudes, the induced-norm
inequality and the Frobenius inequality. It remains valid for complex g and
does not assume an arbitrary submitted error envelope is symmetric. The full
g target is complex symmetric, rather than Hermitian. The actual real Q
target is symmetric.

All arithmetic uses Python `Fraction`; nonrational square roots are bounded
upward on a 180-bit dyadic grid by integer inequalities. No NumPy norm or
floating tolerance accepts a bound. Input interval endpoints must be exact
strings, integers or fractions. Floats, reversed endpoints, missing moments
and malformed complex target entries are rejected.

The Q target is the exact dyadic value of the **float64 sum** of the two
stored branch arrays, matching the controlling certificate. Exact addition
of their dyadic entries would differ by up to `1/72057594037927936`.
That different sum is not silently substituted.

## Budget consequences

For uniform modulus error delta in all seventeen moments, the exact template
part costs at most `11*delta`, before displacement from the actual cache.
The old generic twelve-entry rule was sufficient but slightly conservative.
Uniform sufficient planning allowances are therefore:

| Quantity | Total moment modulus error | Density over all three unit-area charts |
|---|---:|---:|
| Q | 1/3718 ≈ 0.000268962 | 1/11154 ≈ 0.0000896539 |
| g | 2/1859 ≈ 0.00107585 | 2/5577 ≈ 0.000358616 |

These exhaust the respective budgets only when center displacement and
cache-template residual are zero. They are planning limits, not measured
integration errors. For complex rectangular g enclosures, real and imaginary
radii must be combined into a modulus bound; the same number cannot be given
independently to both components without accounting for that combination.
Nonuniform moment allocation uses the explicit row occurrence counts in
`TARGETS.json`; it can be less restrictive than a uniform maximum rule.

The exact selected cache's first-block representative template has certified
operator *upper bounds* of approximately `1.73553e-17` for g and `3.47693e-18`
for Q. The scaled bounds are approximately `2.93304e-17` and `5.87600e-18`.
These tiny residuals are preserved. They describe cache symmetry only;
they say nothing about displacement of the **true integral** from that cache.

## Checks actually run

`CHECKS.json` records eleven positive check groups and twelve rejection
controls, including:

- independent assembly of all144 signed block entries and all17 basis
  multiplicities;
- exactly1152 corner-versus-target rational inequalities, sufficient to test
  the complex-rectangle modulus-envelope implementation;
- exact eleven-entry uniform budgets, a manufactured nonuniform budget,
  displaced zero-width intervals, and a nonzero cache residual at b0;
- square-root upper-bound inequalities, invalid input rejection and mutations
  of all four authority/cache/proof files;
- fresh recovery equal to the delivered exact targets.

The malformed-target review found that omitting a target imaginary component
could have truncated a `zip` operation. Requiring exactly two target components
fixed it before delivery; missing and extra component controls now reject it.
The normal recovered targets were unaffected.

Run from a directory containing the package:

```bash
python matrix/recover_targets.py --repo /path/to/paper1-validation-repository --output matrix/TARGETS.json
python matrix/check_matrix_budget.py --targets matrix/TARGETS.json --repo /path/to/paper1-validation-repository --output matrix/CHECKS.json
```

`--repo` is optional for the second command. Without it, arithmetic checks run
but fresh source recovery and the four source-file mutation tests do not run.

## Remaining dependency

The strongest unresolved condition is obtaining sufficiently tight, complete
g and Q integral enclosures. This module cannot infer completeness from
seventeen plausible numbers. A separately verified coverage ledger must bind
the domain, contour/exterior, source normalization and error certificates.
Its `arithmetic_budget_pass` is deliberately paired with
`certifies_global_integral=false`. It becomes part of the exact-lattice
argument only after the upstream integral enclosures and Q positivity are
established. No manuscript change is justified by bookkeeping alone.
