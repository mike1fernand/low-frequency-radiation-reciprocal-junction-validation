"""Complete-domain ordinary Gauss contour diagnostic, NEVER an error certificate."""
import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys
import time
import numpy as np
from numpy.polynomial.legendre import leggauss
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from matrix_budget import assemble

ENERGY=36/25


def coordinates(t,u,v,chart):
    t,u,v=np.broadcast_arrays(np.asarray(t,dtype=complex),u,v)
    if chart==0: return np.stack((t,t*u,t*v),axis=-1)
    if chart==1: return np.stack((t*u,t,t*v),axis=-1)
    if chart==2: return np.stack((t*u,t*v,t),axis=-1)
    raise ValueError('Expected chart0,1,2')


def symbol(k):
    c=np.cos(k);s=np.sin(k)
    D=2*s[..., :,None]*s[...,None,:]
    for i in range(3):
        D[...,i,i]=6-2*c[...,i]*(1+c[...,(i+1)%3]+c[...,(i+2)%3])
    return D


def bond_symbol(k):
    # Independent definition using 3 axial and6 unoriented face-diagonal bonds.
    bonds=np.array([[1,0,0],[0,1,0],[0,0,1],
       [1,1,0],[1,-1,0],[1,0,1],[1,0,-1],[0,1,1],[0,1,-1]])
    normals=bonds/np.sqrt(np.sum(bonds*bonds,axis=1))[:,None]
    terms=2*(1-np.cos(np.einsum('...i,bi->...b',k,bonds)))
    return np.einsum('...b,bi,bj->...ij',terms,normals,normals)


def moments(t,u,v,chart):
    k=coordinates(t,u,v,chart)
    D=symbol(k)
    H=np.linalg.inv(D-ENERGY*np.eye(3))
    kx,ky,kz=(k[...,i] for i in range(3))
    A=2*np.cos(ky/2)*np.cos(kz/2)
    B=np.sqrt(2)*np.sin(ky/2)*np.cos(kz/2)
    C=np.sqrt(2)*np.cos(ky/2)*np.sin(kz/2)
    aa=A*A*H[...,0,0]
    cc=B*B*H[...,1,1]+2*B*C*H[...,1,2]+C*C*H[...,2,2]
    bb=A*(B*H[...,0,1]+C*H[...,0,2])
    factor=np.asarray(t)**2/np.pi**3
    trig=np.cos(kx[...,None]*np.arange(6))
    out=np.concatenate((aa[...,None]*trig,cc[...,None]*trig,
       bb[...,None]*np.sin(kx[...,None]*np.arange(1,6))),axis=-1)*factor[...,None]
    if not np.isfinite(out).all(): raise ArithmeticError('Nonfinite floating moment')
    return out


def preflight(arb_source):
    sys.path.insert(0,str(arb_source.parent))
    from source_moments import moment_values
    from flint import acb,arb,ctx
    ctx.prec=160
    maximum=0.;symbolmax=0.;symmax=0.
    checks=[]
    for t,u,v in [(0.7-0.2j,.3,.6),(0-0.125j,0.,0.),
                  (1.2-0.07j,1.,1.),(2.1+0j,0.2,0.),(.723-0.01j,.9,.02)]:
        for chart in range(3):
            actual=moments(t,u,v,chart)
            balls=moment_values(acb(t.real,t.imag),arb(u),arb(v),chart)
            reference=np.array([complex(float(z.real.mid()),float(z.imag.mid())) for z in balls])
            error=float(np.max(np.abs(actual-reference)))
            scale=max(1.,float(np.max(np.abs(reference))))
            if error>3e-13*scale: raise ArithmeticError('NumPy/Arb primitive mismatch')
            maximum=max(maximum,error)
            sb=float(np.max(np.abs(symbol(coordinates(t,u,v,chart))-bond_symbol(coordinates(t,u,v,chart)))))
            symbolmax=max(symbolmax,sb)
            if sb>2e-14: raise ArithmeticError('Independent bond symbol mismatch')
        yz=float(np.max(np.abs(moments(t,u,v,1)-moments(t,u,v,2))))
        xx=float(np.max(np.abs(moments(t,u,v,0)-moments(t,v,u,0))))
        symmax=max(symmax,yz,xx)
        if max(yz,xx)>1e-12: raise ArithmeticError('y/z symmetry failed')
        checks.append({'t':[t.real,t.imag],'u':u,'v':v})
    return {'status':'floating_implementation_preflight_passed',
       'points':checks,'chart_evaluations':15,
       'maximum_numpy_arb_difference':maximum,
       'maximum_bond_symbol_difference':symbolmax,
       'maximum_y_z_reflection_difference':symmax,
       'arb_primitive_sha256':hashlib.sha256(arb_source.read_bytes()).hexdigest(),
       'scope':'Pointwise implementation check only, no integration enclosure.'}


def integrate(angular,radial,height,reuse_yz=False):
    x,w=leggauss(angular);u=(x+1)/2;aw=w/2
    r,rw=leggauss(radial);r=(r+1)/2;rw=rw/2
    U,V=np.meshgrid(u,u,indexing='ij');W=np.outer(aw,aw).ravel()
    U=U.ravel();V=V.ravel()
    s=np.arccos(.75);R=np.arccos(.25);h=height
    legs={'down0':(0,-1j*h),'across0s':(-1j*h,s),
          'acrosssR':(s-1j*h,R-s),'upR':(R-1j*h,1j*h),
          'exterior':(R,np.pi-R),'downs':(s,-1j*h)}
    chartresults=[];stage_times=[]
    for chart in range(2 if reuse_yz else 3):
        lt={}
        for name,(start,delta) in legs.items():
            tic=time.monotonic();total=np.zeros(17,complex)
            # Angular chunks bound peak memory and preserve complete coverage.
            for first in range(0,len(U),256):
                uu=U[first:first+256,None];vv=V[first:first+256,None]
                val=moments(start+delta*r[None,:],uu,vv,chart)
                total+=np.einsum('i,j,ijm->m',W[first:first+256],rw,val)*delta
            lt[name]=total
            stage_times.append({'chart':chart,'leg':name,'seconds':time.monotonic()-tic})
        g=sum((lt[x] for x in ('down0','across0s','acrosssR','upR','exterior')),np.zeros(17,complex))
        q=(lt['downs']+lt['acrosssR']+lt['upR']).imag
        chartresults.append({'g':g,'Q':q,'legs':lt})
    if reuse_yz: chartresults.append(chartresults[1])
    return chartresults,stage_times


def compare(chartresults,targets):
    output={}
    for kind in ('g','Q'):
        integrated=sum((c[kind] for c in chartresults),np.zeros(17,complex))
        mat=np.array(assemble(integrated))
        target=np.array([[complex(float(Fraction(z[0])),float(Fraction(z[1]))) for z in row]
                         for row in targets['targets'][kind]])
        displacement=mat-target
        output[kind]={
          'moments':[[float(z.real),float(z.imag)] for z in integrated],
          'scaled_operator_displacement_diagnostic':float(1.69*np.linalg.norm(displacement,2)),
          'scaled_row_sum_displacement_diagnostic':float(1.69*np.max(np.sum(np.abs(displacement),axis=1))),
          'maximum_entry_displacement_diagnostic':float(np.max(np.abs(displacement))),
          'matrix':[[[float(z.real),float(z.imag)] for z in row] for row in mat]}
    output['chart1_chart2_max_moment_difference']={k:float(np.max(np.abs(chartresults[1][k]-chartresults[2][k]))) for k in ('g','Q')}
    return output


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--angular',type=int,default=12)
    ap.add_argument('--radial',type=int,default=48)
    ap.add_argument('--height',type=float,default=.25)
    ap.add_argument('--reuse-yz',action='store_true')
    ap.add_argument('--targets',type=Path,required=True)
    ap.add_argument('--arb-source',type=Path)
    ap.add_argument('--output',type=Path,required=True)
    a=ap.parse_args()
    if a.angular<2 or a.radial<2 or not np.isfinite(a.height) or a.height<=0:
        raise ValueError('Invalid numerical integration settings')
    start=time.monotonic();out={}
    if a.arb_source: out['preflight']=preflight(a.arb_source)
    charts,times=integrate(a.angular,a.radial,a.height,a.reuse_yz)
    out.update({'status':'complete_domain_numerical_diagnostic_not_certified',
      'angular_order':a.angular,'radial_order':a.radial,'height':a.height,
      'energy':'36/25','chart_domain':'three copies of [0,1]^2',
      'normalization':'t^2/pi^3; no extra 1/(2*omega)',
      'contours':'g:0 to -ih to s-ih to R-ih to R plus R to pi; Q: imaginary part s to s-ih to R-ih to R',
      'y_z_symmetry_reuse':a.reuse_yz,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'targets_sha256':hashlib.sha256(a.targets.read_bytes()).hexdigest(),
      'comparison':compare(charts,json.loads(a.targets.read_text())),
      'stage_times':times,'seconds':time.monotonic()-start,
      'claim_limit':'Ordinary Gauss samples cover all integration ranges but supply no certified error. Differences across orders or heights are sensitivities, not upper bounds.'})
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:out[k] for k in ('status','angular_order','radial_order','seconds')}|
         {'displacement':{k:out['comparison'][k]['scaled_operator_displacement_diagnostic'] for k in ('g','Q')}}))
