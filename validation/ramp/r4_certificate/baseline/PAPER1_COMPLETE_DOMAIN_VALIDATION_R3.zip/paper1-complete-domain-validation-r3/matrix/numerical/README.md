# Complete-domain contour diagnostic and usable error allocation

The complete floating calculation predicts scaled operator displacement from
the selected cache of **0.001279250611** for g and **0.0008182002494** for Q.
Those are below the existing budgets 0.020 and 0.005, respectively. They are
ordinary numerical estimates, not certified errors of the selected cache.

The more useful rigorously checked consequence is a **conditional** allocation
around the saved exact dyadic candidate centers. Fraction arithmetic bounds
the assembled candidate-center matrix's displacement from the actual cache,
including the tiny template residuals. Combining the Frobenius and induced
norm bounds gives:

| Quantity | Scaled center-to-cache upper bound | Remaining uniform complete-moment modulus radius | Radius per unit area across all three charts |
|---|---:|---:|---:|
| g | 0.00185694624643 | 0.000975957705948 | 0.000325319235316 |
| Q | 0.000827651841781 | 0.000224440460366 | 0.000074813486788 |

The exact rational values control; displayed decimals are summaries. The
implication is: **if** each of the 17 complete moments lies within its stated
modulus radius of the recorded dyadic center, **then** the original operator
budget is met. This follows by the triangle inequality and the eleven
structural entries per row. No such enclosure around the true integrals is
proved here. In particular, the remaining density is an allocation to prove,
not an achieved integration error or a probabilistic confidence interval.

## Method actually executed

Tensor Gauss-Legendre quadrature integrates each of three charts
`k=t(1,u,v),t(u,1,v),t(u,v,1)` with `u,v` in `[0,1]`. Every source moment
includes `t^2/pi^3`. For `s=acos(3/4)`, `R=acos(1/4)` and height h:

- g includes the lower path `0 → -ih → s-ih → R-ih → R` and the complete
  real exterior `R → pi`.
- Q is the imaginary part of `s → s-ih → R-ih → R`.

The two shared legs are evaluated once per chart. The first run evaluates
all three charts independently. Later runs reuse chart 1 for chart 2 because
interchanging y and z sends `D` to `P D P^T`, leaves A and kx fixed, exchanges
B and C, and therefore leaves each of the 17 source moments invariant.
This maps chart 1 at (u,v) exactly to chart 2 at (u,v). The same symmetry sends
chart 0 at (u,v) to chart 0 at (v,u). The source's physical x direction is never
permuted. The algebra establishes the symmetry; numerical point and complete
chart checks test its implementation.

| Angular/radial order | Height | Charts directly computed | Recorded seconds |
|---|---:|---:|---:|
| 12/48 | 1/4 | 3 | 0.441 |
| 20/80 | 1/4 | 2, plus exact y/z reuse | 1.589 |
| 32/128 | 1/4 | 2, plus exact y/z reuse | 4.380 |
| 20/80 | 1/8 | 2, plus exact y/z reuse | 1.671 |

The maximum complex-moment difference from 20/80 to 32/128 was about
`2.48e-15` for g and `1.30e-15` for Q. Changing height from 1/4 to 1/8 at 20/80
changed the moments by about `1.3e-15`. The difference between 12/48 and 20/80 was larger,
about `2.26e-11` for g and `5.09e-13` for Q. These are sensitivities, not upper
bounds. They justified stopping this inexpensive diagnostic refinement; they
do not justify an exact-lattice floor.

Before integration, the vectorized NumPy primitive was compared with the
saved 160-bit Arb source primitive at five locations in all three charts,
including coordinate-plane, axis and diagonal cases. Maximum discrepancy was
`7.81e-17`. The explicit trigonometric Bloch matrix was independently compared
with the nine-bond stiffness sum, maximum discrepancy `4.97e-16`. The complete
first-run chart 1 versus chart 2 moment difference was below `2e-17`. These checks
address implementation, source orientation and normalization consistency;
none proves quadrature convergence.

## Reproduction and records

The four run JSON files contain all 17 complex moments, assembled matrices,
settings, source and target hashes, per-leg times and claim limits.
`ASSESSMENT.json` binds those runs and records the exact candidate centers and
conditional allocations. To reproduce a run:

```bash
python matrix/numerical/contour_diagnostic.py --angular 12 --radial 48 --targets matrix/TARGETS.json --arb-source /path/to/r2/pilot/source_moments.py --output matrix/numerical/gl12_48.json
```

For the later runs, use the orders and heights above, add `--reuse-yz`, and
omit `--arb-source` after the preflight has been run. Then run:

```bash
python matrix/numerical/assess_diagnostic.py
```

Each recorded run took under five seconds. Angular chunks bound memory use.
This diagnostic changes no manuscript text, selected cache or previous
certificate. The unresolved work is proving the complete moment enclosures
tight enough to meet these allocations, with all chart and exterior coverage
and certified integration errors.
