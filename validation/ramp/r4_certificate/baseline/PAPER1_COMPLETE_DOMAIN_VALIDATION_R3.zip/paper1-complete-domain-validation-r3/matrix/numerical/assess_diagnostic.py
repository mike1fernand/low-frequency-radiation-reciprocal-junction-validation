"""Compare executed diagnostics and derive exact conditional radius allocations."""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from matrix_budget import bound, KSTAR, THRESHOLDS, json_exact


def main():
    root=Path(__file__).resolve().parent
    paths=[root/x for x in ('gl12_48.json','gl20_80.json','gl32_128.json','gl20_80_h0125.json')]
    data=[json.loads(p.read_text()) for p in paths]
    targetpath=root.parent/'TARGETS.json'
    targets=json.loads(targetpath.read_text())
    targethash=hashlib.sha256(targetpath.read_bytes()).hexdigest()
    sourcehash=hashlib.sha256((root/'contour_diagnostic.py').read_bytes()).hexdigest()
    for d in data:
        if d['status']!='complete_domain_numerical_diagnostic_not_certified' or d['targets_sha256']!=targethash or d['source_sha256']!=sourcehash:
            raise ValueError('Diagnostic provenance does not match')
        for kind in ('g','Q'):
            a=np.asarray(d['comparison'][kind]['moments'])
            if a.shape!=(17,2) or not np.isfinite(a).all():
                raise ValueError('Wrong moment shape or values')
    comparisons=[]
    for i,j,label in [(0,1,'12/48 to20/80'),(1,2,'20/80 to32/128'),(1,3,'height1/4 to1/8 at20/80')]:
        values={}
        for kind in ('g','Q'):
            a=np.array(data[i]['comparison'][kind]['moments']);b=np.array(data[j]['comparison'][kind]['moments'])
            delta=(a-b)[:,0]+1j*(a-b)[:,1]
            values[kind]=float(np.max(np.abs(delta)))
            if values[kind]>1e-8:
                raise ArithmeticError('Unexpected diagnostic sensitivity; investigate before using centers')
        comparisons.append({'comparison':label,'maximum_complex_moment_difference':values})
    selected=data[2]
    allocations={}
    for kind in ('g','Q'):
        # Saved float64 centers are exact candidate numbers, not exact integrals.
        centers=[(F(z[0]),F(z[1])) for z in selected['comparison'][kind]['moments']]
        intervals=[((re,re),(im,im)) for re,im in centers]
        center=bound(intervals,targets['targets'][kind],kind)
        delta=(THRESHOLDS[kind]/KSTAR-center['operator_upper'])/11
        if delta<=0: raise ArithmeticError('Candidate centers leave no uniform radius budget')
        # Exact algebra: ||Delta_cache|| <= ||M(center)-cache||+11*delta.
        lhs=KSTAR*(center['operator_upper']+11*delta)
        if lhs!=THRESHOLDS[kind]: raise ArithmeticError('Conditional allocation algebra failed')
        allocations[kind]={
          'candidate_centers_exact_dyadic':centers,
          'center_to_actual_cache_operator_upper':center['operator_upper'],
          'scaled_center_to_actual_cache_upper':center['scaled_operator_upper'],
          'remaining_uniform_moment_modulus_radius':delta,
          'remaining_uniform_chart_area_density':delta/3,
          'scaled_center_upper_diagnostic':float(center['scaled_operator_upper']),
          'radius_diagnostic':float(delta),'density_diagnostic':float(delta/3),
          'hypothesis':'IF all17 true complete moments are within the stated modulus radius of these exact candidate centers, THEN the existing operator budget is met. No such radius enclosure is proved here.',
          'hypothesis_proved':False}
    result=json_exact({
       'status':'complete_domain_diagnostic_and_conditional_allocation_checked_not_error_certificate',
       'source_sha256':sourcehash,'targets_sha256':targethash,
       'assessment_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
       'runs_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
       'ordinary_quadrature_sensitivities':comparisons,
       'selected_candidate_center_run':'gl32_128.json',
       'diagnostic_scaled_operator_displacement':{k:selected['comparison'][k]['scaled_operator_displacement_diagnostic'] for k in ('g','Q')},
       'conditional_uniform_allocations':allocations,
       'elapsed_seconds_all_four_runs':sum(d['seconds'] for d in data),
       'limitations':['Mesh and contour-height agreement is not a quadrature-error bound.',
                     'Exact radius-allocation arithmetic proves only an implication about unproved integral enclosures.',
                     'No source manuscript, selected cache, fixed-matrix certificate, or numerical headline was changed.']})
    (root/'ASSESSMENT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'conditional_density':{k:v['density_diagnostic'] for k,v in result['conditional_uniform_allocations'].items()},'sensitivities':comparisons}))


if __name__=='__main__': main()
