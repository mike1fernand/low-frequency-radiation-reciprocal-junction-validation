"""Meaningful exact-arithmetic checks; no test substitutes for global integration."""
import argparse
from fractions import Fraction as F
import hashlib
import itertools
import json
from pathlib import Path
import random
import shutil
import tempfile
from matrix_budget import *
from recover_targets import recover, representatives, EXPECTED, PREFIX


def need(v,msg):
    if not v: raise ArithmeticError(msg)


def check(targets,repo):
    checks=[]
    failures=[]
    def passed(name): checks.append(name)
    zero=[[(F(0),F(0)) for _ in range(12)] for _ in range(12)]
    m=multiplicities()
    expected=[6,10,8,6,4,2]*2+[20,16,12,8,4]
    need(m['entries']==expected,'Toeplitz occurrence count changed')
    need(sum(expected)==132 and all(sum(row)==11 for row in m['rows']),'Structural support changed')
    passed('all_17_multiplicities_and_12_row_counts')
    vals=[F(i*i+3*i+7,1000) for i in range(17)]
    M=assemble(vals)
    # Independent explicit block formula with signed lag, including all144 entries.
    for s,t in itertools.product(range(6),repeat=2):
        d=s-t; lag=abs(d)
        b=F(0) if d==0 else (1 if d>0 else -1)*vals[11+lag]
        expectedblock=[[vals[lag],b],[-b,vals[6+lag]]]
        for a,beta in itertools.product(range(2),repeat=2):
            need(M[2*s+a][2*t+beta]==expectedblock[a][beta],'Signed lag/block mismatch')
    need(all(M[i][j]==M[j][i] for i,j in itertools.product(range(12),repeat=2)),'Complex-symmetric structure broken')
    passed('independent_all_entry_signed_block_assembly')
    need(M[2][1]>0 and M[0][3]<0 and M[1][2]>0,'X/R sign convention failed')
    for k in range(17):
        v=[F(0)]*17; v[k]=F(1)
        A=assemble(v)
        need(sum(x!=0 for row in A for x in row)==expected[k],'Basis multiplicity failure')
    passed('seventeen_basis_occurrence_tests')
    # Uniform modulus error allocation uses11 nonzero structural terms per row.
    for kind,delta in [('Q',F(1,3718)),('g',F(2,1859))]:
        intervals=[((-delta,delta),(F(0),F(0)))]*17
        r=bound(intervals,zero,kind)
        need(r['row_sum']==11*delta and r['scaled_operator_upper']==THRESHOLDS[kind]
             and r['arithmetic_budget_pass'],'Uniform sufficient allocation wrong')
    passed('exact_uniform_structural_budget_11_not_12')
    rng=random.Random(20260920)
    intervals=[]
    for _ in range(17):
        lo=F(rng.randrange(-100,100),1000);hi=lo+F(rng.randrange(1,100),10000)
        imlo=F(rng.randrange(-20,20),10000);imhi=imlo+F(rng.randrange(1,20),100000)
        intervals.append(((lo,hi),(imlo,imhi)))
    # Check every complex-rectangle corner against exact targets. The maximum
    # squared modulus on a rectangle is attained at a corner, so no sampling
    # premise or floating norm computation enters this envelope test.
    corner_count=0
    for kind in ('Q','g'):
        T=target_matrix(targets['targets'][kind]);E=envelope(intervals,T)
        for i,j in itertools.product(range(12),repeat=2):
            k,sgn=slot(i,j)
            z=((F(0),F(0)),(F(0),F(0))) if k is None else intervals[k]
            for re,im in itertools.product(*z):
                re*=sgn if k is not None else 1;im*=sgn if k is not None else 1
                need((re-T[i][j][0])**2+(im-T[i][j][1])**2<=E[i][j]**2,
                     'Actual target/corner not enclosed')
                corner_count+=1
    passed('all_1152_actual_target_rectangle_corner_inequalities_exact')
    need(corner_count==1152,'Corner coverage missing')
    # A tiny b0 target entry must not disappear when assembling exact b0=0.
    perturbed=[[tuple(z) for z in row] for row in zero]
    perturbed[0][1]=(F(1,10**8),F(-1,10**9))
    P=[((0,0),(0,0))]*17
    E=envelope(P,perturbed)
    need(E[0][1]**2>=F(101,10**18) and E[0][1]>0,'b0 target residual omitted')
    passed('structural_zero_preserves_actual_cache_residual')
    # Nonuniform row pattern reproduces repeated moments rather than the largest
    # moment times12. This test is manufactured, explicitly not lattice data.
    errs=[F(12,100000),F(10,100000),F(9,100000),F(8,100000),F(7,100000),F(6,100000),
          F(14,100000),F(11,100000),F(10,100000),F(9,100000),F(8,100000),F(7,100000),
          F(4,100000),F(35,1000000),F(3,100000),F(25,1000000),F(2,100000)]
    r=bound([((-e,e),(0,0)) for e in errs],zero,'Q')
    need(r['row_sum']==F(83,100000) and r['row_sum']<11*max(errs),'Nonuniform allowance failed')
    passed('exact_nonuniform_repeated_moment_row_budget')
    # Center displacement is necessary even with zero integration width.
    p=[((F(1,100),F(1,100)),(0,0))]*17
    r=bound(p,zero,'Q')
    need(not r['arithmetic_budget_pass'],'Center displacement silently ignored')
    passed('zero_radius_nonzero_center_displacement_rejected')
    for q in [F(0),F(1,4),F(2),F(7,13),F(10**100+1,10**99+7)]:
        u=sqrt_up(q);need(u*u>=q,'Square-root upper bound failed')
        if u.denominator==1<<180:
            need((u-F(1,1<<180))**2<q,'Dyadic upper bound not minimal')
    passed('rational_and_irrational_sqrt_upper_checks')
    negative={
      'float_endpoint':lambda:parse_intervals([((0.,1.),(0,0))]*17),
      'reversed_endpoint':lambda:parse_intervals([((1,0),(0,0))]*17),
      'missing_moment':lambda:parse_intervals(P[:-1]),
      'infinite_endpoint':lambda:parse_intervals([(('inf','inf'),(0,0))]*17),
      'malformed_target_entry':lambda:target_matrix([[(0,0,0)]*12]*12),
      'missing_target_imaginary_entry':lambda:target_matrix([[(0,)]*12]*12),
      'unknown_target_kind':lambda:bound(P,zero,'total_spectral'),
      'negative_envelope':lambda:norm_bounds([[-1]*12]*12)}
    for name,func in negative.items():
        try: func()
        except (TypeError,ValueError,ZeroDivisionError): failures.append(name)
        else: raise ArithmeticError('Expected rejection did not occur: '+name)
    if repo:
        actual=recover(repo)
        need(actual==targets,'Recovered targets differ from delivered targets')
        passed('fresh_recovery_matches_serialized_targets')
        with tempfile.TemporaryDirectory() as td:
            copy=Path(td);dest=copy/PREFIX
            for p in EXPECTED:
                (dest/p).parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(repo/PREFIX/p,dest/p)
            for p in EXPECTED:
                path=dest/p;old=path.read_bytes();path.write_bytes(old+b'x')
                try: recover(copy)
                except ValueError: failures.append('mutated_authority_or_cache_'+p)
                else: raise ArithmeticError('Hash mutation not rejected '+p)
                path.write_bytes(old)
        passed('four_hash_bound_source_mutation_controls')
    return {'status':'passed_exact_matrix_bookkeeping_not_global_integral_certificate',
      'positive_checks':checks,'negative_rejections':failures,
      'exact_target_corner_inequalities':corner_count,
      'targets_sha256':None,'limitations':[
      'Only arithmetic implications were validated; input intervals must cover complete lattice integrals.',
      'Small representative-template residuals do not measure lattice integration error.',
      'Manufactured error allocations are planning examples, not measured errors.']}


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--targets',type=Path,required=True)
    ap.add_argument('--repo',type=Path)
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args()
    result=check(json.loads(args.targets.read_text()),args.repo)
    result['targets_sha256']=hashlib.sha256(args.targets.read_bytes()).hexdigest()
    result['producer_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest()
      for p in [Path(__file__),Path(__file__).with_name('matrix_budget.py'),Path(__file__).with_name('recover_targets.py')]}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
