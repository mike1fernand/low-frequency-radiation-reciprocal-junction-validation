"""Exact rectangular coverage; boundaries have zero integration measure.

The validator rejects overlap rather than allowing multiplicities to hide it.
Every uncovered rectangle is explicit and must receive a fallback enclosure.
"""
from fractions import Fraction as F


def rect(bounds):
    if len(bounds) != 4:
        raise ValueError('rectangle requires four bounds')
    a,b,c,d=map(F,bounds)
    if not (0<=a<b<=1 and 0<=c<d<=1):
        raise ValueError('positive-area rectangle must lie inside unit chart')
    return a,b,c,d


def area(bounds):
    a,b,c,d=rect(bounds)
    return (b-a)*(d-c)


def intersection_area(x,y):
    a,b,c,d=rect(x); e,f,g,h=rect(y)
    return max(F(0),min(b,f)-max(a,e))*max(F(0),min(d,h)-max(c,g))


def complete_chart(bounds_list):
    rs=[rect(x) for x in bounds_list]
    for j,r in enumerate(rs):
        for old in rs[:j]:
            if intersection_area(r,old):
                raise ValueError('positive-area overlap or duplicate coverage')
    xs=sorted({F(0),F(1),*(x for r in rs for x in r[:2])})
    ys=sorted({F(0),F(1),*(x for r in rs for x in r[2:])})
    gaps=[]
    for a,b in zip(xs,xs[1:]):
        for c,d in zip(ys,ys[1:]):
            u=(a+b)/2; v=(c+d)/2
            if not any(e<u<f and g<v<h for e,f,g,h in rs):
                gaps.append((a,b,c,d))
    covered=sum((area(r) for r in rs),F(0))
    remainder=sum((area(r) for r in gaps),F(0))
    if covered+remainder != 1:
        raise ArithmeticError('coverage arithmetic invariant failed')
    return {'refined_area':str(covered),'fallback_area':str(remainder),
            'fallback_rectangles':[[str(z) for z in r] for r in gaps]}


def full_cover(records):
    for r in records:
        if type(r['chart']) is not int or r['chart'] not in (0,1,2):
            raise ValueError('invalid chart')
    result={str(j):complete_chart([r['bounds'] for r in records if r['chart']==j])
            for j in range(3)}
    if sum(F(v['refined_area'])+F(v['fallback_area']) for v in result.values())!=3:
        raise ArithmeticError('missing chart')
    return result


def selftest():
    checks=[]
    def ok(name,test):
        if not test: raise AssertionError(name)
        checks.append(name)
    def rejects(name,fun):
        try:fun()
        except ValueError:checks.append(name)
        else:raise AssertionError(name+' did not reject')
    ok('empty chart is all fallback',complete_chart([])['fallback_area']=='1')
    ok('full chart no fallback',complete_chart([['0','1','0','1']])['fallback_area']=='0')
    tiles=[[str(F(i,3)),str(F(i+1,3)),str(F(j,5)),str(F(j+1,5))] for i in range(3) for j in range(5)]
    ok('rational grid complete',complete_chart(tiles)['refined_area']=='1')
    ok('missing cell remains fallback',complete_chart(tiles[:-1])['fallback_area']=='1/15')
    rejects('duplicate rejected',lambda:complete_chart([tiles[0],tiles[0]]))
    rejects('overlap rejected',lambda:complete_chart([['0','3/4','0','1'],['1/2','1','0','1']]))
    rejects('outside rejected',lambda:complete_chart([['-1/9','1','0','1']]))
    rejects('zero area rejected',lambda:complete_chart([['0','0','0','1']]))
    rejects('invalid chart rejected',lambda:full_cover([{'chart':3,'bounds':['0','1','0','1']}]))
    three=full_cover([{'chart':0,'bounds':['0','1','0','1']}])
    ok('unlisted charts explicitly fallback',three['1']['fallback_area']==three['2']['fallback_area']=='1')
    ok('unequal boundaries exact',complete_chart([['0','1/7','0','1/11']])['fallback_area']=='76/77')
    return {'status':'passed','checks':checks,'count':len(checks)}


if __name__=='__main__':
    import argparse,json
    from pathlib import Path
    p=argparse.ArgumentParser();p.add_argument('--selftest',action='store_true');p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    if not a.selftest:p.error('--selftest required')
    out=selftest();a.output.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
