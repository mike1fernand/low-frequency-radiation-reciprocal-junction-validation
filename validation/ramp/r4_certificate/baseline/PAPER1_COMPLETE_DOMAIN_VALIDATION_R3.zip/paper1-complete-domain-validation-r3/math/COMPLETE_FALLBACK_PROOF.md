# Complete-domain bounds for unfinished integration regions

These conservative bounds cover **every** real angular direction in all three
maximum-coordinate charts. They are a coverage device, not a useful final
matrix-error certificate. They use the reference bare lattice, its actual
nine positive axial/face-diagonal bond representatives, unit conventions,
the fixed physical source x-axis, and exact energy E=36/25. The inherited
shell and contour proofs identify the model and establish the exact integral
identities. Their hashes are recorded by `complete_fallback.py`.

For any measurable angular set U in one chart, each bound below multiplied
by the ordinary parameter area |U| bounds its integral. This area is du dv,
**not solid angle**; t² is already included in each radial integral. Three
unit squares cover the positive octant up to boundaries of measure zero.
The factor 1/pi³ already accounts for octant reflection.

## 1. Quantitative inverse bounds, uniformly in all chart directions

Let a be any chart direction: (1,u,v), (u,1,v), or (u,v,1), with 0≤u,v≤1.
For bond b, write p_b=a·b and P_b=n_b n_bᵀ, n_b=b/|b|. Direct summation gives

    Σ_b P_b = 3 I,
    S(a) := Σ_b p_b² P_b = |a|² I + 2 a aᵀ ≥ I.

Both matrix identities are checked exactly with SymPy in the executable.
Set R=acos(1/4), s=acos(3/4), m=3/50,
c=sin(2R)/(2R)>0, and H(z)=[D(za)-EI]⁻¹.
For 0<x≤R and y>0, since |xp_b|≤2R<pi,

    -Im D((x-iy)a)
       = 2 Σ_b sin(xp_b) sinh(yp_b) P_b
       ≥ 2 x y c S(a) ≥ 2 x y c I.

Here sin(q)/q≥c on |q|≤2R and sinh(q)/q≥1. The first inequality follows
from the monotonicity of sin(q)/q on [0,pi]: the derivative numerator
q cos(q)-sin(q) starts at zero and has derivative -q sin(q)<0.
The Hermitian imaginary part equals the entrywise imaginary part because
D is complex symmetric with real symmetric coefficient matrices.
For any vector w, |w*Aw|≤||w|| ||Aw||; taking its imaginary part therefore gives

    ||H(x-iy)||₂ ≤ 1/(2 x y c).                         (1)

This is quantitative and applies on coordinate planes, axes, and the body
diagonal. It does not presume distinct lower eigenvalues.

At x=0, D(-iya) is real negative semidefinite, so ||H(-iy)||₂≤1/E.
For 0≤x≤δ=1/4, all cos(xp_b) are nonnegative. Consequently

    Re D((x-iy)a) ≤ D(xa) ≤ x² S(a) ≤ 9 x² I,

where 2(1-cos q)≤q² and |a|²≤3. Hence

    ||H(x-iy)||₂ ≤ 1/(E-9δ²),  0≤x≤δ, y≥0.           (2)

The denominator is 351/400>0. No singular 1/x bound is used at the origin.

At x=s and x=R, the inherited real-axis inequalities give
dist(0,spectrum(D(xa)-EI))≥m. For all y≥0,

    ||D((x-iy)a)-D(xa)||₂ ≤ 6 (exp(2y)-1).             (3)

Indeed |cos(q-ir)-cos(q)|≤exp(|r|)-1, |p_b|≤2, and
||Σ_b z_b P_b||₂≤3 max_b |z_b|. The latter follows by applying
Cauchy–Schwarz to Σ_b |v*P_bw| and using Σ_b P_b=3I; it does not
assume the complex coefficients share a phase. Set ε=1/512. Outward
arithmetic verifies 6(exp(2ε)-1)<m/2. Neumann perturbation at the exact
real endpoint then gives

    ||H(x-iy)||₂ ≤ 2/m,  x in {s,R}, 0≤y≤ε.           (4)

For ε≤y≤h, use (1). This resolves the endpoint divergence of the
1/y estimate without deleting either vertical contour edge.

## 2. A finite Green bound, including the regular exterior

Take h=1/4. More generally the executable permits any provably h≥ε.
Define, for x=s or R,

    V(x) = (2/m)(x²ε+ε³/3)
           + [x² log(h/ε)+(h²-ε²)/2]/(2xc).

Equations (1) and (4) imply that V(x) bounds
the integral from y=0 to h of (x²+y²)||H(x-iy)||₂ dy.
The complete lower Green contour is
0 → -ih → R-ih → R. Its weighted inverse integral is bounded by

    J_g = h³/(3E)
        + (δ³/3+h²δ)/(E-9δ²)
        + [(R²-δ²)/2+h² log(R/δ)]/(2ch)
        + V(R).                                      (5)

Each term represents a real path segment: the initial vertical edge,
the near-origin bottom segment, the remaining bottom segment, and the
final vertical edge. Thus path derivatives, orientation-independent
magnitudes, and the |z²|=x²+y² Jacobian factor are all retained.

On this contour each |Im k_i|≤h. Put C_h=cosh(h/2). The analytic source
obeys |A|≤2C_h² and ||(B,C)||≤2C_h². The three source-resolvent
quadratic or cross forms therefore have magnitude at most
4 C_h⁴ ||H||₂. Both |sin(d k_x)| and |cos(d k_x)| are at most cosh(dh).
These estimates apply to the holomorphic source continuation, without
conjugating a complex contour point. Every moment with separation d has
contour magnitude at most

    [4 C_h⁴ cosh(dh)/pi³] J_g.                        (6)

For the real exterior R≤t≤pi, the inherited global exclusion gives
||H(t)||₂≤1/m. Real source norm bounds are A²≤4,
B²+C²≤2, and |A|sqrt(B²+C²)≤2sqrt(2). Consequently its moment magnitude is

    C_ext (pi³-R³)/(3 pi³ m),                          (7)

with C_ext=4 for a_d, 2 for c_d, and 2sqrt(2) for b_d.
The exterior is real; (6)+(7) bounds the absolute real part of each
exact full Green moment. No exterior term contributes to qT or to the
Green imaginary part at the specified real frequency.

For independent comparison, the qT contour weighted inverse bound is

    J_Q = V(s)+[(R²-s²)/2+h² log(R/s)]/(2ch)+V(R).

Equation (6), with J_Q replacing J_g, is a valid qT magnitude bound.
The executable records it as an alternative, but the direct spectral
bound below is smaller and is used for the fallback ledger.

## 3. Sharper spectral bounds for qT and the Green imaginary part

The complete radial root census proves exactly three branch roots with
multiplicity, two lower roots in (s,R) and one upper root in (0,s).
Set β=2R/sqrt(15). The radial monotonicity inequality is
t D'(ta)≥β D(ta). At a shell root t_*, with null projector P,

    P D'(t_*)P ≥ (βE/t_*)P.

Thus the residue B_* = P [P D'(t_*)P]⁻¹ P is PSD and obeys
||B_*||₂≤t_*/(βE), including multiple roots. Its rank equals the root
multiplicity. Since the total lower multiplicity is two and the total
multiplicity is three, bounding each residue separately (or by its trace)
gives a total multiplier of at most two or three respectively.

At these real shell points 0≤k_y,k_z<R. If r=sin²(k_y/2) and
t=sin²(k_z/2), then r,t≤3/8 and

    A² ≤ 4,
    B²+C² = 2(r+t-2rt) ≤ 15/16,
    |A|sqrt(B²+C²) ≤ sqrt(15)/2.

The middle polynomial is increasing in each variable on this rectangle;
its maximum is its exact upper-corner value. Since |sin(dk_x)| and
|cos(dk_x)|≤1 and t_*³≤R³, define

    K = R³/(pi² β E),
    C_shell = 4 (a_d), 15/16 (c_d), sqrt(15)/2 (b_d).

Then every direction obeys the magnitude bounds

    |qT moment| ≤ 2 C_shell K,
    |Im full Green moment| ≤ 3 C_shell K.             (8)

The pi² denominator contains the **spectral factor pi** times the
positive-octant 1/pi³ normalization. The derivative is with respect to
the chart radius t. No additional 1/(2ω) is present. The bound does not
assign equal weights to tied modes or infer matrix positivity from
sampled eigenvalues. The a_0 and c_0 moments in (8) are nonnegative.

## 4. Exact qT matrix positivity and safe symmetry reductions

Let F(k) contain all twelve actual source columns, including segment
phases and the X/R phases used in the controlling model. For any complex
coefficient vector w and every lower spectral residue B_*,

    w* F(k)* B_* F(k) w = (F(k)w)* B_* (F(k)w) ≥ 0.

Integrating with positive measure t_*² du dv and the positive spectral
normalization, or using the original full-Brillouin-zone spectral
measure, proves the **exact** Q matrix is PSD. Positive sums of complete
tied-eigenspace residues preserve this result. The real octant moment
reduction must reconstruct this same physical matrix with all phases
and Toeplitz occurrences; the separate assembler checks that identity.
Interval midpoints need not be PSD, and midpoint PSD is neither the
proof nor a substitute for this spectral argument. Positivity alone
does not make the selected-matrix perturbation budget pass.

The physical exchange y↔z is an exact symmetry of all seventeen moments.
D and H are conjugated by the coordinate permutation fixing x; A is
unchanged, B and C are exchanged, and k_x is unchanged. Thus each of
the forms A²Hxx, B²Hyy+2BCHyz+C²Hzz, and A(BHxy+CHxz) is unchanged.
This algebra is checked exactly, and finite complex-point comparisons
check the implementation. Consequently

    f_chart1(t,u,v) = f_chart2(t,u,v),
    f_chart0(t,u,v) = f_chart0(t,v,u).

These identities permit reuse of certified enclosures only after their
angular regions, physical source, and parameters have been matched.
Reusing chart1 in chart2 requires its distinct chart2 domain to remain
in the coverage ledger with its own contribution; it is not a reason
to omit a chart. Arbitrary exchanges involving x are not justified.

## 5. Executed checks and interpretation

`COMPLETE_FALLBACK_CHECKS.json` records exact symbolic identity checks,
outward evaluation of all constants, 216 finite imaginary-coercivity
falsification comparisons, and 204 finite source-symmetry comparisons.
The finite samples supplement the analytic proof; they do not prove
the uniform inequalities. With h=1/4, the largest rate per unit du dv
area is approximately 27.58556 for the Green real part, 2.84081 for its
imaginary part, and 1.89387 for qT. Exact binary **upper endpoints**,
not these diagnostic decimals, are used in downstream sums.

For a signed component, a region of area A can use [-A U,+A U], where U
is the appropriate certified upper rate. For nonnegative a_0,c_0
imaginary/qT components it may use [0,A U]. Refinements may replace or
intersect these enclosures when they concern exactly the same complete
region and component. They may not be added on top of a fallback for
the same region. A complete but very wide fallback enclosure establishes
coverage only; it does not enclose the selected matrix differences
tightly enough to establish the proposed floor.

The proof is specific to the reference energy and bare bulk. Frequency
or spring-constant sweeps require new constants and, where relevant,
new root-census/contour arguments. No changed-frequency guarantee is
claimed. All quantities use the inherited dimensionless unit convention;
these numerical inverse bounds cannot be transplanted to dimensional
variables without restoring the dynamical-matrix and source units.
