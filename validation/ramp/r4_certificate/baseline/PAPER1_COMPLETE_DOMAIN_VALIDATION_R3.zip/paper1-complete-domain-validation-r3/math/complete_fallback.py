#!/usr/bin/env python3
"""Conservative complete-chart bounds; see COMPLETE_FALLBACK_PROOF.md.

The returned numbers bound exact integral magnitude per unit (u,v) area,
not quadrature uncertainty and not a successful selected-cache budget.
All transcendental evaluations and endpoints use outward Arb arithmetic.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys

from flint import arb, ctx

NAMES = [f'a_{d}' for d in range(6)] + [f'c_{d}' for d in range(6)] + [f'b_{d}' for d in range(1, 6)]


def endpoint(x):
    m, e = x.man_exp()
    return {'mantissa': str(m), 'exponent2': int(e)}


def rate_record(x):
    assert x > 0 and x.is_finite()
    return {'upper': endpoint(x.upper()), 'upper_diagnostic': float(x.upper())}


def complete_rates(height='1/4'):
    """Return rigorous nonnegative magnitude bounds for each chart direction.

    g_real bounds |Re Green moment|; g_imag bounds |Im Green moment|;
    qt bounds |qT moment|. A measurable angular subset of area A has each
    magnitude <= A times the corresponding rate. All three charts obey the
    same rates. a_0,c_0 are additionally nonnegative for g_imag and qt.
    """
    E = arb(36)/25
    m = arb(3)/50
    R = (arb(1)/4).acos()
    s = (arb(3)/4).acos()
    c = (2*R).sin()/(2*R)
    beta = 2*R/arb(15).sqrt()
    h = arb(height)
    eps = arb(1)/512
    delta = arb(1)/4
    if not h >= eps:
        raise ValueError('height must be provably at least 1/512')
    assert 2*delta < arb.pi()/2
    assert 6*((2*eps).exp()-1) < m/2
    assert E-9*delta**2 > 0 and c > 0

    def vertical(x):
        # Integral_0^h (x^2+y^2)||H(x-iy)|| dy.
        near = 2/m*(x*x*eps+eps**3/3)
        far = (x*x*(h/eps).log()+(h*h-eps*eps)/2)/(2*x*c)
        return near+far

    zero_edge = h**3/(3*E)
    bottom_near = (delta**3/3+h*h*delta)/(E-9*delta**2)
    bottom_far = ((R*R-delta*delta)/2+h*h*(R/delta).log())/(2*c*h)
    green_contour = zero_edge+bottom_near+bottom_far+vertical(R)
    qt_bottom = ((R*R-s*s)/2+h*h*(R/s).log())/(2*c*h)
    qt_contour = vertical(s)+qt_bottom+vertical(R)
    complex_source_factor = 4*(h/2).cosh()**4 / arb.pi()**3
    shell_common = R**3/(arb.pi()**2*beta*E)
    exterior_common = (arb.pi()**3-R**3)/(3*arb.pi()**3*m)
    real_source = [arb(4)]*6 + [arb(15)/16]*6 + [arb(15).sqrt()/2]*5
    exterior_source = [arb(4)]*6 + [arb(2)]*6 + [2*arb(2).sqrt()]*5
    ds = list(range(6))+list(range(6))+list(range(1,6))
    green_re = []
    green_im = []
    qt = []
    qt_contour_rates = []
    for d, C, Cext in zip(ds, real_source, exterior_source):
        complex_factor = complex_source_factor*(d*h).cosh()
        green_re.append(complex_factor*green_contour+Cext*exterior_common)
        green_im.append(3*C*shell_common)
        qt.append(2*C*shell_common)
        qt_contour_rates.append(complex_factor*qt_contour)
    return {
        'g_real': green_re, 'g_imag': green_im, 'qt': qt,
        'qt_contour_alternative': qt_contour_rates,
        'constants': {'E': E, 'R': R, 's': s, 'm': m, 'sinc_2R': c,
                      'beta': beta, 'height': h, 'endpoint_layer': eps,
                      'origin_bottom_split': delta,
                      'green_contour_weighted_inverse_integral': green_contour,
                      'qt_contour_weighted_inverse_integral': qt_contour,
                      'shell_common': shell_common, 'exterior_common': exterior_common},
    }


def symbolic_checks():
    import sympy as sp
    a = sp.Matrix(sp.symbols('ax ay az', real=True))
    bonds = [sp.Matrix(x) for x in ((1,0,0),(0,1,0),(0,0,1),
             (1,1,0),(1,-1,0),(1,0,1),(1,0,-1),(0,1,1),(0,1,-1))]
    S = sp.zeros(3)
    P = sp.zeros(3)
    for b in bonds:
        bb = b*b.T/(b.dot(b))
        S += (a.dot(b))**2*bb
        P += bb
    assert sp.simplify(S-(a.dot(a)*sp.eye(3)+2*a*a.T)) == sp.zeros(3)
    assert P == 3*sp.eye(3)
    A,B,C,hxx,hxy,hxz,hyy,hyz,hzz = sp.symbols('A B C hxx hxy hxz hyy hyz hzz')
    aa=A*A*hxx
    cc=B*B*hyy+2*B*C*hyz+C*C*hzz
    bb=A*(B*hxy+C*hxz)
    swap={B:C,C:B,hxy:hxz,hxz:hxy,hyy:hzz,hzz:hyy}
    for expr in (aa,cc,bb):
        assert sp.expand(expr.xreplace(swap)-expr) == 0
    r,t=sp.symbols('r t',real=True)
    cc_norm=2*(r+t-2*r*t)
    assert cc_norm.subs({r:sp.Rational(3,8),t:sp.Rational(3,8)}) == sp.Rational(15,16)
    return {'bond_second_moment_identity': True, 'bond_projector_sum_identity': True,
            'all_three_source_forms_yz_invariant': True,
            'shell_rotational_source_bound_15_over_16': True}


def finite_diagnostics(primitive):
    """Falsification diagnostics supplement the proofs; no grid proves a bound."""
    import importlib.util
    import numpy as np
    spec=importlib.util.spec_from_file_location('fallback_primitive',primitive)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    from flint import acb
    R=float((arb(1)/4).acos())
    c=float(((2*(arb(1)/4).acos()).sin()/(2*(arb(1)/4).acos())).mid())
    directions=((0.,0.),(1.,0.),(1.,1.),(.375,.625),(.01,.93),(.999,.7))
    worst_ratio=1e300
    comparisons=0
    yz_max=0.
    for u,v in directions:
        for chart in range(3):
            for x in (.01,.25,.73,R):
                for y in (.001,.125,.25):
                    D=module.symbol_matrix(acb(x,-y),u,v,chart)
                    Dn=np.array([[complex(float(D[i,j].real.mid()),float(D[i,j].imag.mid())) for j in range(3)] for i in range(3)])
                    mineig=float(np.linalg.eigvalsh(-Dn.imag).min())
                    ratio=mineig/(2*x*y*c)
                    assert ratio > 1-1e-10
                    worst_ratio=min(worst_ratio,ratio)
                    comparisons+=1
        t=acb(.9,-.125)
        one=module.moment_values(t,u,v,1)
        two=module.moment_values(t,u,v,2)
        left=module.moment_values(t,u,v,0)
        right=module.moment_values(t,v,u,0)
        for x,y in zip(one+left,two+right):
            assert x.overlaps(y)
            yz_max=max(yz_max,abs(complex(float((x-y).real.mid()),float((x-y).imag.mid()))))
    return {'kind':'finite_falsification_only','imaginary_coercivity_comparisons':comparisons,
            'minimum_observed_ratio_diagnostic':worst_ratio,
            'symmetry_pairs_checked':len(directions)*34,
            'maximum_symmetry_midpoint_difference_diagnostic':yz_max}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--r2-root',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--precision',type=int,default=160)
    args=p.parse_args()
    if args.precision < 80: p.error('precision must be at least 80 bits')
    ctx.prec=args.precision
    r2=args.r2_root
    primitive=r2/'pilot/source_moments.py'
    paths=[primitive,r2/'math/CONTOUR_DERIVATION.md',r2/'provenance/RADIAL_SHELL_PROOF.md',
           Path(__file__),Path(__file__).with_name('COMPLETE_FALLBACK_PROOF.md')]
    rates=complete_rates()
    result={'status':'proved_complete_chart_fallback_bounds',
            'scope':'Reference E=36/25, all17 source moments, all three real angular charts; conservative bounds only, no exact-lattice floor.',
            'precision_bits':ctx.prec,'moment_order':NAMES,
            'source_sha256':{str(q.relative_to(r2)) if q.is_relative_to(r2) else q.name:hashlib.sha256(q.read_bytes()).hexdigest() for q in paths},
            'symbolic_checks':symbolic_checks(),'diagnostic_checks':finite_diagnostics(primitive),
            'constants':{k:rate_record(v) for k,v in rates['constants'].items()},
            'per_unit_angular_area':{k:list(map(rate_record,rates[k])) for k in ('g_real','g_imag','qt','qt_contour_alternative')},
            'nonnegative_indices_g_imag_and_qt':[0,6],
            'coverage_rule':'Multiply each outward upper endpoint by exact nonnegative angular area, then sum every disjoint region from each of the three charts exactly once.',
            'all_three_charts_upper':{k:[rate_record(3*v) for v in rates[k]] for k in ('g_real','g_imag','qt')}}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'checks':result['symbolic_checks'],
                     'diagnostic_checks':result['diagnostic_checks'],
                     'per_chart_max':{k:max(float(v.upper()) for v in rates[k]) for k in ('g_real','g_imag','qt')}}))


if __name__=='__main__': main()
