#!/usr/bin/env python3
"""Run one bounded stage and measure its complete subprocess wall time."""
import argparse,hashlib,json,subprocess,sys,time
from pathlib import Path

def main():
    p=argparse.ArgumentParser();p.add_argument('--receipt',required=True);p.add_argument('--timeout',type=float,default=45);p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args()
    if not a.command or a.command[0]!='--':p.error('provide -- followed by a Python worker and arguments')
    if a.timeout<=0:p.error('positive timeout required')
    receipt=Path(a.receipt)
    if receipt.exists():raise FileExistsError('receipt already exists')
    command=[sys.executable]+a.command[1:];started=time.monotonic()
    try:
        result=subprocess.run(command,text=True,capture_output=True,timeout=a.timeout)
        output={'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'status':'completed_process'}
    except subprocess.TimeoutExpired as e:
        output={'status':'process_timeout_last_committed_checkpoint_retained','returncode':None,'stdout':str(e.stdout),'stderr':str(e.stderr)}
    output.update({'command':command,'full_subprocess_wall_seconds':time.monotonic()-started,'timeout_seconds':a.timeout,
                   'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
    receipt.write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(output,indent=2))
    if output['returncode']!=0:raise SystemExit(2)

if __name__=='__main__':main()
