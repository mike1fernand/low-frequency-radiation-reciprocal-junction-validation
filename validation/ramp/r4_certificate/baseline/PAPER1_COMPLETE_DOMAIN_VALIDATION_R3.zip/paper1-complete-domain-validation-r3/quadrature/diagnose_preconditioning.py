#!/usr/bin/env python3
"""Finite-neighborhood diagnostic only; not an integral or runtime claim."""
import argparse,hashlib,json,time
from pathlib import Path
from flint import arb,acb,acb_mat,ctx
from arbitrary_tile_sharp import exact,endpoint_certificate,contour_legs
from source_moments import shifted_matrix

def inverse(M,precondition):
    if not precondition:return M.inv()
    # Midpoints are exact dyadics. P0 need not be an exact inverse of M0:
    # finiteness of (P0*M)^-1 suffices for M^-1=(P0*M)^-1*P0.
    M0=acb_mat([[acb(M[i,j].real.mid(),M[i,j].imag.mid()) for j in range(3)] for i in range(3)])
    P=M0.inv();P0=acb_mat([[acb(P[i,j].real.mid(),P[i,j].imag.mid()) for j in range(3)] for i in range(3)])
    return (P0*M).inv()*P0

def run(path):
    path=Path(path);data=json.loads(path.read_text());settings=data['settings'];ctx.prec=settings['bits']
    t0,_=endpoint_certificate(settings['bounds'],settings['chart']);legs=contour_legs(settings['mode'],settings['height'],t0)
    # Fixed first six pending boxes; no selection by diagnostic outcome.
    nodes=data['pending'][:6];records=[]
    for node in nodes:
        _,origin,delta=legs[node['leg']]
        bounds=[(exact(lo),exact(hi)) for lo,hi in node['bounds']]
        centers=[(a+b)/2 for a,b in bounds];halves=[(b-a)/2 for a,b in bounds]
        for axis in range(3):
            for mult in (2,4,8,16):
                xs=[acb(a.union(b)) for a,b in bounds];r=halves[axis]*mult
                xs[axis]=acb(centers[axis]+arb(0,r.abs_upper()),arb(0,r.abs_upper()))
                q,u,v=xs;M=shifted_matrix(origin+delta*q,u,v,settings['chart']);out={'node_id':node['id'],'axis':axis,'multiplier':mult}
                vals={}
                for kind,flag in [('raw',False),('preconditioned',True)]:
                    begin=time.monotonic()
                    try:
                        R=inverse(M,flag);finite=all(R[i,j].is_finite() for i in range(3) for j in range(3))
                        if finite:vals[kind]=R
                    except (ZeroDivisionError,ArithmeticError):finite=False
                    out[kind+'_finite']=finite;out[kind+'_seconds']=time.monotonic()-begin
                if len(vals)==2:out['all_entries_overlap']=all(vals['raw'][i,j].overlaps(vals['preconditioned'][i,j]) for i in range(3) for j in range(3))
                records.append(out)
    return {'status':'diagnostic_complete','input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'records':records,
            'raw_finite':sum(r['raw_finite'] for r in records),'preconditioned_finite':sum(r['preconditioned_finite'] for r in records),
            'gained_neighborhoods':sum(r['preconditioned_finite'] and not r['raw_finite'] for r in records),
            'lost_neighborhoods':sum(r['raw_finite'] and not r['preconditioned_finite'] for r in records),
            'all_common_finite_entries_overlap':all(r.get('all_entries_overlap',True) for r in records),
            'claim_limit':'Only finite inverse enclosures on selected pending neighborhoods; no integrated values, error-budget closure, or total-cost improvement.'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output',required=True);a=p.parse_args();out=run(a.input);Path(a.output).write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k!='records'})
