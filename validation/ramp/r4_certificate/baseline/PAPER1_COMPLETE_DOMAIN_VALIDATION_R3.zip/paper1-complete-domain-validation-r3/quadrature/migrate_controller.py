#!/usr/bin/env python3
"""Explicitly migrate a v1 checkpoint after controller-only corrections.

No integration results are changed. The previous complete producer is kept
in producer_v1; original checkpoint hash and leaf cutoff remain recorded.
"""
import argparse,hashlib,json
from pathlib import Path
from arbitrary_tile import audit_partition,source_hashes,atomic_json

def migrate(path):
    path=Path(path);raw=path.read_bytes();state=json.loads(raw)
    candidates=[]
    for old in sorted(Path(__file__).parent.glob('producer_v*')):
        hashes={name:hashlib.sha256((old/name).read_bytes()).hexdigest() for name in source_hashes()}
        if state['identity']['sources']==hashes:candidates.append((old,hashes))
    if len(candidates)!=1:raise ValueError('not an unambiguous preserved producer checkpoint')
    old,old_hashes=candidates[0]
    new_hashes=source_hashes()
    for name in ('source_moments.py','certified_tensor.py'):
        if old_hashes[name]!=new_hashes[name]:raise ValueError('migration is only authorized for unchanged mathematical primitives')
    audit_partition(state)
    if state['status']!='partial_checkpoint_no_tile_enclosure':raise ValueError('migration currently restricted to partial checkpoints')
    state.setdefault('controller_migrations',[]).append({'from_sources':old_hashes,'to_sources':new_hashes,'original_checkpoint_sha256':hashlib.sha256(raw).hexdigest(),
        'preserved_leaf_count':len(state['accepted']),'preserved_producer_directory':old.name,
        'reason':'Controller coverage/failure/resume corrections; mathematical primitives unchanged.'})
    state['identity']['sources']=new_hashes;atomic_json(path,state)
    return len(state['accepted'])

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('paths',nargs='+');a=p.parse_args()
    for path in a.paths:print(path,migrate(path),'leaves preserved')
