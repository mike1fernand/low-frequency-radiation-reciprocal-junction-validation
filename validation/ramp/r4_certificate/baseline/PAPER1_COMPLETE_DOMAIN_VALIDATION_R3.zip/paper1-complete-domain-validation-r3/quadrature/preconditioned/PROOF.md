# Preconditioning changes the enclosure algorithm, not the integrand

For one complex input box, let M(z)=D(z)-E be the holomorphic matrix in the
source-moment primitive. Form an exactly represented complex dyadic matrix
P0 by taking entrywise midpoints of an interval inverse of the entrywise
midpoint matrix M0. This construction only chooses a useful constant matrix.
Neither P0=M0^-1 nor P0=M(z)^-1 is assumed.

Compute the interval matrix B=P0*M and demand a finite interval inverse.
For every point z represented by the input box, this proves that P0*M(z) is
invertible. Since these are square matrices, both P0 and M(z) are invertible,
and the exact identity is

    M(z)^-1 = (P0*M(z))^-1 * P0.

The multiplication order matters; a noncommuting negative control tests it.
Interval multiplication and inversion enclose this entire formula. The
runtime asserts that each component of P0 is exact after midpoint extraction.
Failure to produce a finite inverse rejects that candidate.

P0 is fixed for the particular input box. Choosing it through midpoint
operations does not introduce a nonholomorphic physical integrand: the
returned ball bounds the original M(z)^-1, and M(z) remains holomorphic.
Existence of an inverse over the whole containing complex square certifies
the analytic neighborhood needed by the Cauchy argument.

For neighborhood balls, the implementation tries both the original direct
inverse and this preconditioned inverse, keeping a finite candidate with the
smaller maximum entry modulus. Each candidate independently encloses the same
true matrix inverse; this choice preserves validity. Balls with widths near
rounding precision retain a finite direct inverse to avoid paying for an
unnecessary midpoint factorization at every quadrature node. The width
threshold affects computation cost only, and does not enter an error bound.

No earlier accepted integral leaf is imported into the new producer. The
worker and source primitive are copied into this separate directory and
hashed in its own new checkpoint. The Gauss rule, sharpened Cauchy bound,
contour geometry, source projection, normalization, requested tolerance,
and physical chart are unchanged.
