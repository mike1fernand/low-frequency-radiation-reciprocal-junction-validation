#!/usr/bin/env python3
"""Exact-preconditioner and independent direct-inverse consistency checks."""
import argparse,hashlib,json
from pathlib import Path
from flint import arb,acb,acb_mat,ctx
from source_moments import shifted_matrix,exact_midpoint_matrix,preconditioned_inverse,certified_inverse

def run():
    ctx.prec=128;checks=[]
    for chart in (0,1,2):
        for t,u,v in [('0.9','0.2','0.7'),('0.8','0.8','0.1'),('1.2','0.3','0.9')]:
            M=shifted_matrix(acb(arb(t),-arb(1)/4),arb(u),arb(v),chart)
            P0=exact_midpoint_matrix(exact_midpoint_matrix(M).inv())
            checks.append({'name':f'exact_dyadic_preconditioner_chart{chart}_{t}','passed':all(P0[i,j].real.is_exact() and P0[i,j].imag.is_exact() for i in range(3) for j in range(3))})
            direct=M.inv();pre=preconditioned_inverse(M);chosen=certified_inverse(M)
            checks.append({'name':f'point_inverse_consistency_chart{chart}_{t}','passed':all(direct[i,j].overlaps(pre[i,j]) and direct[i,j].overlaps(chosen[i,j]) for i in range(3) for j in range(3))})
            product=M*pre
            checks.append({'name':f'point_inverse_identity_chart{chart}_{t}','passed':all(product[i,j].contains(1 if i==j else 0) for i in range(3) for j in range(3))})
    M=acb_mat([[2,1,0],[0,3,1],[1,0,4]]);P0=acb_mat([[1,1,0],[0,1,0],[0,0,1]])
    correct=(P0*M).inv()*P0;wrong=P0*(P0*M).inv();direct=M.inv()
    checks.append({'name':'noncommuting_identity_order','passed':all(correct[i,j].overlaps(direct[i,j]) for i in range(3) for j in range(3)) and any(not wrong[i,j].overlaps(direct[i,j]) for i in range(3) for j in range(3))})
    M=acb_mat([[1,0,0],[0,1,0],[0,0,0]])
    try:certified_inverse(M);blocked=False
    except (ArithmeticError,ZeroDivisionError):blocked=True
    checks.append({'name':'singular_matrix_is_rejected','passed':blocked})
    return {'status':'passed' if all(c['passed'] for c in checks) else 'failed','checks':checks,'sources':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__),Path(__file__).with_name('source_moments.py'))},'claim_limit':'Inverse algebra and pointwise consistency only; no full-domain integral claim.'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args();out=run();Path(a.output).write_text(json.dumps(out,indent=2)+'\n');print(out['status'],len(out['checks']),'checks')
    if out['status']!='passed':raise SystemExit(2)
