# Certified tensor Gauss rule with explicit moment residuals

This derivation concerns the numerical integration error only. The existing
contour, shell-count, normalization, and source-projection arguments remain
necessary to identify the resulting integral with the stated Green/qT moment.

Let I be normalized integration on [-1,1], and Q be the normalized positive
n-point Gauss–Legendre rule, n=3 or5. The exact nodes/weights are given by
radicals in `rule`; symbolic checks verify I(x^k)=Q(x^k) for every
0<=k<=2n-1. Every node has its exact negative partner with the same weight,
and the central node is zero. Hence I(x^k)=Q(x^k)=0 for every odd k, including
degrees beyond the rule's polynomial exactness. Ball arithmetic encloses
these exact constants; it does not redefine an asymmetric floating point rule.

For f holomorphic on a neighborhood of |z-c|<=rho, with |f(z)|<=M there,
write f(c+h*x)=sum_k a_k h^k x^k. Cauchy's estimate gives
|a_k|<=M/rho^k. The power series converges uniformly on the integration
interval because r=h/rho<1. Integration and the finite quadrature sum can
therefore be applied term by term.

Define d_k=|I(x^k)-Q(x^k)|. For k even,
d_k=|1/(k+1)-sum_i w_i x_i^k|. For each odd k, d_k=0 exactly.
Because the weights are positive, sum to1, and |x_i|<=1, both I and Q have
operator norm1 in the supremum norm. Thus d_k<=2 for all k. No sign of the
quadrature error is assumed.

Taking K=2n+20, an even integer, gives the rigorous bound

    |I f-Q f| <= M [sum_(k=2n,even)^K d_k*r^k
                         + 2*r^(K+2)/(1-r^2)].

Every retained d_k is evaluated outward with Arb; the remaining geometric
tail bounds all omitted even powers. `tail_factor` implements precisely
eleven retained even degrees, followed by this tail. The term after the
last multiplication is r^(2n+22), as required. The code does not infer the
tail from convergence or sample differences.

For a tensor product on a three-dimensional real box, telescope
I1 I2 I3 - Q1 Q2 Q3 into three differences. The other real parameters range
over their complete intervals when obtaining each analytic modulus M_j.
The normalized integration and quadrature operators on those parameters
have norm1. Therefore the three one-coordinate bounds sum; multiplication
by the real box volume gives the integral error. Complex error magnitude
E implies that adding [-E,E] to both real and imaginary quadrature components
is a valid rectangular enclosure.

The analytic disk in each coordinate is contained in the complex square
actually evaluated by the callback. Trigonometric functions are entire, and
the interval inverse must be finite on the entire evaluated square with
the other parameters in their complete real intervals. This establishes
holomorphy for the concrete source-projected resolvent callback. A successful
point inverse alone would not establish this condition.

The old bound 2*M*r^(2n)/(1-r) is mathematically valid but discards all
post-exactness moment information. The first retained residual is
approximately0.0228571 forGL3 and0.00146591 forGL5. Actual cost improvement
must be measured because the finite-neighborhood requirement can still
force subdivisions independently of the quadrature error.

The checkpoint controller preserves every accepted box and every pending
box. Exact rational bisections reconstruct the complete parameter partition.
Three contour legs are required forqT; four, including the regular exterior,
are required for the full Green integral. Only a queue with no pending boxes
can produce a complete tile enclosure. A tile's complete-area result is not
a complete angular-chart or Brillouin-zone result.
