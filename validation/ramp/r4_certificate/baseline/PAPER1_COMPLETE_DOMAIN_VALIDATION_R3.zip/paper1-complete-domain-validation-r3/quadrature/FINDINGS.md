# Integration findings and stopping decision

The exact-radical Gauss–Legendre 5 rule, a sharpened Cauchy remainder,
rigorous inverse preconditioning, and an arbitrary-tile checkpoint controller
are implemented and checked. These changes improve certified integration.
They do not yet establish the complete-domain matrix perturbation budgets or
an exact-lattice floor.

## Implemented mathematics and validation

The sharpened bound retains eleven actual even Gauss moment residuals and
bounds all later even terms geometrically. Its proof is in
`SHARP_CAUCHY_PROOF.md`. Exact symmetry makes every odd residual zero. The
implementation assumes neither a quadrature-error sign nor an error estimate
from empirical convergence. An independent referee reviewed the derivation,
including the first omitted degree, 2n+22.

`MANUFACTURED_CHECKS.json` records 30 checks of the exact-radical GL3/GL5 rule
and original Cauchy estimate. `SHARP_CHECKS.json` records 44 checks exercising
the actual sharpened rule, including symbolic polynomial exactness, nonzero
remainders, complex exact integrals, the first omitted tail index, and pole
rejection. The original and sharpened controller checks each record 10 checks.
Manufactured controller callbacks verify control flow, not physical values.
`preconditioned/INVERSE_CHECKS.json` records 29 checks of exact dyadic
preconditioners, inverse identities, agreement with direct inverses in all
three charts, multiplication order, and singular rejection.

## Completed qT tiles

These results use the second max-coordinate chart, height 1/4, 128-bit Arb,
GL5, and requested density tolerance 1/25000. Exact angular bounds, source
hashes, and the full accepted partition are stored in each checkpoint.
Loop time excludes checkpoint loading, auditing, sum rebuilding, and writing.

| Tile and inverse method | Accepted leaves | Integration-loop seconds | Certified maximum radius / angular area |
|---|---:|---:|---:|
| u,v in [0,1/32], direct | 47 | 0.9331 | 4.07395e-6 |
| u in [7/16,1/2], v in [0,1/32], direct | 608 | 12.1490 | 1.08243e-5 |
| u in [3/8,7/16], v in [5/8,11/16], preconditioned | 419 | 10.5590 | 8.77304e-6 |
| u,v in [31/32,1], preconditioned | 206 | 5.2075 | 3.77288e-6 |

All four complete tiles have per-area radii below the current sufficient
uniform matrix-budget allocation. This is feasibility evidence for these
tiles only. No complete-domain runtime or integral error is inferred.

The preconditioned ordinary and body-diagonal runs have measured whole-process
wall times of 11.3760 and 5.9351 seconds, respectively. Each started independently
and completed the whole tile; no earlier accepted leaf was imported.

## Diagnosed bottleneck and controlled comparisons

The earlier unpreconditioned ordinary attempt remains saved with 9,319 accepted
leaves after 210.0021 seconds of integration loops. The downward leg is complete;
119/512 of the horizontal parameter volume and the entire upward leg remain
pending. The earlier unpreconditioned body-diagonal attempt has 1,094 accepted
leaves after 25.0001 seconds; its downward leg is complete, 3427/4096 of its
horizontal volume and the whole upward leg remain. These fractions describe
parameter volume, not omitted-integral error.

The diagnostic fixed the first six pending ordinary boxes before examining
results. Across 72 coordinate/radius neighborhoods, direct interval inversion
was finite on 18, while exact-midpoint left preconditioning was finite on 42:
24 gains and no losses. All entries overlapped where both inverses were finite.
This identifies interval enclosure conditioning as a concrete issue in that
attempt. The diagnostic alone provides no integral or runtime claim.

For an exact dyadic matrix P0, finite inversion of P0*M proves
M^-1 = (P0*M)^-1*P0. P0 is chosen from midpoint calculations; it is never
assumed to be an exact inverse. The separate producer and proof are in
`preconditioned/`. Its successful complete ordinary/body integrations directly
test the resulting improvement at the same physical parameters and requested
tolerances as the earlier attempts. The earlier ordinary 210-second figure
is a partial-run time, so it is not a full-run speedup denominator.

Two files compare identical, completely covered parameter subregions:

* `COMMON_REGION_COMPARISON.json`: the original versus sharpened Cauchy bound
  takes 728 versus 267 accepted leaves for the whole downward leg, and 2,240
  versus 482 for the first quarter of the horizontal leg.
* `PRECONDITIONED_COMMON_REGION_COMPARISON.json`: direct versus preconditioned
  inversion with the sharpened bound takes 267 versus 53 leaves for the
  downward leg, and 482 versus 32 for the first horizontal quarter.

All 17 complex integral enclosures overlap in each comparison, and each improved
method has a smaller maximum rectangle radius. Exact rational volume within
the audited partition verifies complete coverage of the compared regions.
Accepted-leaf comparisons exclude failed split attempts; they are not runtime
or full-domain cost comparisons.

Checkpoint overhead was also measured. Unpreconditioned ordinary stages 5–6
used 25-second loops but took 35.8429 and 38.6409 seconds as whole processes.
Stages 7–9 used 20-second loops and took 37.0951, 35.8360, and 37.5830 seconds.
Earlier whole-process times were not independently measured and are not
reconstructed. The wrapper enforces a 45-second process timeout; incomplete
writes do not replace the prior committed checkpoint.

## Corrections and next decision

Confirmed controller issues were corrected before continuation. Maximum-depth
failures now save their pending partition; completed resumes recompute their
moments; required contour-leg counts derive from the mode so Green's exterior
cannot disappear; and endpoint certificates are recomputed on resume.
Earlier complete producers are retained in `producer_v1` and `producer_v2`.
Migrated partial checkpoints record original hashes, source hashes, preserved
leaf counts, and the reason. The controller migration helper refuses changes
to mathematical primitives. The preconditioned variant has entirely new data.

The next campaign should use the validated preconditioner, allocate the actual
remaining moment error budget nonuniformly, and benchmark a compact incremental
checkpoint format. Preconditioning resolved the measured ordinary/body
bottleneck. Its performance on the untested domain remains unmeasured. Changes
to error allocation must be explicit and preserve the identity and provenance
of accepted contributions. Nonuniform allocation and the storage redesign are
not implemented or validated here.

The physical source-moment formula is unchanged from R2; its inverse enclosure
algorithm is strengthened in the separate preconditioned variant. This work
does not change the paper, selected cached matrices, numerical coefficient,
or fixed-matrix floor. The integration proof belongs in validation material
unless complete-domain budgets justify a new paper claim.
