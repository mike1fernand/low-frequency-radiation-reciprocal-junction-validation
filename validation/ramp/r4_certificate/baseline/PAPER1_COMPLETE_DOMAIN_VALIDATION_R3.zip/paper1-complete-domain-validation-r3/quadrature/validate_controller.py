#!/usr/bin/env python3
"""Controller negative tests; manufactured callback does not test physics."""
import argparse,copy,json,tempfile
from pathlib import Path
from flint import acb
import arbitrary_tile as tile

def run():
    checks=[]
    settings={'bounds':['3/8','7/16','5/8','11/16'],'chart':1,'mode':'qt','height':'1/4','orders':[5,5,5],'density_tolerance':'1/25000','bits':128}
    with tempfile.TemporaryDirectory() as directory:
        dest=Path(directory)/'check.json'
        state=tile.integrate_stage(settings,dest,.001)
        checks.append({'name':'timeout_saves_exact_complete_partition','passed':dest.exists() and state['pending'] and tile.audit_partition(state)>0})
        original=tile.moment_values
        try:
            tile.moment_values=lambda t,u,v,chart:[acb(1)]*17
            state=tile.integrate_stage(settings,dest,5)
            checks.append({'name':'manufactured_resume_completes_and_aggregates','passed':state['status']=='rigorous_complete_tile_enclosure' and not state['pending']})
            state=tile.integrate_stage(settings,dest,1)
            checks.append({'name':'completed_resume_recomputes_aggregate','passed':state['status']=='rigorous_complete_tile_enclosure'})
            for label,change in (
                ('completed_with_pending',lambda x:x['pending'].append(copy.deepcopy(x['accepted'][0]['node']))),
                ('wrong_aggregate',lambda x:x['moments'][0]['upper'].__setitem__('mantissa','777777777777777777777777777777777')),
                ('missing_leaf',lambda x:x['accepted'].pop()),
                ('changed_endpoint',lambda x:x['endpoint_certificate'].__setitem__('kind','wrong')),
                ('source_mismatch',lambda x:x['identity']['sources'].__setitem__('source_moments.py','wrong'))):
                broken=copy.deepcopy(state);change(broken);dest.write_text(json.dumps(broken))
                try:tile.integrate_stage(settings,dest,1);rejected=False
                except (ValueError,KeyError):rejected=True
                checks.append({'name':'reject_'+label,'passed':rejected})
        finally:tile.moment_values=original
        dest.unlink();hard=copy.deepcopy(settings);hard['bounds']=['0','1','0','1'];hard['max_depth']=0
        blocked=tile.integrate_stage(hard,dest,5)
        checks.append({'name':'hard_failure_persists_pending_partition','passed':dest.exists() and blocked['status']=='blocked_checkpoint_no_tile_enclosure' and len(blocked['pending'])==3 and tile.audit_partition(blocked)==3})
        fabricated=copy.deepcopy(blocked);fabricated['settings']['mode']='green'
        try:tile.audit_partition(fabricated);rejected=False
        except ValueError:rejected=True
        checks.append({'name':'reject_missing_green_exterior_with_decreased_saved_leg_count','passed':rejected})
    return {'status':'passed' if all(c['passed'] for c in checks) else 'failed','checks':checks,'claim_limit':'Controller tests include manufactured constant callback; these do not provide physical moment values.'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args();out=run();Path(a.output).write_text(json.dumps(out,indent=2)+'\n');print(out)
    if out['status']!='passed':raise SystemExit(2)
