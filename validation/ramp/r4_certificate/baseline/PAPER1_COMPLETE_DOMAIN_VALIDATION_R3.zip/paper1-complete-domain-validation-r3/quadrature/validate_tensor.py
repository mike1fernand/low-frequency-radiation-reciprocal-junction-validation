#!/usr/bin/env python3
"""Exact symbolic rule checks and nontrivial manufactured enclosures."""
import argparse, hashlib, json
from pathlib import Path
import sympy as sp
from flint import arb, acb, ctx
from certified_tensor import rule, gauss_box, NeighborhoodFailure

def run():
    ctx.prec=128;checks=[]
    for n in (3,5):
        if n==3:
            r=sp.sqrt(sp.Rational(3,5));xx=[-r,0,r];ww=[sp.Rational(5,18),sp.Rational(4,9),sp.Rational(5,18)]
        else:
            r=sp.sqrt(sp.Rational(10,7));a=sp.sqrt(5-2*r)/3;b=sp.sqrt(5+2*r)/3
            wi=(322+13*sp.sqrt(70))/1800;wo=(322-13*sp.sqrt(70))/1800
            xx=[-b,-a,0,a,b];ww=[wo,wi,sp.Rational(64,225),wi,wo]
        nodes,weights=rule(n)
        checks.append({'name':f'GL{n}_positive_weights_and_interior_nodes','passed':all(w>0 for w in weights) and all(abs(x)<1 for x in nodes)})
        for degree in range(2*n):
            expected=sp.Rational(0) if degree%2 else sp.Rational(1,degree+1)
            residual=sp.simplify(sum(w*x**degree for x,w in zip(xx,ww))-expected)
            ball_expected=arb(0) if degree%2 else arb(1)/(degree+1)
            checks.append({'name':f'GL{n}_exact_degree_{degree}', 'passed':bool(residual==0 and sum(w*x**degree for x,w in zip(nodes,weights)).contains(ball_expected))})
    bounds=[(arb(-1),arb(1))]*3
    for orders in ((3,3,3),(5,5,5),(5,3,5)):
        cases=[('rational',lambda x,y,z:[1/((5-x)*(6-y)*(7-z))],(arb(6)/4).log()*(arb(7)/5).log()*(arb(8)/6).log()),
               ('degree10_nonzero_remainder',lambda x,y,z:[x**10+y**10+z**10],arb(24)/11),
               ('complex_entire',lambda x,y,z:[(x+y+z).exp()*acb(1,2)],(arb(1).exp()-arb(-1).exp())**3*acb(1,2))]
        for name,callback,target in cases:
            vals,meta=gauss_box(callback,bounds,orders,(2,3))
            checks.append({'name':str(orders)+'_'+name,'passed':vals[0].contains(target),'metadata':meta})
    try:
        gauss_box(lambda x,y,z:[1/(x-acb(0,arb(1)/10))],bounds)
        blocked=False
    except NeighborhoodFailure:blocked=True
    checks.append({'name':'reject_pole_inside_analytic_disk','passed':blocked})
    # Exact power x^10 ensures an incorrect "degree9 implies zero remainder"
    # substitution would fail on the quadrature sum itself.
    nodes,weights=rule(5)
    checks.append({'name':'negative_test_GL5_degree10_not_exact','passed':not sum(w*x**10 for x,w in zip(nodes,weights)).overlaps(arb(1)/11)})
    h=arb(1)/100
    vals,meta=gauss_box(lambda x,y,z:[1/((5-x)*(6-y)*(7-z))],[(-h,h)]*3,(5,5,5),(4,8,16))
    target=arb(1)
    for c in (5,6,7):target*=((c+h)/(c-h)).log()
    checks.append({'name':'narrow_tight_rational','passed':vals[0].contains(target) and vals[0].real.rad()<arb('1e-16')})
    return {'status':'passed' if all(c['passed'] for c in checks) else 'failed','checks':checks,'precision_bits':ctx.prec,
            'sources':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__),Path(__file__).with_name('certified_tensor.py'))}}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args();result=run()
    Path(a.output).write_text(json.dumps(result,indent=2)+'\n');print(result['status'],len(result['checks']),'checks')
    if result['status']!='passed':raise SystemExit(2)
