#!/usr/bin/env python3
"""Validate sharpened Cauchy coefficients and genuinely inexact integrals."""
import argparse,hashlib,json
from pathlib import Path
from flint import arb,acb,ctx
import certified_tensor_sharp as sharp
import validate_tensor as ordinary_validation

def run():
    ctx.prec=128
    # Reuse the same independent symbolic/manufactured test suite with the
    # sharpened callback bound. This changes no expected targets.
    ordinary_validation.gauss_box=sharp.gauss_box
    ordinary_validation.NeighborhoodFailure=sharp.NeighborhoodFailure
    ordinary_validation.rule=sharp.rule
    out=ordinary_validation.run();checks=out['checks']
    for n in (3,5):
        r=arb(1)/2
        finite=sum(d*r**(2*n+2*j) for j,d in enumerate(sharp.even_residuals(n,ctx.prec)))
        remainder=sharp.tail_factor(n,r)-finite
        expected_tail=2*r**(2*n+22)/(1-r*r)
        wrong_next_tail=2*r**(2*n+24)/(1-r*r)
        checks.append({'name':f'GL{n}_tail_index_and_nonzero_geometric_remainder',
                       'passed':remainder.contains(expected_tail) and not remainder.overlaps(wrong_next_tail)})
        for mult in (2,4,8,16):
            r=arb(1)/mult;factor=sharp.tail_factor(n,r);old=2*r**(2*n)/(1-r)
            checks.append({'name':f'GL{n}_r1over{mult}_factor_tighter','passed':factor>0 and factor<old,
                           'improvement_factor_diagnostic':float(old/factor)})
        # Tail starts beyond all eleven explicitly retained even powers.
        degree=2*n+22
        vals,meta=sharp.gauss_box(lambda x,y,z:[x**degree+y**degree+z**degree],[(arb(-1),arb(1))]*3,(n,n,n),(2,))
        checks.append({'name':f'GL{n}_unretained_even_power_tail','passed':vals[0].contains(arb(24)/(degree+1))})
        vals,meta=sharp.gauss_box(lambda x,y,z:[acb(1,2)/(acb(3,1)-x)/(4-y)/(5-z)],[(arb(-1),arb(1))]*3,(n,n,n),(2,))
        expected=acb(1,2)*((acb(4,1))/(acb(2,1))).log()*(arb(5)/3).log()*(arb(6)/4).log()
        checks.append({'name':f'GL{n}_complex_rational_exact_integral','passed':vals[0].contains(expected)})
    out['status']='passed' if all(c['passed'] for c in checks) else 'failed'
    out['sources']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__),Path(__file__).with_name('certified_tensor_sharp.py'),Path(__file__).with_name('validate_tensor.py'))}
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);a=p.parse_args();out=run();Path(a.output).write_text(json.dumps(out,indent=2)+'\n');print(out['status'],len(out['checks']),'checks')
    if out['status']!='passed':raise SystemExit(2)
