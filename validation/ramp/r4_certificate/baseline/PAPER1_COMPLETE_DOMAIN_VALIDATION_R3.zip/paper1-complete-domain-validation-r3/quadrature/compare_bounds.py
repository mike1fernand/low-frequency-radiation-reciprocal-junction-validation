#!/usr/bin/env python3
"""Compare old/sharp methods only on identical fully covered subregions."""
import argparse,hashlib,json
from fractions import Fraction
from pathlib import Path
from flint import acb,ctx
from arbitrary_tile import audit_partition,decode_ball

def subregion(state,leg,qhi):
    audit_partition(state);ctx.prec=state['settings']['bits']
    qhi=Fraction(qhi)
    selected=[]
    for leaf in state['accepted']:
        node=leaf['node'];lo,hi=map(Fraction,node['bounds'][0])
        if node['leg']==leg and lo<qhi:
            if hi>qhi:raise ValueError('selected boundary cuts an accepted leaf')
            selected.append(leaf)
    for node in state['pending']:
        if node['leg']==leg and Fraction(node['bounds'][0][0])<qhi:raise ValueError('subregion still has pending boxes')
    volume=sum((Fraction(v['node']['bounds'][0][1])-Fraction(v['node']['bounds'][0][0]))*(Fraction(v['node']['bounds'][1][1])-Fraction(v['node']['bounds'][1][0]))*(Fraction(v['node']['bounds'][2][1])-Fraction(v['node']['bounds'][2][0])) for v in selected)
    a,b,c,d=map(Fraction,state['settings']['bounds'])
    if volume!=qhi*(b-a)*(d-c):raise ValueError('subregion volume mismatch')
    total=[acb(0) for _ in range(17)]
    for leaf in selected:
        for m,v in enumerate(leaf['moments']):total[m]+=decode_ball(v)
    return {'accepted_leaf_count':len(selected),'successful_leaf_callback_calls':sum(v['metadata']['calls'] for v in selected),'parameter_volume_exact':str(volume),'maximum_complex_rectangle_radius_diagnostic':max(max(float(x.real.rad()),float(x.imag.rad())) for x in total)},total

def run(old_path,new_path):
    old=json.loads(Path(old_path).read_text());new=json.loads(Path(new_path).read_text())
    if old['settings']!=new['settings'] or old['endpoint_certificate']!=new['endpoint_certificate']:raise ValueError('comparison changes settings or contour')
    result=[]
    for leg,qhi,label in ((0,'1','complete_down_leg'),(1,'1/4','first_quarter_across_leg')):
        a,av=subregion(old,leg,qhi);b,bv=subregion(new,leg,qhi)
        result.append({'region':label,'old':a,'sharp':b,'accepted_leaf_reduction_factor':a['accepted_leaf_count']/b['accepted_leaf_count'],'all17_complex_enclosures_overlap':all(x.overlaps(y) for x,y in zip(av,bv))})
    return {'status':'passed' if all(r['all17_complex_enclosures_overlap'] for r in result) else 'failed',
            'comparisons':result,'input_sha256':{str(p):hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in (old_path,new_path)},
            'claim_limit':'These fully covered parameter subregions do not give complete qT moments. Accepted leaf counts exclude failed subdivision attempts; no runtime or global-cost extrapolation.'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--old',required=True);p.add_argument('--sharp',required=True);p.add_argument('--output',required=True);a=p.parse_args();out=run(a.old,a.sharp);Path(a.output).write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
    if out['status']!='passed':raise SystemExit(2)
