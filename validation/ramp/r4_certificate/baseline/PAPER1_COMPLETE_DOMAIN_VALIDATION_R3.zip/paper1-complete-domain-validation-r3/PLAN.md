# Paper 1: complete-domain continuation

## Objective and authority

Advance the optional exact-lattice certification from the recovered R2 pilots to a complete-domain error ledger and tested execution strategy. Preserve the manuscript, selected numerical values, and fixed-input certificate unless a confirmed defect requires correction. The recovered Extension 1 repository controls the model, source, cache selection and claim ceiling. The R2 archive controls the existing contour derivation and pilot evidence. Their verified archive identities are in `RECOVERED_INPUTS.json`.

The existing paper does not require the optional exact-lattice strengthening. A successful finite-domain pilot, ordinary quadrature agreement, or a finite but wide global enclosure cannot establish that strengthening. Deterministic checks do not imply a calibrated 95% confidence level.

## Sequence and correction gates

1. **Recover and identify.** Verify archive identities, identify the exact selected matrices and current claim boundaries, rebuild the pinned interval environment. Check before interpreting inherited results; do not repeat the completed N160 campaign.
2. **Close the accounting specification.** Independently reconstruct all 12 by 12 matrix occurrences from 17 moments. Include distance to the actual dyadic selected matrices, all source signs, each chart and the Green exterior. Specify exact sufficient operator-norm tests at 0.020 and 0.005 after the 1.69 scaling. Discharge exact Q positive semidefiniteness from its actual lower-pair spectral measure, including ties; midpoint eigenvalues are not that proof. Check algebra and deliberately altered inputs before using the budget.
3. **Ensure no domain can disappear.** Build an exact rational cover of all three angular squares. Develop an analytic finite fallback for every unresolved region, if provable, so the ledger distinguishes numerical refinement from domain coverage. Check gaps, overlaps, duplicate evidence, incompatible parameters and missing output with rejection tests. Never substitute zero for missing work.
4. **Measure the actual bottleneck.** Improve the certified quadrature only where error/cost evidence warrants it. Test manufactured analytic integrals and invalid neighborhoods before physical runs. Use bounded stages and bind source/settings to outputs. Include difficult neighborhoods and all chart orientations, not just the previous four x-chart cells. Probe relevant tolerance levels, keeping timing projections explicitly empirical.
5. **Choose and implement the next computation from evidence.** If complete coverage and a practical allocation support a useful global campaign, run it in resumable tiles. Otherwise implement the complete conservative bound and identify the measured unresolved width/cost, with a reproducible allocation for the next campaign. Do not call an unexecuted campaign completed. Check after each setting change and aggregate; preserve successful stages and avoid blind retries.
6. **Review and deliver.** Conduct an independent load-bearing review, then an open skeptical-referee pass, including whether the new work contributes to the paper. Correct only confirmed issues. Recheck affected dependencies, verify the exported package and report performed/unperformed work distinctly. Keep technical development in validation material unless a new result justifies paper length.

## Plan review criteria

Before relying on implementation, review whether (a) the budget tests the actual selected matrices rather than nearby reconstructed ones, (b) every integration component is represented, (c) timing pilots are not being treated as rigorous global runtime bounds, (d) a timeout preserves useful evidence without being mislabeled success, and (e) new quadrature formulas have a proof for the order actually used. Revisit the plan once after this review and once after the first measured results. Further checks must address a concrete material risk.

## Explicit stopping rule

The stronger theorem is complete only when the whole-domain enclosures satisfy both selected-matrix operator budgets and the existing conditional bridge is rechecked. If the tested implementation cannot reach them within a practical bounded campaign, finish the reproducible accounting and diagnostic result, state the exact outstanding calculation, and retain the current paper's valid claim ceiling. Do not invent results, silently loosen tolerances, or repeat unchanged failed stages.

## First independent review and resulting improvements

The first review found an omitted explicit positive-semidefinite premise; it is now included in stage 2. The spectral definition supplies the proof without adding an unnecessary numerical PSD test. Each numerical stage has a 30-second working cap (a single in-flight interval evaluation may finish beyond it); it must save all validated work and unfinished domains. For the initial campaign, at most 24 such probe stages are allocated before an accuracy/cost decision. Extra stages require a concrete improvement or a forecast supported by those measurements, rather than repetition. Resource caps limit this execution, not the validity of the mathematical method or a future campaign. Source symmetry may reduce work only after algebraic verification and explicit complete-domain accounting.

## Second plan check after implementation

The actual selected-center displacement is material. Four inexpensive, complete-domain floating contour calculations were therefore added before committing to a large certification run. Their candidate centers were passed through exact matrix accounting to produce a conditional allocation that includes displacement. Mesh and contour agreement remain diagnostics; the plan does not promote them to integration bounds.

The first GL5 probes showed that a crude Cauchy tail wasted known Gauss cancellations. A separately proved and tested remainder retains eleven exact even-moment residuals and bounds the remaining infinite tail. Old and new producers are separate, and comparison uses identical completed subregions rather than incomparable partial tiles. Complex-neighborhood finiteness still forces substantial work. This improvement was checked with manufactured analytic integrals, source/endpoint checks and whole-cell physical runs.

Measured checkpoint overhead required distinguishing the integration-loop limit from whole-process time. A bounded subprocess wrapper records both. Later slow stages use a 20-second integration budget to leave room for growing checkpoint work; prior atomic outputs survive a hard external timeout.

The ledger is now complete even when refinement is absent, through proved analytic fallback bounds. The meaning of failure is explicit: a sufficient norm upper bound has not met its budget; this does not prove a physical discrepancy. No manuscript length is added for this development.

## Concrete next-campaign design, if the optional theorem is pursued

1. Start from the exact candidate-center allocations in `matrix/numerical/ASSESSMENT.json`, the already completed cells and the ledger's explicit fallback rectangles. Do not reset completed work or assume the remaining rectangles are uniform in cost.
2. For each observable and each moment, record the sum of outward regional radii and the displacement of the summed center from the actual target. Use `matrix_budget.envelope` and its exact row/column or Frobenius bounds to evaluate the real constraint. For g, use complex modulus rather than adding only real-part errors.
3. Extend the integrator to accept a vector of 17 regional error allocations. Choose the next subdivision by the observed reduction in the relevant matrix bound per measured wall-time cost; retaining a common scalar density everywhere is a baseline, not an optimum. Test the allocation arithmetic and a deliberately underallocated repeated moment before physical execution.
4. On the measured slow ordinary/diagonal regions, compare a small number of justified settings or improved inverse-neighborhood bounds on the same domains. Require valid remainders and actual complete-region error reduction before adopting an improvement. Checkpoint compaction must reproduce the exact accepted sum and split-tree cover; it cannot drop pending boxes.
5. Only after these measurements support a campaign budget, expand the explicit rational cover. Reuse only the proved y/z symmetry, keep the Green exterior, and replace or intersect fallback bounds rather than adding duplicate contributions. Each stage saves source/settings-bound progress and a wall-time receipt.
6. Accept the stronger result only if the complete selected-matrix bounds pass both original thresholds, exact Q positivity remains applicable, and the existing conditional bridge is replayed. Otherwise report the achieved enclosure and the dominant remaining region/moment. Do not weaken a threshold or revise the physical preparation to force agreement.

The present continuation implements the accounting and measurement prerequisites for this design. The full adaptive campaign and its resulting exact-lattice guarantee remain unperformed.

## Final measured improvement and revised execution choice

The last two allocated probes tested an exact-dyadic left preconditioner after a direct interval-neighborhood diagnostic found a concrete source of overestimation. Its matrix identity was checked independently on points and wide complex balls. Separate new producers then completed the previously difficult ordinary and body-diagonal qT cells in 11.376 and 5.935 seconds of full subprocess wall time. The old ordinary run was still partial after 210.002 integration-loop seconds. No prior accepted leaves were silently transferred.

This changes the next-step choice: use the validated preconditioner for a staged global campaign, rather than continue the old slow implementation or attribute its cost to physical singularities. The exact source, contour, remainder and error budgets remain unchanged. The global ledger includes the new complete cells and their proved y/z copies; all other regions retain analytic fallback. Those complete-domain widths still fail the target budgets. The global campaign and optional theorem are not reported as completed.
