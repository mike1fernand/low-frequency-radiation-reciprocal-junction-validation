# Paper 1 continuation R3: implemented result

The remaining problem is now specified more precisely and supported by executable whole-domain accounting. No new error in Paper 1's Hamiltonian, selected kernels, physical observable or existing claim boundary was established. The optional exact-lattice floor is still unproved: the current complete enclosure is too wide. The existing fixed-input floor and approximately 12.6% physical headline remain unchanged.

This continuation implemented the reviewed plan, rather than repeating the R2 pilots. It recovered the exact selected matrices, included every matrix occurrence and center displacement, proved finite bounds for every unrefined integration region, improved the certified quadrature, ran new complete-domain numerical diagnostics and bounded certified probes, and corrected confirmed validation defects. The new material belongs in the validation package; it does not presently justify a longer main paper.

## 1. What is established

**Actual target matrices.** The controlling selection is `basis_invariant_n192_sobol23_m256_v1`. The existing certificate's stored floor is approximately 0.1080401795285; its conditional exact-lattice conclusion is approximately 0.1037986667791. The latter still requires the original scaled operator-error budgets, 0.020 for g and 0.005 for Q. Recovery reproduces the actual float64 addition of the two saved qT branch matrices, then treats those resulting numbers as exact dyadic targets. Replacing that addition by a different exact sum would change the target.

The 17 moments populate 132 structural matrix entries, while the comparison checks all 144 actual cache entries. Signed cross moments and exact structural zeros are retained. Each row has eleven potentially nonzero structural entries. This modestly improves uniform sufficient allocations relative to the earlier conservative twelve-entry rule. The cache's small symmetry residuals remain included; they are not integration-error estimates.

**Complete-domain fallback and positivity.** The new proof supplies finite outward bounds for all 17 moments over any measurable subset of each angular square. It includes the entire Green contour and regular exterior. Every region not covered by a completed refined cell receives this fallback; no missing region is assigned zero. Exact rational geometry checks all three charts, overlaps and omissions.

The proof also establishes exact physical Q positive semidefiniteness from its full source-projected spectral residues, including tied modes. This discharges a previously implicit premise of the perturbation bridge. It does not depend on eigenvalues of an approximate midpoint matrix.

The physical y/z symmetry permits chart 1 to be reused for chart 2, with both physical contributions retained. It also permits u/v reflection within chart 0. It does not permit an x/source-axis permutation. Algebraic verification precedes the finite numerical comparisons.

**Better certified integration.** The new rule retains the actual even-power Gauss moment residuals in its Cauchy remainder, instead of replacing every residual by the same worst-case constant. The remaining infinite tail is still explicitly bounded. This is a mathematical tightening with the same source, contour and observable. It does not assume ordinary quadrature convergence. The final probes identified interval-matrix overestimation as a major additional bottleneck. An exact-dyadic left preconditioner substantially reduced it on two previously difficult cells. The identity M^{-1}=(P0 M)^{-1} P0 is enclosed with interval arithmetic; the approximate midpoint inverse is used only to choose P0 and is never treated as exact.

All completed new cells cover positive angular area and every required radial contour component. Unfinished checkpoints retain accepted and pending parameter boxes separately. Only completed cells enter the physical ledger.

## 2. Numerical diagnostics and a realistic error allocation

Four ordinary complete-domain contour runs used angular/radial orders 12/48, 20/80 and 32/128, plus a contour-height change. The largest moment changes from 20/80 to 32/128 were approximately 2.48e-15 for g and 1.30e-15 for Q. The source primitive was compared with Arb and the Bloch symbol with an independent nine-bond sum. These checks support implementation consistency. They do not bound the quadrature error.

The ordinary numerical estimate of scaled operator displacement from the selected cache is 0.00127925 for g and 0.000818200 for Q. Thus ignoring center displacement would materially overallocate the available error, especially for Q.

More usefully, exact rational matrix arithmetic gives the following conditional allocation around the recorded candidate centers:

| Quantity | Rigorous scaled candidate-center-to-cache upper bound | Remaining complete-moment modulus radius | Equivalent radius density across three chart areas |
|---|---:|---:|---:|
| g | 0.00185694624643 | 0.000975957705948 | 0.000325319235316 |
| Q | 0.000827651841781 | 0.000224440460366 | 0.000074813486788 |

The rigorous statement here is an implication: if every true complete moment lies within the assigned radius of its recorded candidate center, the corresponding operator budget passes. True-integral containment within those radii has not been proved. The exact rational values in `matrix/numerical/ASSESSMENT.json` control over the displayed decimals.

The certified probes target density 1/25000 for the real Q moments and 1/5000 separately for the real and imaginary g components. For planning, the latter requires the complex-modulus conversion by sqrt(2); that target remains below the available conditional modulus allocation. Final acceptance uses actual interval-to-cache matrix bounds, not tolerance settings alone.

## 3. Executed certified probes and cost decision

Completed results include chart-1 qT axis, coordinate-plane, ordinary and body-diagonal cells, plus chart-1 Green axis and chart-0 Green ordinary cells. The Green results include the real exterior. Exact y/z symmetry makes completed chart-1 cells valid contributions to both charts 1 and 2. The complete ledger retains the verified R2 cells where no replacement was made.

| New complete cell | Maximum achieved radius per unit parameter area | Integration-loop time |
|---|---:|---:|
| qT, chart 1, axis | 4.07395e-6 | 0.933 s |
| qT, chart 1, coordinate plane | 1.08243e-5 | 12.149 s |
| qT, chart 1, ordinary, preconditioned | 8.77304e-6 | 10.559 s |
| qT, chart 1, body diagonal, preconditioned | 3.77288e-6 | 5.208 s |
| Green, chart 1, axis, maximum component radius | 1.28019e-5 | 1.618 s |
| Green, chart 0, ordinary, maximum component radius | 2.43357e-5 | 86.436 s across four stages |

These are local achievements, not a full-domain error certificate. The earlier unpreconditioned chart-1 ordinary qT run remains partial after nine bounded stages totaling about 210.002 seconds, with 9,319 accepted leaves. A new run with the independently validated preconditioner completed the identical whole cell in 10.559 integration seconds, 11.376 seconds for the full subprocess, and 419 leaves. The earlier body-diagonal attempt also remained partial; the preconditioned whole-cell run completed in 5.208 integration seconds and 5.935 seconds overall. Old leaves were not silently reused in either new producer. These comparisons identify an interval-enclosure issue, not a change to the physics or a missing source term. The old partial checkpoints remain available as provenance, but do not enter the completed-cell ledger.

The improved remainder reduces leaf count on directly comparable completed regions: 728 to 267 on the ordinary qT downward leg, and 2240 to 482 on the first quarter of its horizontal leg. All 17 resulting enclosures overlap and the new radii are smaller. Those are measured reductions for those same regions, not a global speedup claim.

Costs vary substantially with geometry. The saved `stages.seconds` measures the integration loop only. One later ordinary stage used 25.001 seconds in that loop but 35.843 seconds for the full subprocess including checkpoint work. Neither easy-cell timing nor theoretical remainder-constant improvement supplies a reliable whole-domain runtime estimate. `quadrature/run_stage.py` records separately bounded full-process times.

**Updated decision after the final improvement:** the validated preconditioner is now the preferred starting point for the next campaign. The earlier ordinary/diagonal bottleneck no longer justifies continuing unchanged slow runs or assuming those cells are intrinsically prohibitive. The method now succeeds on all four tested qT geometries. A staged complete-domain campaign is technically supported; its global allocation and measured wall-time budget still need to be established, especially for the remaining Green regions. No full-domain runtime estimate or final operator bound follows from these local successes. The existing paper can retain its present scoped claim while that optional stronger theorem is completed.

## 4. Confirmed issues corrected

- Matrix-input parsing could silently omit imaginary target displacement when given a malformed one-component entry. It now requires exactly two components; missing and extra components are rejected.
- The new checkpoint validator initially trusted a saved contour-leg count. A deliberately incomplete Green state could therefore omit the exterior. Leg count is now derived from the observable, and omission is rejected.
- Complete status, endpoint certificates, aggregates and hard-failure persistence needed stronger checks. Complete results now require no pending boxes, exact split-tree coverage and recomputed totals; endpoints are rechecked, and hard failures preserve the pending domain and previous accepted work.
- The direct ledger adapter now performs the same relevant endpoint and producer checks, including the separate sharpened-rule producer.

The exported replay runner was also corrected to persist a failed status after post-run comparison failures and to compare the new numerical diagnostic with its saved baseline. Four manufactured runner controls confirm those reporting paths; they are not physical simulations.

The first defects were confirmed by reproductions before correction. They were validation-input/controller defects; no established physical output was shown wrong. Repairs were checked at their affected dependencies, and old producers were retained where existing checkpoints had to be migrated. The new mathematical remainder is a separate producer, so its calculations are not silently mixed with earlier ones.

## 5. Referee assessment and next work

For the paper as currently worded, a full exact-lattice floor is optional. It would strengthen the lower-bound claim, but it is not necessary to rescue a claim already explicitly restricted to the selected finite matrices. No new main-text caveats or development history are warranted. Keep the existing concise scope statements and put proof, uncertainty accounting and reproduction details here.

If pursuing the stronger theorem, the next implementation should allocate error by moment and region using the actual row/column occurrence weights and candidate-center displacement; use the now-validated preconditioned inverse; measure region-by-region progress at those allocations; and reduce checkpoint overhead where material. Validate each algorithmic change on manufactured analytic integrals, then on identical physical regions before expanding coverage. A useful next campaign must retain every chart and the Green exterior, and culminate in both actual operator budgets and a replay of the conditional bridge. A failed sufficient allocation should trigger a diagnosed refinement, not a changed tolerance presented as success.

The retained supplied-paper assessments support complete root accounting, full tied eigenspaces, source/resolvent symmetry and preservation of the actual time-domain readout. They do not supply Paper 1's missing integral bounds. This continuation used those preserved assessments; it did not newly reread or rerun the primary donor manuscripts. The new fallback and remainder results were derived from Paper 1's equations and the stated quadrature rule.

## 6. Unresolved matters and unperformed verifications

1. Tight complete-domain g and Q enclosures remain unresolved. The full-domain ledger has proved coverage, but its fallback widths do not pass the operator budgets. They are conservative certification bounds, not physical error estimates or new error bars on the 12.6% headline.

   The refined parameter areas are 1/64 for g and 15/512 for Q, out of total area 3 across the three chart squares. Every remaining region has a proved fallback bound. These areas are integration parameters, not solid angles or percentages of physical error.
2. The candidate-center allocations remain conditional on actual integral containment. Numerical order and contour agreement do not resolve this premise.
3. Complete-domain cost and optimal nonuniform allocation remain open. The ordinary/diagonal qT bottleneck was resolved locally; coverage and cost of all remaining regions, including the preconditioned Green campaign, were not measured.
4. No exact finite-window/stationary identity, new whole-band theorem, additional N160 campaign, independent-person replication, second-platform execution or experimental validation was performed. These are separate from the present reference-frequency accounting.
5. Public-release metadata, licensing and repository destination remain governed by the earlier release records. No publication or GitHub push occurred.

All new mathematics is for the declared reference model: E=36/25, unit bare-bulk parameters, the original six X/R source sections and lower-two spectral observable, with the inherited shell/contour proofs. It does not certify other frequencies or devices. Deterministic outward bounds and checked algebra are reported as such; no calibrated 95% probability is inferred from agreement between solvers.

The final exported replay record is delivered separately and identifies exactly which fresh checks were run. The review targeted material and open referee concerns; it is not described as exhaustive.
