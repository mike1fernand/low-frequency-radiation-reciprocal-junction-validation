#!/usr/bin/env python3
"""Bounded cold replay of this addition; no global-floor promotion.

Writes replay records outside sealed evidence. Each stage is separately
recorded and timeout-limited. The existing N160 production is not repeated.
"""
import argparse,hashlib,json,os,subprocess,sys,time
from pathlib import Path


def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--physical-replay',action='store_true')
    a=p.parse_args();root=Path(__file__).resolve().parent;dest=a.output.absolute()
    if dest.exists() and any(dest.iterdir()):p.error('use a new empty replay output directory')
    dest.mkdir(parents=True,exist_ok=True)
    if dest==root or root in dest.parents and dest.name!='replay':
        p.error('use an external replay directory or package-root/replay')
    manifest=json.loads((root/'MANIFEST.json').read_text())
    for name,sha in manifest['files'].items():
        rel=Path(name)
        if rel.is_absolute() or '..' in rel.parts or digest(root/rel)!=sha:raise ValueError('manifest mismatch: '+name)
    stages=[
      ('coverage',['coverage.py','--selftest','--output',str(dest/'coverage.json')]),
      ('selected_matrix',['matrix/check_matrix_budget.py','--targets','matrix/TARGETS.json','--repo','provenance/selected_repository','--output',str(dest/'matrix.json')]),
      ('fallback',['math/complete_fallback.py','--r2-root','provenance/r2','--output',str(dest/'fallback.json')]),
      ('gauss_rules',['quadrature/validate_tensor.py','--output',str(dest/'gauss.json')]),
      ('sharp_remainder',['quadrature/validate_sharp.py','--output',str(dest/'sharp.json')]),
      ('preconditioned_inverse',['quadrature/preconditioned/validate_preconditioned.py','--output',str(dest/'preconditioner.json')]),
      ('preconditioner_wide_boxes',['review/check_preconditioned_wide.py','--producer','quadrature/preconditioned','--output',str(dest/'preconditioner_wide.json')]),
      ('controller',['quadrature/validate_controller.py','--output',str(dest/'controller.json')]),
      ('replay_reporting',['review/check_replay_reporting.py','--root',str(root),'--output',str(dest/'replay_reporting.json')]),
      ('ledger_controls',['review/check_ledger.py','--root',str(root),'--output',str(dest/'ledger_checks.json')]),
      ('ledger',['complete_ledger.py','--root',str(root),'--manifest','EVIDENCE_MANIFEST.json','--targets','matrix/TARGETS.json','--fallback','math/COMPLETE_FALLBACK_CHECKS.json','--output',str(dest/'ledger.json')]),
      ('numerical_diagnostic',['matrix/numerical/contour_diagnostic.py','--angular','12','--radial','48','--targets','matrix/TARGETS.json','--arb-source','provenance/r2/pilot/source_moments.py','--output',str(dest/'diagnostic.json')]),
    ]
    if a.physical_replay:
        for kind,tol in [('qt','1/25000'),('green','1/5000')]:
            stages.append((kind+'_axis_physical',['quadrature/arbitrary_tile_sharp.py','--bounds','0,1/32,0,1/32','--chart','1','--mode',kind,'--orders','5,5,5','--density-tolerance',tol,'--max-seconds','25','--output',str(dest/(kind+'_axis.json'))]))
        for name,bounds in [('ordinary','3/8,7/16,5/8,11/16'),('body','31/32,1,31/32,1')]:
            stages.append(('preconditioned_'+name,['quadrature/preconditioned/arbitrary_tile_sharp.py','--bounds',bounds,'--chart','1','--mode','qt','--orders','5,5,5','--density-tolerance','1/25000','--max-seconds','25','--output',str(dest/('preconditioned_'+name+'.json'))]))
    records=[];summary={'status':'in_progress','manifest_payloads_verified':len(manifest['files']),'stages':records,
      'scope':'Same-host bounded replay. No full high-cost tile campaign, N160 rerun, second-platform run, or exact-lattice floor certification.'}
    def save(): (dest/'REPLAY.json').write_text(json.dumps(summary,indent=2)+'\n')
    save()
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    for name,args in stages:
        start=time.monotonic();status='passed';code=None
        try:
            r=subprocess.run([sys.executable,*args],cwd=root,env=env,capture_output=True,text=True,timeout=55)
            code=r.returncode;(dest/(name+'.stdout.txt')).write_text(r.stdout);(dest/(name+'.stderr.txt')).write_text(r.stderr)
            if code:status='failed'
        except subprocess.TimeoutExpired as e:
            status='timeout';(dest/(name+'.stderr.txt')).write_text(str(e))
        records.append({'name':name,'status':status,'returncode':code,'wall_seconds':time.monotonic()-start,'arguments':args})
        save();print(name+': '+status,flush=True)
        if status!='passed':summary['status']='failed';save();return 2
    try:
        # Arithmetic ledger replay must match the sealed result exactly.
        if json.loads((dest/'ledger.json').read_text())!=json.loads((root/'COMPLETE_DOMAIN_LEDGER.json').read_text()):
            raise ValueError('replayed ledger differs from sealed result')
        old=json.loads((root/'math/COMPLETE_FALLBACK_CHECKS.json').read_text());new=json.loads((dest/'fallback.json').read_text())
        if old['per_unit_angular_area']!=new['per_unit_angular_area']:raise ValueError('fallback endpoints changed')
        import math
        new=json.loads((dest/'diagnostic.json').read_text());old=json.loads((root/'matrix/numerical/gl12_48.json').read_text())
        maxdiff=0.0
        if new['status']!='complete_domain_numerical_diagnostic_not_certified':raise ValueError('numerical diagnostic incomplete')
        for kind in ('g','Q'):
            left=new['comparison'][kind]['moments'];right=old['comparison'][kind]['moments']
            if len(left)!=17 or any(len(z)!=2 for z in left):raise ValueError('diagnostic moment shape')
            for x,y in zip(left,right):
                d=math.hypot(x[0]-y[0],x[1]-y[1])
                if not math.isfinite(d) or d>1e-12:raise ValueError('numerical diagnostic consistency failed')
                maxdiff=max(maxdiff,d)
        summary['numerical_consistency']={'maximum_moment_difference':maxdiff,'comparison_tolerance':1e-12,'kind':'floating reproducibility comparison, not a lattice error bound'}
        if a.physical_replay:
            for kind,oldname in [('qt','qt_chart1_axis_sharp_gl5.json'),('green','green_chart1_axis_sharp.json')]:
                new=json.loads((dest/(kind+'_axis.json')).read_text());old=json.loads((root/'quadrature'/oldname).read_text())
                if new['status']!='rigorous_complete_tile_enclosure' or new['moments']!=old['moments']:
                    raise ValueError('physical axis replay incomplete or changed: '+kind)
            for name in ('ordinary','body'):
                new=json.loads((dest/('preconditioned_'+name+'.json')).read_text());old=json.loads((root/'quadrature'/('qt_chart1_'+name+'_preconditioned_gl5.json')).read_text())
                if new['status']!='rigorous_complete_tile_enclosure' or new['moments']!=old['moments']:
                    raise ValueError('preconditioned physical replay incomplete or changed: '+name)
    except Exception as e:
        summary['status']='failed';summary['post_validation_error']=str(e);save();print('Post-validation failed: '+str(e),flush=True);return 2
    summary['status']='passed';summary['exact_ledger_reproduced']=True;summary['fallback_endpoints_reproduced']=True;summary['physical_axis_moments_reproduced']=a.physical_replay;summary['preconditioned_ordinary_and_body_moments_reproduced']=a.physical_replay;save()
    print('All '+str(len(records))+' bounded stages passed.',flush=True);return 0


if __name__=='__main__':raise SystemExit(main())
